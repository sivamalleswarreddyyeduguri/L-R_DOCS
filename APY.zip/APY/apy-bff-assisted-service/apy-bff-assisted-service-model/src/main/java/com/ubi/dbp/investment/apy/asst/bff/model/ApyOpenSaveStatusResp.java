package com.ubi.dbp.investment.apy.asst.bff.model;

public class ApyOpenSaveStatusResp {

}
