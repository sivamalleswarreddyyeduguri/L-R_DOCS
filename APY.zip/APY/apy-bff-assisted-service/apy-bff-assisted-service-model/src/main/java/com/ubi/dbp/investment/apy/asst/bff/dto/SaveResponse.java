package com.ubi.dbp.investment.apy.asst.bff.dto;

import lombok.Data;

@Data
public class SaveResponse {
	private String opsStatus;
	private String applicationFrmNum;
}
