package com.ubi.dbp.investment.apy.asst.bff.model;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.ToString;


@ToString
@Data
public class BeneficiaryDetails {
	@NotNull
	@NotBlank
	@Schema(required = true, description = "dob")
	private String dob;
	
	@NotNull
	@NotBlank
	@Schema(required = true, description = "first name")
	private String fname;
	
	private String mname;
	
	@Schema(required = true, description = "last name")
	private String lname;
	
	@NotNull
	@NotBlank
	@Schema(required = true, description = "relationship")
	private String relShipId;
	
	@NotNull
	@NotBlank
	@Schema(required = true, description = "isSameAddr")
	private String isSameAddr;
	
	@NotNull
	@NotBlank
	@Schema(required = true, description = "contact details")
	ContactDetails contactInfo;
}
