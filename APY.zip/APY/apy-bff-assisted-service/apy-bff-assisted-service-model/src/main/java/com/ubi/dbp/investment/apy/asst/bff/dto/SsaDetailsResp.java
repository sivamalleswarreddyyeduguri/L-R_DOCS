package com.ubi.dbp.investment.apy.asst.bff.dto;

import java.util.List;

import dbp.framework.common.investment.model.Document;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SsaDetailsResp {
	private String cif;
	private String applNum;
	List<AccountsDetailsForJourney> accts;
	private String txnId;
	private String relationWithChild;
	private String birthType;
	private List<Document> documents;
}
