package com.ubi.dbp.investment.apy.asst.bff.model;

import java.util.Map;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UploadReq {
	@NotNull
	@NotBlank
	@Schema(required = true, description = "cif")
	private String cif;
	@NotNull
	@NotBlank
	@Schema(required = true, description = "applNum")
	private String applNum;
	@NotNull
	@NotBlank
	@Schema(required = true, description = "docUploadReq")
	DocumentReq docUploadReq;
	private Map<String,String> metaData;
}
