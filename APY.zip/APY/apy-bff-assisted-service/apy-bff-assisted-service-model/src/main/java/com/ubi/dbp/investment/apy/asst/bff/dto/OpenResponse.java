package com.ubi.dbp.investment.apy.asst.bff.dto;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class OpenResponse {
	private String opsStatus;
	private String transRefNumber;
	private String applicationFrmNum;
}
