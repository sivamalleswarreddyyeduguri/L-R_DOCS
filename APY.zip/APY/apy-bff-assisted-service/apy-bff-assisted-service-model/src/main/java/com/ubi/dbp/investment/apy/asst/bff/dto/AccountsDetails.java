package com.ubi.dbp.investment.apy.asst.bff.dto;

import java.time.LocalDate;
import java.util.List;

import dbp.framework.common.model.AcctBal;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AccountsDetails {
	
	private String acctNum;
	private String name;
	AccountStatus acctStatus;
	List<AcctBal> acctBals;
	BankDetails bankInfo;
	LocalDate acctOpenDate;
	LocalDate maturityDate;
	BeneficiaryDetails beneficiary;

}
