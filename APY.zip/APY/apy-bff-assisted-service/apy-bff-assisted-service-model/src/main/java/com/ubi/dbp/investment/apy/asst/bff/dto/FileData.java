package com.ubi.dbp.investment.apy.asst.bff.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class FileData {
	String fileName;
	String data;
}
