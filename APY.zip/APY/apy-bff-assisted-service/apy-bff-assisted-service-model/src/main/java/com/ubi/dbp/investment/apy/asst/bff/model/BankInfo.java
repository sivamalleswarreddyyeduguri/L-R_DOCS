package com.ubi.dbp.investment.apy.asst.bff.model;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BankInfo {
	@Schema(required = true, description = "address required for open and within flow required for save")
	AddressDetails address;
	@Schema(required = true, description = "branch Id required for open and within flow required for save")
	private String branchId;
	@Schema(required = true, description = "branch Sol Id required for open and within flow required for save")
	private String branchSolId;
	@Schema(required = true, description = "branch Name required for open and within flow required for save")
	private String branchName;
	@Schema(required = true, description = "workingHrs required for open and within flow required for save")
	private String workingHrs;
	@Schema(required = true, description = "workingDays required for open and within flow required for save")
	private String workingDays;
}