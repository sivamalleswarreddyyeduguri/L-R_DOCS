package com.ubi.dbp.investment.apy.asst.bff.dto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class PaymentStatusResp {
	
	private String cif;
	private String applNum;
	private String remarks;
	List<AccountsDetailsForPayment> accts;
	InvestmentContributionDetails investmentContribution;
	private String contribStatus;		//For overall contribution status
	private String message;
}
