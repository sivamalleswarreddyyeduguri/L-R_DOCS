package com.ubi.dbp.investment.apy.asst.bff.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SsaDocument {
	private String docRefNo;
	private String name;
	private String type;
	private String uri;
}
