package com.ubi.dbp.investment.apy.asst.bff.model;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class CustomerInfo {
	@NotNull
	@NotBlank
	@Schema(required = true, description = "cif")
	private String cif;
}
