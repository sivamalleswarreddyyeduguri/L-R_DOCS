package com.ubi.dbp.investment.apy.asst.bff.model;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DocumentReq {
	@NotNull
	@NotBlank
	@Schema(required = true, description = "docTypeCode")
	private String docTypeCode;
	@NotNull
	@NotBlank
	@Schema(required = true, description = "docCategory")
	private String docCategory;
	@NotNull
	@NotBlank
	@Schema(required = true, description = "fileTypeCode")
	private String fileTypeCode;
	@NotNull
	@NotBlank
	@Schema(required = true, description = "content")
	private String content;
}
