package com.ubi.dbp.investment.apy.asst.bff.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class InvestmentContributionDetails {
	private String paymentTxnId;
	private BigDecimal contribAmt;
	private String channelTxnId;
	private String contribAcctNum;
	private LocalDateTime paymentTxnDate;
}
