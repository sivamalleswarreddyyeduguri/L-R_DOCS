package com.ubi.dbp.investment.apy.asst.bff.model;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class PaymentStatusReq {
	@NotNull
	@Schema(required = true, description = "cif")
	private String cif;
	@NotNull
	@Schema(required = true, description = "source")
	SourceInfo source;
	@NotNull
	@Schema(required = true, description = "investmentContribution")
	InvestmentContributionInfo investmentContribution;
	
}
