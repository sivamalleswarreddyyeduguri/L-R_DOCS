package com.ubi.dbp.investment.apy.asst.bff.model;

import java.time.LocalDate;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ContributionDemo {
	@NotNull
	@Min(value=1,message="txnId should not be less than 5")
	@Max(value=100,message="txnId should not be more than 20")
	private int  txnId;
	
	@NotNull
	@Min(value=1,message="amount should not be less than 500")
	@Max(value=100,message="amount should not be more than 1000")
	private int amount;
	@NotNull
	private LocalDate startDate;
	@NotNull	
	private LocalDate  endDate;
	
	@Schema(minLength = 5, maxLength = 256)
	@NotNull
	private String name;
	
}