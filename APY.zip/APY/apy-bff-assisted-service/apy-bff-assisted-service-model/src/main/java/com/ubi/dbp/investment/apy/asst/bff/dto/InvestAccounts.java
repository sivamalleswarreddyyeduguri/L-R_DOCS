package com.ubi.dbp.investment.apy.asst.bff.dto;

import java.math.BigDecimal;
import java.time.LocalDate;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class InvestAccounts {
	private String cif ;
	private String acctNum;
	private String applNum;
	private String acctStatus;
	private String customerName;
	private String acctName;
	private String acctType;
	private Boolean activeFlag;
//	private LocalDate openingDate;
	private LocalDate maturityDate;
	private BigDecimal acctBal;
	private BigDecimal penaltyAmount;
}
