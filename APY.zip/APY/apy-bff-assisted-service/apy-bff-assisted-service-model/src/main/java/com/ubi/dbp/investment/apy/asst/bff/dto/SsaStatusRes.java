package com.ubi.dbp.investment.apy.asst.bff.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SsaStatusRes {
	
	private String cif;
	private String transRefNumber;
	private BigDecimal amount;
	private String paymentTxnId;
	private String creditAccountNumber;
	private String debitAccountNumber;
	private BigDecimal currentInterestRate;
	private LocalDate paymentTxnDate;
	private String paymentTxnStatus;
	private String remarks;
	private LocalDate maturityDate;

}
