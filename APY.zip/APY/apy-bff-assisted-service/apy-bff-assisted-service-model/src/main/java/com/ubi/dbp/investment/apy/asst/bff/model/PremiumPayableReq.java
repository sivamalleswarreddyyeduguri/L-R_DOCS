package com.ubi.dbp.investment.apy.asst.bff.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PremiumPayableReq {
	private String cif;
	private InvestmentContribution investmentContribution;
	private CustomerForPremium customer;
}
