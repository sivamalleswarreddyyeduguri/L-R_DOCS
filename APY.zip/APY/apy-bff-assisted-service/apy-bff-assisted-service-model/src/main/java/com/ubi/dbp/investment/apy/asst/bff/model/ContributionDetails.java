package com.ubi.dbp.investment.apy.asst.bff.model;

import java.math.BigDecimal;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class ContributionDetails {
	@NotNull
	@NotBlank
	@Schema(required = true, description = "contribution amount required for open and Contribution Details and within flow required for save")
	private BigDecimal contribAmt;
	@NotNull
	@NotBlank
	@Schema(required = true, description = "contribution acct num required for open and Contribution Details and within flow required for save")
	private String contribAcctNum;
	@Schema(description = "Remarks not required for validateAmunt only applicable for Contribution")
	private String remarks;
}
