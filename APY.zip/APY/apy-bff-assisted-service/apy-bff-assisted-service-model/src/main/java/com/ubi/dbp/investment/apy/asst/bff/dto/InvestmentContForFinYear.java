package com.ubi.dbp.investment.apy.asst.bff.dto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class InvestmentContForFinYear {
	private List<String> financialYears;
}
