package com.ubi.dbp.investment.apy.asst.bff.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BankDetails {
	PostalAddress address;
	private String branchId;
	private String branchSolId;
	private String branchName;
	private String workingDays;
	private String workingHrs;
}
