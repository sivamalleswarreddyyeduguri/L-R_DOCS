package com.ubi.dbp.investment.apy.asst.bff.model;

import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.ToString;


@ToString
@Data
public class DeclarationInfo {
	@NotNull
	@Schema(required = true, description = "declarationText required for open and within flow required for save")
	private List<String> declarationText;
	@NotNull
	@Schema(required = true, description = "isAccepted required for open and within flow required for save")
	private Boolean isAccepted;
}
