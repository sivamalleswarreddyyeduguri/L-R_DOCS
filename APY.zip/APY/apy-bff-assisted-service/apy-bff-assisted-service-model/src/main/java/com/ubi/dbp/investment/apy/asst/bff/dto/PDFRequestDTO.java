package com.ubi.dbp.investment.apy.asst.bff.dto;

import java.time.LocalDate;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
public class PDFRequestDTO {
	
	@Schema(required = true, description = "cif")
	String cif;
	
	@Schema(required = true, description = "acctNum")
	String acctNum;
	
	@Schema(required = true, description = "startDate")
	LocalDate startDate;
	
	@Schema(required = true, description = "endDate")
	LocalDate endDate;
}
