package com.ubi.dbp.investment.apy.asst.bff.dto;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonInclude;

import dbp.framework.common.investment.model.InvestmentResponse;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SsaAcctResponse extends InvestmentResponse{

	private String rqType;		//Request Type -- ACCT_OPERATION or CONTRIBUTION to identify message request type at Proxy level
	private BigDecimal currFYContriAmt;		//Current FY Contribution for PPF/SSA
	private BigDecimal penaltyAmt;		//Current penalty for PPF/SSA
	private String relationWithChild;		//For SSA
	private String birthType;	
}