package com.ubi.dbp.investment.apy.asst.bff.model;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Documents {
	@Schema(required = true, description = "name(only for Open Ssa)")
	private String name;
	@Schema(required = true, description = "type(only for Open Ssa)")  
	private String type;
	@Schema(required = true, description = "uri(only for Open Ssa)")
	private String uri;

}
