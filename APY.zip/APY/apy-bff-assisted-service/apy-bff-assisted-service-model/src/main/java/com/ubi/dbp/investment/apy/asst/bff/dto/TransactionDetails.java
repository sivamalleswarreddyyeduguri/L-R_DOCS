package com.ubi.dbp.investment.apy.asst.bff.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

import lombok.Data;

@Data
public class TransactionDetails {
	private String acctNum;	//account number
	private LocalDate transactionDate;	//TrnDt
	private BigDecimal amount;	//TrnAmt
	private LocalDate valueDate;	//ValueDt
	private String transactionCurrencyCode;//TrnCurCode
}
