package com.ubi.dbp.investment.apy.asst.bff.config;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebFilter;
import org.springframework.web.server.WebFilterChain;

import reactor.core.publisher.Mono;
//@Component
//@Order(-1) // Set the order to ensure this filter is executed before others
public class ContentLengthFilter implements WebFilter {
    @Override
    public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {
        return chain.filter(exchange)
//                .contextWrite(ServerWebExchangeContextFilter.setResponseStatus(exchange.getResponse().getRawStatusCode()))
                .doOnTerminate(() -> addContentLengthHeader(exchange));
    }
    private void addContentLengthHeader(ServerWebExchange exchange) {
        // Get the content length from the response body
        Long contentLength = exchange.getResponse().getHeaders().getContentLength();
        // Add the Content-Length header to the response
        if (contentLength != null) {
        	
            exchange.getResponse().getHeaders().setContentLength(contentLength);
        }
    }
}