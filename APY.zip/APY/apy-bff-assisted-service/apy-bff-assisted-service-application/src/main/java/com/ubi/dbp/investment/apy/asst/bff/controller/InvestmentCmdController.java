package com.ubi.dbp.investment.apy.asst.bff.controller;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ubi.dbp.investment.apy.asst.bff.dto.OpenResponse;
import com.ubi.dbp.investment.apy.asst.bff.dto.SaveResponse;
import com.ubi.dbp.investment.apy.asst.bff.model.ApyOpenSaveStatusResp;
import com.ubi.dbp.investment.apy.asst.bff.model.OpenSsaReq;
import com.ubi.dbp.investment.apy.asst.bff.model.SaveSsaReq;
import com.ubi.dbp.investment.apy.asst.bff.service.InvestmentBFFApyCmdService;

import dbp.framework.schema.validator.dbpbffabs.DbpAbstractBff;
import dbp.framework.support.exception.ErrorResponse;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/web/invst/apy/api/v1/")
@OpenAPIDefinition(info = @Info(title = "APIs", version = "1.0", description = "Documentation APIs v2.0"))
@Tag(name = "Apy BFF APIs", description = "Apy BFF APIs to perform various operation on Apy")
public class InvestmentCmdController extends DbpAbstractBff {

	private InvestmentBFFApyCmdService bffCmdRequestService;
	
	public InvestmentCmdController(InvestmentBFFApyCmdService bffCmdRequestService) {
		this.bffCmdRequestService = bffCmdRequestService;
	}
	
	
	@Operation(summary = "This is to save the Apy Details")
	@ApiResponses({@ApiResponse(responseCode = "200", description = "This is to Save Apy Details", content = {@Content(schema = @Schema(implementation = ApyOpenSaveStatusResp.class))}), 
		@ApiResponse(responseCode = "400", description = "Data not retrived", content = {@Content(schema = @Schema(implementation = ErrorResponse.class))}),
		@ApiResponse(responseCode = "404", description = "Data not retrived", content = {@Content(schema = @Schema(implementation = ErrorResponse.class))}), 
		@ApiResponse(responseCode = "500", description = "Server not responded", content = {@Content(schema = @Schema(implementation = ErrorResponse.class))})})
//	@ValidateDbpSchema(groupId = "com.ubi.dbp.investment",artifactId = "web_invst_ssa_api_v1_saveSsa")
//	@PostMapping(value = {"saveApy"}, produces = {"application/json"})
	public Mono<SaveResponse> saveApy (@RequestBody SaveSsaReq saveSsaReq) {
		return this.bffCmdRequestService.saveApy(saveSsaReq);
	}
	
	@Operation(summary = "This is to Open Apy ")
	@ApiResponses({@ApiResponse(responseCode = "200", description = "This is to Open Apy Account", content = {@Content(schema = @Schema(implementation = ApyOpenSaveStatusResp.class))}), 
		@ApiResponse(responseCode = "400", description = "Data not retrived", content = {@Content(schema = @Schema(implementation = ErrorResponse.class))}),
		@ApiResponse(responseCode = "404", description = "Data not retrived", content = {@Content(schema = @Schema(implementation = ErrorResponse.class))}), 
		@ApiResponse(responseCode = "500", description = "Server not responded", content = {@Content(schema = @Schema(implementation = ErrorResponse.class))})})
//	@ValidateDbpSchema(groupId = "com.ubi.dbp.investment",artifactId = "web_invst_ssa_api_v1_openSsa")
//	@PostMapping(value = {"openApy"}, produces = {"application/json"})
	public Mono<OpenResponse> openApy (@RequestBody OpenSsaReq openSsaReq) {
		return this.bffCmdRequestService.openApy(openSsaReq);
	}
	
}
