package com.ubi.dbp.investment.apy.asst.bff.service.impl;

import java.util.Map;

import org.springframework.stereotype.Service;

import com.ubi.dbp.investment.apy.asst.bff.config.InvestmentBFFAppApyCmdConfig;
import com.ubi.dbp.investment.apy.asst.bff.dto.OpenResponse;
import com.ubi.dbp.investment.apy.asst.bff.dto.PaymentStatusResp;
import com.ubi.dbp.investment.apy.asst.bff.dto.RemoveResp;
import com.ubi.dbp.investment.apy.asst.bff.dto.SaveResponse;
import com.ubi.dbp.investment.apy.asst.bff.dto.UploadResp;
import com.ubi.dbp.investment.apy.asst.bff.model.ContributionReq;
import com.ubi.dbp.investment.apy.asst.bff.model.InvestmentContributionInfo;
import com.ubi.dbp.investment.apy.asst.bff.model.OpenSsaReq;
import com.ubi.dbp.investment.apy.asst.bff.model.PaymentStatusReq;
import com.ubi.dbp.investment.apy.asst.bff.model.SaveSsaReq;
import com.ubi.dbp.investment.apy.asst.bff.model.SourceInfo;
import com.ubi.dbp.investment.apy.asst.bff.model.UploadReq;
import com.ubi.dbp.investment.apy.asst.bff.service.InvestmentBFFApyCmdService;
import com.ubi.dbp.investment.apy.asst.bff.service.InvestmentBFFApyQryService;
import com.ubi.dbp.investment.apy.asst.bff.service.AbsCommonService.CallType;
import com.ubi.dbp.investment.apy.asst.bff.util.JSONHeader;

import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;


@Service
@Slf4j
public class InvestmentBFFApyCmdServiceImpl implements InvestmentBFFApyCmdService {

	private InvestmentBFFAppApyCmdConfig investmentBFFAppApyCmdConfig;
	

	Map<String, String> header = JSONHeader.getHeader();
	
	private CommonService commonUtil;
	
	public InvestmentBFFApyCmdServiceImpl(InvestmentBFFAppApyCmdConfig investmentBFFAppApyCmdConfig , CommonService commonUtil) {
		this.investmentBFFAppApyCmdConfig = investmentBFFAppApyCmdConfig;
		this.commonUtil = commonUtil;
		
	}

	@Override
	public Mono<SaveResponse> saveApy(SaveSsaReq saveReq) {
		return Mono.fromSupplier(() -> {
            return commonUtil.getData(null,
            		investmentBFFAppApyCmdConfig.getApyCmdSvcBaseUrl()
    				+ investmentBFFAppApyCmdConfig.getApyCmdInvestmentPath() + investmentBFFAppApyCmdConfig.getSaveApy(),
    				saveReq, SaveResponse.class, CallType.POST, false);
        });
	}

	@Override
	public Mono<OpenResponse> openApy(OpenSsaReq openReq) {
		log.info("openReq : "+openReq);
		return Mono.fromSupplier(() -> {
            return commonUtil.getData(null,
            		investmentBFFAppApyCmdConfig.getApyCmdSvcBaseUrl()
    				+ investmentBFFAppApyCmdConfig.getApyCmdInvestmentPath() + investmentBFFAppApyCmdConfig.getOpenApy(),
    				openReq, OpenResponse.class, CallType.POST, false);
        });
	}

}
