package com.ubi.dbp.investment.apy.asst.bff.util;

public class ApyConst {

	public static enum InvestmentStatus {
		DRAFT, PENDING, COMPLETE, CLOSED, REJECTED, PENDING_CBS, PENDING_GBM
	}
}
