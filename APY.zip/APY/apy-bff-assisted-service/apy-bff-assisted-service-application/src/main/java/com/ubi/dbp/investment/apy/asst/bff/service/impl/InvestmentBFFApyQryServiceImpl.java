package com.ubi.dbp.investment.apy.asst.bff.service.impl;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.ubi.dbp.investment.apy.asst.bff.config.InvestmentBFFAppApyQryConfig;
import com.ubi.dbp.investment.apy.asst.bff.dto.ApyAccountResp;
import com.ubi.dbp.investment.apy.asst.bff.dto.ApyStatusResponse;
import com.ubi.dbp.investment.apy.asst.bff.dto.EmailResponse;
import com.ubi.dbp.investment.apy.asst.bff.dto.ExistingAccountsResp;
import com.ubi.dbp.investment.apy.asst.bff.dto.FinancialYearsResp;
import com.ubi.dbp.investment.apy.asst.bff.dto.InvestmentAccountsResp;
import com.ubi.dbp.investment.apy.asst.bff.dto.PDFDownloaderDTO;
import com.ubi.dbp.investment.apy.asst.bff.dto.PremiumPayableResp;
import com.ubi.dbp.investment.apy.asst.bff.dto.SsaDetailsResp;
import com.ubi.dbp.investment.apy.asst.bff.dto.TransactionDetailsResp;
import com.ubi.dbp.investment.apy.asst.bff.exception.ErrorEnum;
import com.ubi.dbp.investment.apy.asst.bff.exception.InvestmentException;
import com.ubi.dbp.investment.apy.asst.bff.model.ApyAccReq;
import com.ubi.dbp.investment.apy.asst.bff.model.ApyDetailsReq;
import com.ubi.dbp.investment.apy.asst.bff.model.ExistingAccountReq;
import com.ubi.dbp.investment.apy.asst.bff.model.FinancialYearReq;
import com.ubi.dbp.investment.apy.asst.bff.model.PremiumPayableReq;
import com.ubi.dbp.investment.apy.asst.bff.model.StatementReq;
import com.ubi.dbp.investment.apy.asst.bff.model.TransactionReq;
import com.ubi.dbp.investment.apy.asst.bff.service.InvestmentBFFApyQryService;
import com.ubi.dbp.investment.apy.asst.bff.service.AbsCommonService.CallType;

import reactor.core.publisher.Mono;

@Service
//@Slf4j
public class InvestmentBFFApyQryServiceImpl implements InvestmentBFFApyQryService {

	private InvestmentBFFAppApyQryConfig investBFFAppConfig;
	private CommonService commonUtil;
	public InvestmentBFFApyQryServiceImpl(InvestmentBFFAppApyQryConfig investBFFAppConfig, CommonService commonUtil) {
		this.investBFFAppConfig = investBFFAppConfig;
		this.commonUtil = commonUtil;
	}

	@Override
	public Mono<TransactionDetailsResp> getApyTransactions(TransactionReq transactionReq) {
		return Mono.fromSupplier(() -> {
			return commonUtil.getData(null,
					investBFFAppConfig.getApyQrySvcBaseUrl() + investBFFAppConfig.getApyQryInvestmentPath()
							+ investBFFAppConfig.getApyTransactions(),
					transactionReq, TransactionDetailsResp.class, CallType.POST, false);
		});
	}

	@Override
	public Mono<PDFDownloaderDTO> downloadStatement(StatementReq pdfRequest) {
		return Mono.fromSupplier(() -> {
			return commonUtil.getData(null,
					investBFFAppConfig.getApyQrySvcBaseUrl() + investBFFAppConfig.getApyQryInvestmentPath()
							+ investBFFAppConfig.getApyStatement(),
					pdfRequest, PDFDownloaderDTO.class, CallType.POST, false);
		});
	}

	@Override
	public Mono<EmailResponse> emailStatement(StatementReq emailRes) {
		return Mono.fromSupplier(() -> {
			return commonUtil.getData(null,
					investBFFAppConfig.getApyQrySvcBaseUrl() + investBFFAppConfig.getApyQryInvestmentPath()
							+ investBFFAppConfig.getApyEmailStatement(),
					emailRes, EmailResponse.class, CallType.POST, false);
		});
	}

	@Override
	public Mono<ApyStatusResponse> getApyStatus(ApyDetailsReq ssaStatusReq) {
		return Mono.fromSupplier(() -> {
			return commonUtil
					.getData(ssaStatusReq.getCif() + "_" + ssaStatusReq.getApplicationFrmNum() + "_" + new Object() {
					}.getClass().getEnclosingMethod().getName(),
							investBFFAppConfig.getApyQrySvcBaseUrl() + investBFFAppConfig.getApyQryInvestmentPath()
									+ investBFFAppConfig.getApyStatus(),
							ssaStatusReq, ApyStatusResponse.class, CallType.POST, true);
		});
	}

	@Override
	public Mono<ApyAccountResp> getApyAccountDetails(ApyAccReq accReq) {
		return Mono.fromSupplier(() -> {
			return commonUtil.getData(accReq.getCif() + "_" + accReq.getSource().getAcctNum() + "_" + new Object() {
			}.getClass().getEnclosingMethod().getName(),
					investBFFAppConfig.getApyQrySvcBaseUrl() + investBFFAppConfig.getApyQryInvestmentPath()
							+ investBFFAppConfig.getApyAccountDetails(),
					accReq, ApyAccountResp.class, CallType.POST, true);
		});
	}

	@Override
	public Mono<SsaDetailsResp> getApyDetailsToResume(ApyDetailsReq detailReq) {
		return Mono.fromSupplier(() -> {
			return commonUtil.getData(null,
					investBFFAppConfig.getApyQrySvcBaseUrl() + investBFFAppConfig.getApyQryInvestmentPath()
							+ investBFFAppConfig.getApyDetailsToResume(),
					detailReq, SsaDetailsResp.class, CallType.POST, false);
		});
	}

	@Override
	public Mono<ExistingAccountsResp> checkExistingAccounts(ExistingAccountReq existingReq) {
		if (StringUtils.isBlank(existingReq.getCif())) {
			throw new InvestmentException(ErrorEnum.CUST_NOT_INIT);
		}
		return Mono.fromSupplier(() -> {
			return commonUtil.getData(existingReq.getCif() + "_" + new Object() {
			}.getClass().getEnclosingMethod().getName(),
					investBFFAppConfig.getApyQrySvcBaseUrl() + investBFFAppConfig.getApyQryInvestmentPath()
							+ investBFFAppConfig.getApyExistingAccounts(),
					existingReq, ExistingAccountsResp.class, CallType.POST, true);
		});
	}

	@Override
	public Mono<InvestmentAccountsResp> getInvestmentAccounts(ExistingAccountReq existingReq) {
		if (StringUtils.isBlank(existingReq.getCif())) {
			throw new InvestmentException(ErrorEnum.CUST_NOT_INIT);
		}
		return Mono.fromSupplier(() -> {
			return commonUtil.getData(existingReq.getCif() + "_" + new Object() {
			}.getClass().getEnclosingMethod().getName(),
					investBFFAppConfig.getApyQrySvcBaseUrl() + investBFFAppConfig.getApyQryInvestmentPath()
							+ investBFFAppConfig.getInvestmentAccounts(),
					existingReq, InvestmentAccountsResp.class, CallType.POST, true);
		});
	}

	@Override
	public Mono<PremiumPayableResp> getPremiumPayable(PremiumPayableReq premiumPayableReq) {
		return Mono.fromSupplier(() -> {
			return commonUtil.getData(null,
					investBFFAppConfig.getApyQrySvcBaseUrl() + investBFFAppConfig.getApyQryInvestmentPath()
							+ investBFFAppConfig.getPremiumPayable(),
							premiumPayableReq, PremiumPayableResp.class, CallType.POST, false);
		});
	}

	@Override
	public Mono<FinancialYearsResp> getFinancialYears(FinancialYearReq financialYearReq) {
		return Mono.fromSupplier(() -> {
			return commonUtil.getData(null,
					investBFFAppConfig.getApyQrySvcBaseUrl() + investBFFAppConfig.getApyQryInvestmentPath()
							+ investBFFAppConfig.getFinancialYears(),
							financialYearReq, FinancialYearsResp.class, CallType.POST, false);
		});
	}



//	@Override
//	public Mono<FileData> getSSATermsAndCondition(TAndCRequest tAndCRequest) {
//		if (tAndCRequest != null && tAndCRequest.getTandCType().equalsIgnoreCase("SSA") && apyFileData != null) {
//			log.info("ssaFileData not null...");
//			return Mono.just(apyFileData);
//		} else if (tAndCRequest.getTandCType().equalsIgnoreCase("SSA")) {
//			log.info("initially ssaFileData null...");
//			try {
//				log.info("Reading data from pdf file...");
//				InputStream inputStream = this.getClass().getClassLoader()
//						.getResourceAsStream(investBFFAppConfig.getTermsAndConditionforApy());
//				if (inputStream == null) {
//					throw new IOException("File not found " + investBFFAppConfig.getTermsAndConditionforApy());
//				}
//
//				byte[] pdfBytes = inputStream.readAllBytes();
//				log.info("Saving data in ssaFileData...");
//				apyFileData = new FileData(tAndCRequest.getTandCType().toUpperCase() + "_T&C" + ".pdf",
//						Base64.getEncoder().encodeToString(pdfBytes));
//				return Mono.just(apyFileData);
//			} catch (Exception e) {
//				log.error("some exception to process request", e.getMessage());
//			}
//		}
//		throw new InvestmentException(ErrorEnum.NO_SSA_TYPE);
//	}

}
