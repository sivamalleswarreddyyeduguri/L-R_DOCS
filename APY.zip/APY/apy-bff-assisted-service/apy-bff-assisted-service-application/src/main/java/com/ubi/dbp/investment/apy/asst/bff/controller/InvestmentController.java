package com.ubi.dbp.investment.apy.asst.bff.controller;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ubi.dbp.investment.apy.asst.bff.dto.ApyAccountResp;
import com.ubi.dbp.investment.apy.asst.bff.dto.ApyStatusResponse;
import com.ubi.dbp.investment.apy.asst.bff.dto.EmailResponse;
import com.ubi.dbp.investment.apy.asst.bff.dto.ExistingAccountsResp;
import com.ubi.dbp.investment.apy.asst.bff.dto.FinancialYearsResp;
import com.ubi.dbp.investment.apy.asst.bff.dto.InvestmentAccountsResp;
import com.ubi.dbp.investment.apy.asst.bff.dto.PDFDownloaderDTO;
import com.ubi.dbp.investment.apy.asst.bff.dto.PremiumPayableResp;
import com.ubi.dbp.investment.apy.asst.bff.dto.SsaDetailsResp;
import com.ubi.dbp.investment.apy.asst.bff.dto.TransactionDetailsResp;
import com.ubi.dbp.investment.apy.asst.bff.model.ApyAccReq;
import com.ubi.dbp.investment.apy.asst.bff.model.ApyDetailsReq;
import com.ubi.dbp.investment.apy.asst.bff.model.ExistingAccountReq;
import com.ubi.dbp.investment.apy.asst.bff.model.FinancialYearReq;
import com.ubi.dbp.investment.apy.asst.bff.model.PremiumPayableReq;
import com.ubi.dbp.investment.apy.asst.bff.model.StatementReq;
import com.ubi.dbp.investment.apy.asst.bff.model.TransactionReq;
import com.ubi.dbp.investment.apy.asst.bff.service.InvestmentBFFApyQryService;

import dbp.framework.schema.validator.dbpbffabs.DbpAbstractBff;
import dbp.framework.support.exception.ErrorResponse;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/web/invst/apy/api/v1/")
@OpenAPIDefinition(info = @Info(title = "APIs", version = "1.0", description = "Documentation APIs v2.0"))
@Tag(name = "Apy BFF APIs", description = "Apy BFF APIs to perform various operation on Apy")
public class InvestmentController extends DbpAbstractBff {

	private InvestmentBFFApyQryService bffQryRequestService;
	
	public InvestmentController(InvestmentBFFApyQryService bffQryRequestService) {
		this.bffQryRequestService = bffQryRequestService;
	}
	
	@Operation(summary = "This is to fetch Apy Transaction Details")
	@ApiResponses({@ApiResponse(responseCode = "200", description = "This is to fetch All the Apy Transaction Details", content = {@Content(schema = @Schema(implementation = TransactionDetailsResp.class))}), 
		@ApiResponse(responseCode = "400", description = "Data not retrived", content = {@Content(schema = @Schema(implementation = ErrorResponse.class))}),
		@ApiResponse(responseCode = "404", description = "Data not retrived", content = {@Content(schema = @Schema(implementation = ErrorResponse.class))}),
		@ApiResponse(responseCode = "500", description = "Server not responded", content = {@Content(schema = @Schema(implementation = ErrorResponse.class))})})
//	@PostMapping(value = {"getApyTransactions"}, produces = {"application/json"})
//	@ValidateDbpSchema(groupId = "com.ubi.dbp.investment",artifactId = "web_invst_apy_api_v1_getApyTransactions")
	public Mono<TransactionDetailsResp> getApyTransactions(@RequestBody TransactionReq transactionReq) {
		return this.bffQryRequestService.getApyTransactions(transactionReq);
	}
	
	@Operation(summary = "Download Statement")
	  @ApiResponses({@ApiResponse(responseCode = "200", description = "This is to Download All the Apy Transaction Details", content = {@Content(schema = @Schema(implementation = PDFDownloaderDTO.class))}), 
		  @ApiResponse(responseCode = "400", description = "Data not retrived", content = {@Content(schema = @Schema(implementation = ErrorResponse.class))}),
		  @ApiResponse(responseCode = "404", description = "Data not retrived", content = {@Content(schema = @Schema(implementation = ErrorResponse.class))}), 
		  @ApiResponse(responseCode = "500", description = "Server not responded", content = {@Content(schema = @Schema(implementation = ErrorResponse.class))})})
//	  @PostMapping(value = {"downloadStatement"}, produces = {"application/json"})
//	@ValidateDbpSchema(groupId = "com.ubi.dbp.investment",artifactId = "web_invst_apy_api_v1_downloadStatement")
	public Mono<PDFDownloaderDTO> downloadStatement(@RequestBody StatementReq statementReq) {
		return this.bffQryRequestService.downloadStatement(statementReq);
	}
	
	@Operation(summary = "Email Statement")
	  @ApiResponses({@ApiResponse(responseCode = "200", description = "This is to Email All the Apy Transaction Details", content = {@Content(schema = @Schema(implementation = EmailResponse.class))}), 
		  @ApiResponse(responseCode = "400", description = "Data not retrived", content = {@Content(schema = @Schema(implementation = ErrorResponse.class))}),
		  @ApiResponse(responseCode = "404", description = "Data not retrived", content = {@Content(schema = @Schema(implementation = ErrorResponse.class))}), 
		  @ApiResponse(responseCode = "500", description = "Server not responded", content = {@Content(schema = @Schema(implementation = ErrorResponse.class))})})
//	  @PostMapping(value = {"emailStatement"}, produces = {"application/json"})
//	@ValidateDbpSchema(groupId = "com.ubi.dbp.investment",artifactId = "web_invst_apy_api_v1_emailStatement")
	public Mono<EmailResponse> emailStatement(@RequestBody StatementReq emailReq) {
		return this.bffQryRequestService.emailStatement(emailReq);
	}
	
	@Operation(summary = "This is to fetch Apy Status")
	@ApiResponses({@ApiResponse(responseCode = "200", description = "This is to fetch Apy Status", content = {@Content(schema = @Schema(implementation = ApyStatusResponse.class))}), 
		@ApiResponse(responseCode = "400", description = "Data not retrived", content = {@Content(schema = @Schema(implementation = ErrorResponse.class))}),
		@ApiResponse(responseCode = "404", description = "Data not retrived", content = {@Content(schema = @Schema(implementation = ErrorResponse.class))}), 
		@ApiResponse(responseCode = "500", description = "Server not responded", content = {@Content(schema = @Schema(implementation = ErrorResponse.class))})})
//	@PostMapping(value = {"getApyStatus"}, produces = {"application/json"})
//	@ValidateDbpSchema(groupId = "com.ubi.dbp.investment",artifactId = "web_invst_apy_api_v1_getApyStatus")
	public Mono<ApyStatusResponse> getApyStatus(@RequestBody ApyDetailsReq apyStatusReq) {
		return this.bffQryRequestService.getApyStatus(apyStatusReq);
	}
	
	@Operation(summary = "This is to fetch Apy Account Details")
	@ApiResponses({@ApiResponse(responseCode = "200", description = "This is to fetch Apy Account Details", content = {@Content(schema = @Schema(implementation = ApyAccountResp.class))}), 
		@ApiResponse(responseCode = "400", description = "Data not retrived", content = {@Content(schema = @Schema(implementation = ErrorResponse.class))}),
		@ApiResponse(responseCode = "404", description = "Data not retrived", content = {@Content(schema = @Schema(implementation = ErrorResponse.class))}), 
		@ApiResponse(responseCode = "500", description = "Server not responded", content = {@Content(schema = @Schema(implementation = ErrorResponse.class))})})
//	@PostMapping(value = {"getApyAccountDetails"}, produces = {"application/json"})
//	@ValidateDbpSchema(groupId = "com.ubi.dbp.investment",artifactId = "web_invst_apy_api_v1_getApyAccountDetails")
	public Mono<ApyAccountResp> getApyAccountDetails(@RequestBody ApyAccReq accReq) {
		return this.bffQryRequestService.getApyAccountDetails(accReq);
	}
	
	
	@Operation(summary = "This is to fetch Apy Details to Resume for Apy Account")
	@ApiResponses({@ApiResponse(responseCode = "200", description = "This is to fetch Apy Details To Resume", content = {@Content(schema = @Schema(implementation = SsaDetailsResp.class))}), 
		@ApiResponse(responseCode = "400", description = "Data not retrived", content = {@Content(schema = @Schema(implementation = ErrorResponse.class))}),
		@ApiResponse(responseCode = "404", description = "Data not retrived", content = {@Content(schema = @Schema(implementation = ErrorResponse.class))}), 
		@ApiResponse(responseCode = "500", description = "Server not responded", content = {@Content(schema = @Schema(implementation = ErrorResponse.class))})})
//	@PostMapping(value = {"getApyDetailsToResume"}, produces = {"application/json"})
//	@ValidateDbpSchema(groupId = "com.ubi.dbp.investment",artifactId = "web_invst_apy_api_v1_getSSADetailsToResume")
	public Mono<SsaDetailsResp> getApyDetailsToResume(@RequestBody ApyDetailsReq detailReq) {
		return this.bffQryRequestService.getApyDetailsToResume(detailReq);
	}
	
	@Operation(summary = "This is to fetch Existing Apy Accounts for Customer")
	@ApiResponses({@ApiResponse(responseCode = "200", description = "This is to fetch Existing Apy Accounts for Customer", content = {@Content(schema = @Schema(implementation = ExistingAccountsResp.class))}), 
		@ApiResponse(responseCode = "400", description = "Data not retrived", content = {@Content(schema = @Schema(implementation = ErrorResponse.class))}),
		@ApiResponse(responseCode = "404", description = "Data not retrived", content = {@Content(schema = @Schema(implementation = ErrorResponse.class))}), 
		@ApiResponse(responseCode = "500", description = "Server not responded", content = {@Content(schema = @Schema(implementation = ErrorResponse.class))})})
//	@PostMapping(value = {"checkExistingAccounts"}, produces = {"application/json"})
//	@ValidateDbpSchema(groupId = "com.ubi.dbp.investment",artifactId = "web_invst_apy_api_v1_checkExistingAccounts")
	public Mono<ExistingAccountsResp> checkExistingAccounts(@RequestBody ExistingAccountReq existingReq) {
		return this.bffQryRequestService.checkExistingAccounts(existingReq);
	}
	
	@Operation(summary = "This is to fetch All Investment Accounts for Customer")
	@ApiResponses({@ApiResponse(responseCode = "200", description = "This is to fetch Investment Accounts for Customer", content = {@Content(schema = @Schema(implementation = InvestmentAccountsResp.class))}), 
		@ApiResponse(responseCode = "400", description = "Data not retrived", content = {@Content(schema = @Schema(implementation = ErrorResponse.class))}),
		@ApiResponse(responseCode = "404", description = "Data not retrived", content = {@Content(schema = @Schema(implementation = ErrorResponse.class))}), 
		@ApiResponse(responseCode = "500", description = "Server not responded", content = {@Content(schema = @Schema(implementation = ErrorResponse.class))})})
//	@PostMapping(value = {"getInvestmentAccounts"}, produces = {"application/json"})
//	@ValidateDbpSchema(groupId = "com.ubi.dbp.investment",artifactId = "web_invst_apy_api_v1_getInvestmentAccounts")
	public Mono<InvestmentAccountsResp> getInvestmentAccounts(@RequestBody ExistingAccountReq existingReq) {
		return this.bffQryRequestService.getInvestmentAccounts(existingReq);
	}
	
	@Operation(summary = "This is to calculate Premium Payable for APY Account Opening")
	@ApiResponses({@ApiResponse(responseCode = "200", description = "This is to calculate Premium Payable for APY Account Opening", content = {@Content(schema = @Schema(implementation = PremiumPayableResp.class))}), 
		@ApiResponse(responseCode = "400", description = "Data not retrived", content = {@Content(schema = @Schema(implementation = ErrorResponse.class))}),
		@ApiResponse(responseCode = "404", description = "Data not retrived", content = {@Content(schema = @Schema(implementation = ErrorResponse.class))}), 
		@ApiResponse(responseCode = "500", description = "Server not responded", content = {@Content(schema = @Schema(implementation = ErrorResponse.class))})})
	@PostMapping(value = {"getPremiumPayable"}, produces = {"application/json"})
//	@ValidateDbpSchema(groupId = "com.ubi.dbp.investment",artifactId = "web_invst_apy_api_v1_getPremiumPayable")
	public Mono<PremiumPayableResp> getPremiumPayable(@RequestBody PremiumPayableReq premiumPayableReq) {
		return this.bffQryRequestService.getPremiumPayable(premiumPayableReq);
	}
	
	@Operation(summary = "This is to fetch financial years based on acctOpening Date")
	@ApiResponses({@ApiResponse(responseCode = "200", description = "This is to fetch financial years based on acctOpening Date", content = {@Content(schema = @Schema(implementation = FinancialYearsResp.class))}), 
		@ApiResponse(responseCode = "400", description = "Data not retrived", content = {@Content(schema = @Schema(implementation = ErrorResponse.class))}),
		@ApiResponse(responseCode = "404", description = "Data not retrived", content = {@Content(schema = @Schema(implementation = ErrorResponse.class))}), 
		@ApiResponse(responseCode = "500", description = "Server not responded", content = {@Content(schema = @Schema(implementation = ErrorResponse.class))})})
	@PostMapping(value = {"getFinancialYears"}, produces = {"application/json"})
//	@ValidateDbpSchema(groupId = "com.ubi.dbp.investment",artifactId = "web_invst_apy_api_v1_getFinancialYears")
	public Mono<FinancialYearsResp> getFinancialYears(@RequestBody FinancialYearReq financialYearReq) {
		return this.bffQryRequestService.getFinancialYears(financialYearReq);
	}
}
