package com.ubi.dbp.investment.apy.asst.bff.service;

import com.ubi.dbp.investment.apy.asst.bff.dto.OpenResponse;
import com.ubi.dbp.investment.apy.asst.bff.dto.SaveResponse;
import com.ubi.dbp.investment.apy.asst.bff.model.OpenSsaReq;
import com.ubi.dbp.investment.apy.asst.bff.model.SaveSsaReq;

import reactor.core.publisher.Mono;

public interface InvestmentBFFApyCmdService {
	public Mono<SaveResponse> saveApy(SaveSsaReq saveReq);
	public Mono<OpenResponse> openApy(OpenSsaReq openReq);
//	public Mono<OpenResponse> makeContribution(ContributionReq contributionDetails);
//	public Mono<PaymentStatusResp> makeContributionBlock(ContributionReq contributionDetails);
}