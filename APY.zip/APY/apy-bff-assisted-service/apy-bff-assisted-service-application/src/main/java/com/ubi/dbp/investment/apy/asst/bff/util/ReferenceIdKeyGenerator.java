package com.ubi.dbp.investment.apy.asst.bff.util;

import java.util.UUID;

public class ReferenceIdKeyGenerator {
	
	public static String generateKey(String firstChars, String id, String opType, String channel) {
		return firstChars +":" + id + "-" + opType + "-" + channel;
	}
	
	public static String guid() {
		return UUID.randomUUID().toString();
	}

	public static String generateKey(String firstChars, String id, String opType) {
		return firstChars +":" + id + "-" + opType;
	}

	public static String generateKey(String firstChars, String cif, String string2, String journeyName,
			String subJourneyName) {
		
		return firstChars +":" + cif + "-" + string2 + "-" + journeyName;
	}
}
