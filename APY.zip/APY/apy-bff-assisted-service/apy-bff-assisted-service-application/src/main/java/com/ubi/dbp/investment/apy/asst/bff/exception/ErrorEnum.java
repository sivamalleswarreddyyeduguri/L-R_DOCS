package com.ubi.dbp.investment.apy.asst.bff.exception;

public enum ErrorEnum {

    CUST_NOT_FOUND("CUST_NOT_FOUND", "Customer not found."),
    CUST_NOT_INIT("CUST_NOT_INIT", "Customer id is not initialized (empty)."),
    CUST_NOT_AVAILABLE("CUST_NOT_AVAILABLE", "Customer id is not initialized (empty)."),
    CONSTRAINT_VIOLATION("CONSTRAINT_VIOLATION","Request could not be processed due to a constraint violation"),
    NO_APPS_FORM_NUM("NO_APPS_FORM_NUM", "Application form number is empty or invalid"),
    ACCT_NOT_INIT("ACCT_NOT_INIT", "ACCOUNT is not initialized."),
	NO_REQUEST_BODY("NO_REQUEST_BODY", "Request body is required for this operation"),
    ACCT_NOT_AVAILABLE("ACCT_NOT_AVAILABLE", "ACCOUNT is not available or invalid."),
    NO_ACCT_NUM("NO_ACCT_NUM","Account Number is empty or invalid"),
    NO_REF_NUM("NO_REF_NUM","TransReference number is empty or invalid"),
    NOT_VALID_INPUT("NOT_VALID_INPUT","No valid response body found"),
    NO_TXN_ID("NO_TXN_ID","Transaction Id is empty or invalid"),
    NO_START_DATE("NO_START_DATE","Start Date is empty or invalid"),
    NO_END_DATE("NO_END_DATE","End Date is empty or invalid"),
    NOT_VALID_SCHEMA("NOT_VALID_SCHEMA","Not Valid Input Schema"),
    NO_APY_TYPE("NO_APY_TYPE","Type Should only be Apy"),
    NOT_VALID_AMT("NOT_VALID_AMT","Amount Entered is not Valid")
    ;
    
    private final String code;
    private final String message;
    private ErrorEnum(String code, String message) {
        this.code = code;
        this.message = message;
    }
    public String getMessage() {
        return message;
    }
    public String getCode() {
        return code;
    }
    @Override
    public String toString() {
        return code + ": " + message;
    }
}
