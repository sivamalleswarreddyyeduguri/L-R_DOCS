package com.ubi.dbp.investment.apy.asst.bff.service;

import com.ubi.dbp.investment.apy.asst.bff.dto.ApyAccountResp;
import com.ubi.dbp.investment.apy.asst.bff.dto.ApyStatusResponse;
import com.ubi.dbp.investment.apy.asst.bff.dto.EmailResponse;
import com.ubi.dbp.investment.apy.asst.bff.dto.ExistingAccountsResp;
import com.ubi.dbp.investment.apy.asst.bff.dto.FinancialYearsResp;
import com.ubi.dbp.investment.apy.asst.bff.dto.InvestmentAccountsResp;
import com.ubi.dbp.investment.apy.asst.bff.dto.PDFDownloaderDTO;
import com.ubi.dbp.investment.apy.asst.bff.dto.PremiumPayableResp;
import com.ubi.dbp.investment.apy.asst.bff.dto.SsaDetailsResp;
import com.ubi.dbp.investment.apy.asst.bff.dto.TransactionDetailsResp;
import com.ubi.dbp.investment.apy.asst.bff.model.ApyAccReq;
import com.ubi.dbp.investment.apy.asst.bff.model.ApyDetailsReq;
import com.ubi.dbp.investment.apy.asst.bff.model.ExistingAccountReq;
import com.ubi.dbp.investment.apy.asst.bff.model.FinancialYearReq;
import com.ubi.dbp.investment.apy.asst.bff.model.PremiumPayableReq;
import com.ubi.dbp.investment.apy.asst.bff.model.StatementReq;
import com.ubi.dbp.investment.apy.asst.bff.model.TransactionReq;

import reactor.core.publisher.Mono;

public interface InvestmentBFFApyQryService {
	
	public Mono<TransactionDetailsResp> getApyTransactions(TransactionReq transactionReq );
	
	public Mono<PDFDownloaderDTO> downloadStatement(StatementReq pdfRequest);

	public Mono<EmailResponse> emailStatement(StatementReq emailRes);
	
	public Mono<ApyStatusResponse> getApyStatus(ApyDetailsReq ssaStatusReq);
	
	public Mono<ApyAccountResp> getApyAccountDetails(ApyAccReq accReq);

	public Mono<SsaDetailsResp> getApyDetailsToResume(ApyDetailsReq detailReq);

	public Mono<ExistingAccountsResp> checkExistingAccounts(ExistingAccountReq existingReq);

	public Mono<InvestmentAccountsResp> getInvestmentAccounts(ExistingAccountReq existingReq);

	public Mono<PremiumPayableResp> getPremiumPayable(PremiumPayableReq premiumPayableReq);

	public Mono<FinancialYearsResp> getFinancialYears(FinancialYearReq financialYearReq);
	
//	public Mono<FileData> getSSATermsAndCondition(TAndCRequest tAndCRequest);
	
}