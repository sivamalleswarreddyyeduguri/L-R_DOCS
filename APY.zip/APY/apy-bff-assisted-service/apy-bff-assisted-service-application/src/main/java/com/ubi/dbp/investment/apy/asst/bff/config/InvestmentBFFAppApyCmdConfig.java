package com.ubi.dbp.investment.apy.asst.bff.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import lombok.Getter;

@Configuration
@Getter
public class InvestmentBFFAppApyCmdConfig {
	@Value("${apy.command.service.base.url}")
	public String apyCmdSvcBaseUrl;
	
	@Value("${apy.command.service.investment.path}")
	public String apyCmdInvestmentPath;
	
	@Value("${apy.command.service.apy.save}")
	private String saveApy;
	
	@Value("${apy.command.service.apy.open}")
	private String openApy;

	

	
}
