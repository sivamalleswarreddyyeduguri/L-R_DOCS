package com.ubi.dbp.investment.apy.asst.bff.exception;

import dbp.framework.common.domain.exception.DomainException;

public class InvestmentException extends DomainException {

    private static final long serialVersionUID = -8004702236911760231L;
    public InvestmentException(ErrorEnum error) {
        super(error.getCode(),error.getMessage());
    }
    public InvestmentException(ErrorEnum error, Object... values) {
        super(error.getCode(),
                String.format(error.getMessage(),values));
    }
    
    public InvestmentException(String error) {
        super(error, error);
    }

}
