package com.ubi.dbp.investment.apy.asst.bff.util;

import java.time.Instant;
import java.time.LocalDate;

import org.springframework.boot.autoconfigure.gson.GsonBuilderCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class GsonConfiguration {

	@Bean
	public GsonBuilderCustomizer typeAdapterRegistration() {
		return builder -> {
			builder.registerTypeAdapter(LocalDate.class, new LocalDateTypeAdapter())
				   . registerTypeAdapter(Instant.class, new InstantTypeAdapter());
		};
	}
}