//package com.ubi.dbp.investment.apy.asst.bff.test;
//
//import static org.assertj.core.api.Assertions.assertThatExceptionOfType;
//import static org.assertj.core.api.Assertions.assertThatIllegalArgumentException;
//import static org.junit.Assert.assertNotNull;
//import static org.mockito.ArgumentMatchers.any;
//import static org.mockito.ArgumentMatchers.anyMap;
//import static org.mockito.ArgumentMatchers.anyString;
//import static org.mockito.Mockito.when;
//
//import java.lang.reflect.Type;
//
//import org.apache.hc.core5.http.io.entity.StringEntity;
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.junit.jupiter.MockitoExtension;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.boot.test.mock.mockito.MockBean;
//import org.springframework.test.context.junit.jupiter.SpringExtension;
//
//import com.fasterxml.jackson.core.type.TypeReference;
//import com.ubi.dbp.investment.apy.bff.service.CacheService;
//import com.ubi.dbp.investment.apy.bff.service.AbsCommonService.CallType;
//import com.ubi.dbp.investment.apy.bff.service.impl.CommonService;
//import com.ubi.dbp.investment.apy.bff.util.JsonUtils;
//import com.ubi.dbp.investment.ssa.bff.dto.FileData;
//
//import dbp.framework.proxy.common.client.DbpHttpClient;
//
//@ExtendWith(SpringExtension.class)
////@SpringBootTest
//public class CommonServiceTest {
//	@Mock
//	private DbpHttpClient mockDbpHttpClient;
//	@Mock
//	CacheService cacheServiceMock ;
//	@InjectMocks
//	CommonService commonService = new CommonService(cacheServiceMock, mockDbpHttpClient);
//
//	FileData data = null;
//	String response = "{\"fileName\":\"test.pdf\",\"data\":\"asdasdadsasd\"}";
//	
//	@Test
//	public void testNonCacheExecutePostRequest() {
//		String req = "";
//		when(mockDbpHttpClient.executePostRequest(any(), anyMap(), any())).thenReturn(response);
//		FileData resp = commonService.getData("test-key", "url", req, FileData.class, CallType.POST, false);
//		assertNotNull(resp);
//	}
//	
//	
//	@Test
//	public void testCacheWithNullDataExecutePostRequest() {
//		String req = "";
//		when(mockDbpHttpClient.executePostRequest(any(), anyMap(), any())).thenReturn(response);
//		when(cacheServiceMock.getFromCache(anyString(), any())).thenReturn(null);
//		FileData resp = commonService.getData("test-key", "url", req, FileData.class, CallType.POST, true);
//		assertNotNull(resp);
//	}
//	
//	@Test
//	public void testCacheWithDataExecutePostRequest() {
//		String req = "";
//		when(mockDbpHttpClient.executePostRequest(any(), anyMap(), any())).thenReturn(response);
//		data = new FileData("myfile.pdf", "ASDASDKJKJDKS");
//		when(cacheServiceMock.getFromCache(anyString(), any())).thenReturn(data);
//		FileData resp = commonService.getData("test-key", "url", req, FileData.class, CallType.POST, true);
//		assertNotNull(resp);
//	}
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	@Test
//	public void testNonCacheExecutePostRequestWithType() {
//		String req = "";
//		when(mockDbpHttpClient.executePostRequest(any(), anyMap(), any())).thenReturn(response);
//		FileData resp = commonService.getData("test-key", "url", req, new TypeReference<FileData>(){}.getType(), CallType.POST, false);
//		assertNotNull(resp);
//	}
//	
//	
//	@Test
//	public void testCacheWithNullDataExecutePostRequestWithType() {
//		String req = "";
//		when(mockDbpHttpClient.executePostRequest(any(), anyMap(), any())).thenReturn(response);
//		when(cacheServiceMock.getFromCache(anyString(), any())).thenReturn(null);
//		FileData resp = commonService.getData("test-key", "url", req, new TypeReference<FileData>(){}.getType(), CallType.POST, true);
//		assertNotNull(resp);
//	}
//	
//	@Test
//	public void testCacheWithDataExecutePostRequestWithType() {
//		String req = "";
//		when(mockDbpHttpClient.executePostRequest(any(), anyMap(), any())).thenReturn(response);
//		data = new FileData("myfile.pdf", "ASDASDKJKJDKS");
//		//Type type = new TypeReference<FileData>(){}.getType();
//		when(cacheServiceMock.getFromCache(anyString(), any())).thenReturn(data);
//		FileData resp = commonService.getData("test-key", "url", req, new TypeReference<FileData>(){}.getType(), CallType.POST, true);
//		assertNotNull(resp);
//	}
//	
//	@Test
//	public void testCacheWithRunTimeException() {
//		try {
//		String req = "";
//		when(mockDbpHttpClient.executePostRequest(any(), anyMap(), any())).thenReturn(response);
//		data = new FileData("myfile.pdf", "ASDASDKJKJDKS");
//		when(cacheServiceMock.getFromCache(anyString(), any())).thenReturn(data);
//		FileData resp = commonService.getData("test-key", "url", req, new TypeReference<FileData>(){}.getType(), null, true);
//		}catch(Exception e) {
//			assertThatExceptionOfType(RuntimeException.class);
//		}
//	}
//	
//
//}
