//package com.ubi.dbp.investment.apy.asst.bff.test;
//
//import static org.mockito.Mockito.reset;
//import static org.mockito.Mockito.verify;
//import static org.mockito.Mockito.when;
//
//import java.math.BigDecimal;
//import java.util.ArrayList;
//import java.util.Arrays;
//import java.util.List;
//
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.test.context.junit.jupiter.SpringExtension;
//
//import com.ubi.dbp.investment.apy.bff.controller.InvestmentCmdController;
//import com.ubi.dbp.investment.apy.bff.service.InvestmentBFFApyCmdService;
//import com.ubi.dbp.investment.ssa.bff.dto.DocumentEnt;
//import com.ubi.dbp.investment.ssa.bff.dto.OpenResponse;
//import com.ubi.dbp.investment.ssa.bff.dto.PaymentStatusResp;
//import com.ubi.dbp.investment.ssa.bff.dto.RemoveResp;
//import com.ubi.dbp.investment.ssa.bff.dto.SaveResponse;
//import com.ubi.dbp.investment.ssa.bff.dto.SsaDocument;
//import com.ubi.dbp.investment.ssa.bff.dto.UploadResp;
//import com.ubi.dbp.investment.ssa.bff.model.AddressDetails;
//import com.ubi.dbp.investment.ssa.bff.model.BankInfo;
//import com.ubi.dbp.investment.ssa.bff.model.BeneficiaryDetails;
//import com.ubi.dbp.investment.ssa.bff.model.BeneficiaryDetailsForSave;
//import com.ubi.dbp.investment.ssa.bff.model.ContactDetails;
//import com.ubi.dbp.investment.ssa.bff.model.ContactDetailsForSave;
//import com.ubi.dbp.investment.ssa.bff.model.ContributionDetails;
//import com.ubi.dbp.investment.ssa.bff.model.ContributionReq;
//import com.ubi.dbp.investment.ssa.bff.model.CustomerInfo;
//import com.ubi.dbp.investment.ssa.bff.model.DeclarationInfo;
//import com.ubi.dbp.investment.ssa.bff.model.DocumentReq;
//import com.ubi.dbp.investment.ssa.bff.model.Documents;
//import com.ubi.dbp.investment.ssa.bff.model.OpenSsaReq;
//import com.ubi.dbp.investment.ssa.bff.model.SaveSsaReq;
//import com.ubi.dbp.investment.ssa.bff.model.SourceInfo;
//import com.ubi.dbp.investment.ssa.bff.model.UploadReq;
//import com.ubi.dbp.investment.ssa.model.SsaResponse;
//
//import reactor.core.publisher.Mono;
//
//@ExtendWith(SpringExtension.class)
//@SpringBootTest
//public class InvestmentCmdControllerTest {
//	
//	@InjectMocks
//	InvestmentCmdController investmentCmdControllerUnderTest;
//	
//	@Mock
//	InvestmentBFFApyCmdService bffCmdRequestService;
//	
//	@BeforeEach
//	void setUp() {
//		SaveSsaReq saveRequest= new SaveSsaReq();
//		OpenSsaReq openRequest= new OpenSsaReq();
//		ContributionReq contributionReq = new ContributionReq();
//		SsaResponse ssaResponse=new SsaResponse();
//		
////		saveRequest
//		saveRequest.setApplNum("2023122100001");
//		saveRequest.setCif("900807110");
//		SourceInfo sourceInfo = new SourceInfo();
//		sourceInfo.setAcctNum("799002010000005");
//		saveRequest.setSource(sourceInfo);
//		BankInfo bankDetails = new BankInfo();
//		bankDetails.setBranchId("BK001");
//		bankDetails.setBranchSolId("0010");
//		AddressDetails address = new AddressDetails();
//		address.setPinCode("400049");
//		address.setAddrLine1("New medeline road");
//		address.setAddrLine2("Opp BKC drive");
//		address.setAddrLine3("Bandra");
//		address.setCityCode("MUMBA");
//		address.setStateCode("MH");
//		bankDetails.setAddress(address);
//		saveRequest.setBankInfo(bankDetails);
//		CustomerInfo customerInfo = new CustomerInfo();
//		customerInfo.setCif("626004728");
//		saveRequest.setCustomer(customerInfo);
//		BeneficiaryDetailsForSave beneficiary= new BeneficiaryDetailsForSave();
//		beneficiary.setDob("2021-02-20");
//		beneficiary.setFname("Harper");
//		beneficiary.setLname("Smith");
//		beneficiary.setMname("J");
//		beneficiary.setRelShipId("Daughter");
//		ContactDetailsForSave contactInfo= new ContactDetailsForSave();
//		contactInfo.setPostalAddr(address);
//		beneficiary.setContactInfo(contactInfo);
//		saveRequest.setBeneficiary(beneficiary);
//		List<Documents> documents=new ArrayList<Documents>();
//		documents.add(new Documents("Birth_Cert.pdf","BirthCertificateDocumentCode","228394-33747392-009383"));
//		saveRequest.setDocuments(documents);
//		saveRequest.setChannel("DBP");
//		
//		//SSA Response
//		ssaResponse.setRelationWithChild("Daughter");
//		ssaResponse.setBirthType("FIRST");
//		
//		//openRequest
//		openRequest.setRqType("ACCT_OPEN");
//		openRequest.setCif("626004728");
//		openRequest.setApplNum("368068652608");
//		openRequest.setChannel("DBP");
//		openRequest.setBirthOrder("FIRST");
//		openRequest.setBirthType("SINGLE");
//		SourceInfo sourceDetails = new SourceInfo();
//		sourceDetails.setAcctNum("799002010000005");
//		CustomerInfo customerDetails = new CustomerInfo();
//		customerDetails.setCif("626004728");
//		openRequest.setCustomer(customerDetails);
//		BeneficiaryDetails beneficiaryForOpen= new BeneficiaryDetails();
//		beneficiaryForOpen.setDob("2021-02-20");
//		beneficiaryForOpen.setFname("Harper");
//		beneficiaryForOpen.setLname("Smith");
//		beneficiaryForOpen.setMname("J");
//		beneficiaryForOpen.setRelShipId("Daughter");
//		ContactDetails contactInfoForOpen= new ContactDetails();
//		contactInfoForOpen.setPostalAddr(address);
//		beneficiaryForOpen.setContactInfo(contactInfoForOpen);
//		openRequest.setBeneficiary(beneficiaryForOpen);
//		openRequest.setDocuments(documents);
//		List<String> declarationList=Arrays.asList("I hereby declare the info is correct","I am FATCA complaint", "Only one account is present for girl-child");
//		DeclarationInfo declarationDetails=new DeclarationInfo();
//		declarationDetails.setDeclarationText(declarationList);
////		declarationDetails.setAccepted(true);
//		openRequest.setDeclarationDetails(declarationDetails);
//		ContributionDetails investmentContribution=new ContributionDetails();
//		investmentContribution.setContribAmt(BigDecimal.valueOf(100050.0));
//		
////		make contribution
//		contributionReq.setReferenceNum(null);
//		contributionReq.setCif(null);
//		contributionReq.setSource(sourceDetails);
//		contributionReq.setCustomer(customerDetails);
//		contributionReq.setInvestmentContribution(investmentContribution);
//		
////		Upload & Remove Document 
//		UploadReq uploadReq = new UploadReq();
//		uploadReq.setCif("cif");
//		uploadReq.setApplNum("applNum");
//		DocumentReq docUploadReq = new DocumentReq();
//		docUploadReq.setContent("document Content");
//		docUploadReq.setDocCategory("Category");
//		docUploadReq.setDocTypeCode("Type");
//		docUploadReq.setFileTypeCode("fileType");
//		uploadReq.setDocUploadReq(docUploadReq);
//		
//		UploadResp resp = new UploadResp();
//		resp.setOpsStatus("SUCCESS");
//		resp.setApplicationFrmNum("applNum");
//		DocumentEnt documentEnt = new DocumentEnt();
//		SsaDocument document = new SsaDocument();
//		document.setName("name");
//		document.setDocRefNo("refNum");
//		document.setType("Type");
//		document.setUri("uri");
//		List<SsaDocument> documentList = new ArrayList<SsaDocument>();
//		documentList.add(document);
//		documentEnt.setDocuments(documentList);
//		resp.setEntity(documentEnt);
//		
//		RemoveResp removeResp = new RemoveResp();
//		removeResp.setOpsStatus("SUCCESS");
//		removeResp.setApplicationFrmNum("applNum");
////		contributionReq.set
//
//	}
//	@Test
//	void testSaveSsa() {
//		SaveSsaReq ssaReq = new SaveSsaReq();
//		SaveResponse response = new SaveResponse();
//		
//
//		when(bffCmdRequestService.saveSsa(ssaReq)).thenReturn(Mono.just(response));
//		Mono<SaveResponse> saveSsaResp = investmentCmdControllerUnderTest.saveSsa(ssaReq);
//		verify(bffCmdRequestService).saveSsa(ssaReq);
//		reset(bffCmdRequestService);
//	}
//	@Test
//	void testOpenSsa() {
//		OpenSsaReq openReq= new OpenSsaReq();
//		OpenResponse response = new OpenResponse();
//		when(bffCmdRequestService.openSsa(openReq)).thenReturn(Mono.just(response));
//		Mono<OpenResponse> openSsaResp = investmentCmdControllerUnderTest.openSsa(openReq);
//		verify(bffCmdRequestService).openSsa(openReq);
//		reset(bffCmdRequestService);
//	}
//	@Test
//	void testMakeContribution() {
//		ContributionReq contributionReq = new ContributionReq();
//		PaymentStatusResp response = new PaymentStatusResp();
//
//		when(bffCmdRequestService.makeContributionBlock(contributionReq)).thenReturn(Mono.just(response));
//		Mono<PaymentStatusResp> contributionResp = investmentCmdControllerUnderTest.makeContribution(contributionReq);
//		verify(bffCmdRequestService).makeContributionBlock(contributionReq);
//		reset(bffCmdRequestService);
//	}
//	
//	@Test
//	void testUploadDocuments() {
//		UploadReq uploadReq = new UploadReq();
//		UploadResp response = new UploadResp();
//		
//		when(bffCmdRequestService.uploadDocuments(uploadReq)).thenReturn(Mono.just(response));
//		Mono<UploadResp> uploadResp = investmentCmdControllerUnderTest.uploadDocuments(uploadReq);
//		verify(bffCmdRequestService).uploadDocuments(uploadReq);
//		reset(bffCmdRequestService);
//	}
//	
//	@Test
//	void testRemoveDocuments() {
//		UploadReq removeReq = new UploadReq();
//		RemoveResp response = new RemoveResp();
//		
//		when(bffCmdRequestService.removeDocument(removeReq)).thenReturn(Mono.just(response));
//		Mono<RemoveResp> removeResp = investmentCmdControllerUnderTest.removeDocument(removeReq);
//		verify(bffCmdRequestService).removeDocument(removeReq);
//		reset(bffCmdRequestService);
//	}
//}

