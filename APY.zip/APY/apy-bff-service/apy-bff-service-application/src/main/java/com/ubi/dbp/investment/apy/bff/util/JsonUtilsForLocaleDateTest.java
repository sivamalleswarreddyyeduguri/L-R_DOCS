package com.ubi.dbp.investment.apy.bff.util;
public class JsonUtilsForLocaleDateTest {
    public static void main(String[] args) {
        String json = "{\"date\":\"2023-11-25\",\"itemList\":[\"item1\",\"item2\",\"item3\"]}";
        MyObject myObject = JsonUtilsForLocaleDate.jsonToPojo(json, MyObject.class);

        System.out.println("Date: " + myObject.getDate());
        System.out.println("Item List: " + myObject.getItemList());
    }
}
