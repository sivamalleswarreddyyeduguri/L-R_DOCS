package com.ubi.dbp.investment.apy.bff.util;

public class ApyConst {

	public static enum InvestmentStatus {
		DRAFT, PENDING,
		COMPLETE, CLOSED, REJECTED,
		PENDING_APPROVAL, PENDING_CBS,
		PENDING_GBM
	}
}
