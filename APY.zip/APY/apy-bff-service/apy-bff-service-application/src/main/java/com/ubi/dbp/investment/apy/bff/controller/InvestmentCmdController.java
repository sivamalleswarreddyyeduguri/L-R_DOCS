package com.ubi.dbp.investment.apy.bff.controller;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

//import com.ubi.dbp.investment.apy.bff.dto.ApyOpenSaveStatusResp;
import com.ubi.dbp.investment.apy.bff.dto.OpenResponse;
import com.ubi.dbp.investment.apy.bff.dto.PaymentStatusResp;
import com.ubi.dbp.investment.apy.bff.dto.RemoveResp;
import com.ubi.dbp.investment.apy.bff.dto.SaveResponse;
import com.ubi.dbp.investment.apy.bff.dto.UploadResp;
import com.ubi.dbp.investment.apy.bff.model.ApyOpenSaveStatusResp;
import com.ubi.dbp.investment.apy.bff.model.ContributionReq;
import com.ubi.dbp.investment.apy.bff.model.OpenSsaReq;
import com.ubi.dbp.investment.apy.bff.model.SaveSsaReq;
import com.ubi.dbp.investment.apy.bff.model.UploadReq;
import com.ubi.dbp.investment.apy.bff.service.InvestmentBFFApyCmdService;

import dbp.framework.schema.validator.ValidateDbpSchema;
import dbp.framework.schema.validator.dbpbffabs.DbpAbstractBff;
import dbp.framework.support.exception.ErrorResponse;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/app/invst/apy/api/v1/")
@OpenAPIDefinition(info = @Info(title = "APIs", version = "1.0", description = "Documentation APIs v2.0"))
@Tag(name = "Apy BFF APIs", description = "Apy BFF APIs to perform various operation on Apy")
public class InvestmentCmdController extends DbpAbstractBff {

	private InvestmentBFFApyCmdService bffCmdRequestService;

	public InvestmentCmdController(InvestmentBFFApyCmdService bffCmdRequestService) {
		this.bffCmdRequestService = bffCmdRequestService;
	}


	@Operation(summary = "This is to save the SSA Details")
	@ApiResponses({@ApiResponse(responseCode = "200", description = "This is to Save Ssa Details", content = {@Content(schema = @Schema(implementation = ApyOpenSaveStatusResp.class))}),
		@ApiResponse(responseCode = "400", description = "Data not retrived", content = {@Content(schema = @Schema(implementation = ErrorResponse.class))}),
		@ApiResponse(responseCode = "404", description = "Data not retrived", content = {@Content(schema = @Schema(implementation = ErrorResponse.class))}),
		@ApiResponse(responseCode = "500", description = "Server not responded", content = {@Content(schema = @Schema(implementation = ErrorResponse.class))})})
	@ValidateDbpSchema(groupId = "com.ubi.dbp.investment",artifactId = "app_invst_ssa_api_v1_saveSsa")
	@PostMapping(value = {"saveSsa"}, produces = {"application/json"})
	public Mono<SaveResponse> saveSsa (@RequestBody SaveSsaReq saveSsaReq) {
		return this.bffCmdRequestService.saveApy(saveSsaReq);
	}

	@Operation(summary = "This is to Open SSA ")
	@ApiResponses({@ApiResponse(responseCode = "200", description = "This is to Open Ssa Account", content = {@Content(schema = @Schema(implementation = ApyOpenSaveStatusResp.class))}),
		@ApiResponse(responseCode = "400", description = "Data not retrived", content = {@Content(schema = @Schema(implementation = ErrorResponse.class))}),
		@ApiResponse(responseCode = "404", description = "Data not retrived", content = {@Content(schema = @Schema(implementation = ErrorResponse.class))}),
		@ApiResponse(responseCode = "500", description = "Server not responded", content = {@Content(schema = @Schema(implementation = ErrorResponse.class))})})
	@ValidateDbpSchema(groupId = "com.ubi.dbp.investment",artifactId = "app_invst_ssa_api_v1_openSsa")
	@PostMapping(value = {"openSsa"}, produces = {"application/json"})
	public Mono<OpenResponse> openSsa (@RequestBody OpenSsaReq openSsaReq) {
		return this.bffCmdRequestService.openApy(openSsaReq);
	}

}
