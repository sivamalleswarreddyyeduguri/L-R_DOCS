package com.ubi.dbp.investment.apy.bff.util;

import java.lang.reflect.Type;
import java.util.List;

import com.google.gson.reflect.TypeToken;

public class JsonUtilTest {
	
    public static void main(String[] args) {
        String json = "{\"name\":\"John\",\"age\":30,\"email\":\"john@example.com\"}";
        Person person = JsonUtils.jsonToPojo(json, Person.class);

        // Now 'person' contains the data from the JSON string
        System.out.println("Name: " + person.getName());
        System.out.println("Age: " + person.getAge());
        System.out.println("Email: " + person.getEmail());
        
        String jsonArray = "[{\"name\":\"John\",\"age\":30},{\"name\":\"Alice\",\"age\":25}]";
        Type type = new TypeToken<List<Person>>(){}.getType();
        List<Person> people = JsonUtils.jsonToPojo(jsonArray, type);
        System.out.println("====");
        for (Person person1 : people) {
            System.out.println("Name: " + person1.getName());
            System.out.println("Age: " + person1.getAge());
            System.out.println("====");
        }
    }
}