package com.ubi.dbp.investment.apy.bff.service.impl;


import java.io.IOException;
import java.io.InputStream;
import java.util.Base64;

import com.ubi.dbp.investment.apy.bff.dto.*;
import com.ubi.dbp.investment.apy.bff.model.*;
import io.micrometer.common.util.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.ubi.dbp.investment.apy.bff.config.InvestmentBFFAppApyQryConfig;
import com.ubi.dbp.investment.apy.bff.exception.ErrorEnum;
import com.ubi.dbp.investment.apy.bff.exception.InvestmentException;
import com.ubi.dbp.investment.apy.bff.service.AbsCommonService.CallType;
import com.ubi.dbp.investment.apy.bff.service.InvestmentBFFApyQryService;

import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

@Service
//@Slf4j
public class InvestmentBFFApyQryServiceImpl implements InvestmentBFFApyQryService {

	private static final Logger log = LoggerFactory.getLogger(InvestmentBFFApyQryServiceImpl.class);
	private InvestmentBFFAppApyQryConfig investBFFAppConfig;
	private CommonService commonUtil;
	private static FileData apyFileData = null;
	public InvestmentBFFApyQryServiceImpl(InvestmentBFFAppApyQryConfig investBFFAppConfig, CommonService commonUtil) {
		this.investBFFAppConfig = investBFFAppConfig;
		this.commonUtil = commonUtil;
	}

	@Override
	public Mono<TransactionDetailsResp> getApyTransactions(TransactionReq transactionReq) {
		return Mono.fromSupplier(() -> {
			return commonUtil.getData(null,
					investBFFAppConfig.getApyQrySvcBaseUrl() + investBFFAppConfig.getApyQryInvestmentPath()
							+ investBFFAppConfig.getApyTransactions(),
					transactionReq, TransactionDetailsResp.class, CallType.POST, false);
		});
	}

	@Override
	public Mono<PDFDownloaderDTO> downloadStatement(StatementReq pdfRequest) {
		return Mono.fromSupplier(() -> {
			return commonUtil.getData(null,
					investBFFAppConfig.getApyQrySvcBaseUrl() + investBFFAppConfig.getApyQryInvestmentPath()
							+ investBFFAppConfig.getApyStatement(),
					pdfRequest, PDFDownloaderDTO.class, CallType.POST, false);
		});
	}

	@Override
	public Mono<EmailResponse> emailStatement(StatementReq emailRes) {
		return Mono.fromSupplier(() -> {
			return commonUtil.getData(null,
					investBFFAppConfig.getApyQrySvcBaseUrl() + investBFFAppConfig.getApyQryInvestmentPath()
							+ investBFFAppConfig.getApyEmailStatement(),
					emailRes, EmailResponse.class, CallType.POST, false);
		});
	}

	@Override
	public Mono<ApyStatusResponse> getApyStatus(ExistingAccountReq request) {
		return Mono.fromSupplier(() -> {
			return commonUtil.getData(null,
					investBFFAppConfig.getApyQrySvcBaseUrl() + investBFFAppConfig.getApyQryInvestmentPath()
							+ investBFFAppConfig.getApyStatus(),
					request, ApyStatusResponse.class, CallType.POST, false);
		});	}


	@Override
	public Mono<InvestmentAccountApy> getApyAccountDetails(ApyAccReq accReq) {
		return Mono.fromSupplier(() -> {
			return commonUtil.getData(accReq.getCif() + "_" + accReq.getSource().getAcctNum() + "_" + new Object() {
			}.getClass().getEnclosingMethod().getName(),
					investBFFAppConfig.getApyQrySvcBaseUrl() + investBFFAppConfig.getApyQryInvestmentPath()
							+ investBFFAppConfig.getApyAccountDetails(),
					accReq, InvestmentAccountApy.class, CallType.POST, false);
		});
	}

	@Override
	public Mono<InvestmentAccountApy> getApyDetailsToResume(ApyDetailsReq detailReq) {
		return Mono.fromSupplier(() -> {
			return commonUtil.getData(null,investBFFAppConfig.getApyQrySvcBaseUrl() + investBFFAppConfig.getApyQryInvestmentPath()
							+ investBFFAppConfig.getApyDetailsToResume(),
					detailReq, InvestmentAccountApy.class, CallType.POST, false);
		});
	}


	@Override
	public Mono<GenericResponse> checkExistingAccounts(ApyRequest request) {
		if (StringUtils.isBlank(request.getCif())) {
			throw new InvestmentException(ErrorEnum.CUST_NOT_INIT);
		}
		log.info("Request {}",request);
		return Mono.fromSupplier(() -> {
			return commonUtil.getData(null,
					investBFFAppConfig.getApyQrySvcBaseUrl() + investBFFAppConfig.getApyQryInvestmentPath()
							+ investBFFAppConfig.getApyExistingAccounts(),
					request, GenericResponse.class, CallType.POST, false);
		});
	}

	@Override
	public Mono<InvestmentAccountsResp> getInvestmentAccounts(ExistingAccountReq existingReq) {
		if (StringUtils.isBlank(existingReq.getCif())) {
			throw new InvestmentException(ErrorEnum.CUST_NOT_INIT);
		}
		Mono<ApyResponse> response= Mono.fromSupplier(() -> {
			return commonUtil.getData(existingReq.getCif() + "_" + new Object() {
			}.getClass().getEnclosingMethod().getName(),
					investBFFAppConfig.getApyQrySvcBaseUrl() + investBFFAppConfig.getApyQryInvestmentPath()
							+ investBFFAppConfig.getInvestmentAccounts(),
					existingReq, ApyResponse.class, CallType.POST, false);
		});
		return response.flatMap(apyResponse -> {
			InvestmentAccountsResp resp = new InvestmentAccountsResp();
			// Assuming you have getters and setters in ApyResponse and InvestmentAccountsResp
			//resp.setAcctBal(apyResponse.getInvestmentContribution().getAmount());
			resp.setCustomerName(apyResponse.getAccts().get(0).getName());
			resp.setPran(apyResponse.getPranNum());
			resp.setCif(apyResponse.getCif());
			return Mono.just(resp);
		});
	}

	@Override
	public Mono<PremiumPayableResp> getPremiumPayable(PremiumPayableReq premiumPayableReq) {
		return Mono.fromSupplier(() -> {
			return commonUtil.getData(null,
					investBFFAppConfig.getApyQrySvcBaseUrl() + investBFFAppConfig.getApyQryInvestmentPath()
							+ investBFFAppConfig.getPremiumPayable(),
							premiumPayableReq, PremiumPayableResp.class, CallType.POST, false);
		});
	}

	@Override
	public Mono<FinancialYearsResp> getFinancialYears(FinancialYearReq financialYearReq) {
		return Mono.fromSupplier(() -> {
			return commonUtil.getData(null,
					investBFFAppConfig.getApyQrySvcBaseUrl() + investBFFAppConfig.getApyQryInvestmentPath()
							+ investBFFAppConfig.getFinancialYears(),
							financialYearReq, FinancialYearsResp.class, CallType.POST, false);
		});
	}



	@Override
	public Mono<FileData> getApyTermsAndCondition(TAndCRequest tAndCRequest) {
		if (tAndCRequest != null && tAndCRequest.getTandCType().equalsIgnoreCase("APY") && apyFileData != null) {
			log.info("apyFileData not null...");
			return Mono.just(apyFileData);
		} else if (tAndCRequest.getTandCType().equalsIgnoreCase("APY")) {
			log.info("initially apyFileData null...");
			try {
				log.info("Reading data from pdf file...");
				InputStream inputStream = this.getClass().getClassLoader()
						.getResourceAsStream(investBFFAppConfig.getTermsAndConditionforApy());
				if (inputStream == null) {
					throw new IOException("File not found " + investBFFAppConfig.getTermsAndConditionforApy());
				}

				byte[] pdfBytes = inputStream.readAllBytes();
				log.info("Saving data in apyFileData...");
				apyFileData = new FileData(tAndCRequest.getTandCType().toUpperCase() + "_T&C" + ".pdf",
						Base64.getEncoder().encodeToString(pdfBytes));
				return Mono.just(apyFileData);
			} catch (Exception e) {
				log.error("some exception to process request", e.getMessage());
			}
		}
		throw new InvestmentException(ErrorEnum.NO_APY_TYPE);
	}

}
