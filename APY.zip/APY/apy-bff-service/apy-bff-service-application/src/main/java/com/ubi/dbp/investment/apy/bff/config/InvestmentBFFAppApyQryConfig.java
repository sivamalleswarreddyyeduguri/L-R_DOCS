 package com.ubi.dbp.investment.apy.bff.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import lombok.Getter;

@Configuration
@Getter
public class InvestmentBFFAppApyQryConfig {
	
	@Value("${apy.query.service.base.url}")
	public String apyQrySvcBaseUrl;
	
	@Value("${apy.query.service.investment.path}")
	public String apyQryInvestmentPath;
	
	@Value("${apy.query.service.apy.transaction}")
	private String apyTransactions;
	
	@Value("${apy.query.service.apy.statement.download}")
	private String apyStatement;
	
	@Value("${apy.query.service.apy.statement.email}")
	private String apyEmailStatement;
	
	@Value("${apy.query.service.apy.status}")
	private String apyStatus;
	
	@Value("${apy.query.service.apy.accountDetails}")
	public String apyAccountDetails;
	
	@Value("${apy.query.service.apy.detailsToResume}")
	private String apyDetailsToResume;
	
	@Value("${apy.query.service.apy.existingAccts}")
	private String apyExistingAccounts;

	@Value("${apy.query.service.apy.investmentAccounts}")
	private String investmentAccounts;
	
	@Value("${apy.query.service.apy.premiumPayable}")
	private String premiumPayable;
	
	@Value("${apy.query.service.apy.financialYears}")
	private String financialYears;
	
	@Value("${apy.path.tnc}")
	private String termsAndConditionforApy;
	
}
