package com.ubi.dbp.investment.apy.bff.util;

import lombok.Data;

@Data
public class Person {
    String name;
    int age; 
    String email; 
    
}
