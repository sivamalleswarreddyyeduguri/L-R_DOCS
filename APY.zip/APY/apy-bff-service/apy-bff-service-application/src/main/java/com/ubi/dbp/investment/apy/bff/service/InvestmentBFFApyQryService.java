package com.ubi.dbp.investment.apy.bff.service;

import com.ubi.dbp.investment.apy.bff.dto.*;
import com.ubi.dbp.investment.apy.bff.model.*;

import reactor.core.publisher.Mono;

public interface InvestmentBFFApyQryService {
	
	public Mono<TransactionDetailsResp> getApyTransactions(TransactionReq transactionReq );
	
	public Mono<PDFDownloaderDTO> downloadStatement(StatementReq pdfRequest);

	public Mono<EmailResponse> emailStatement(StatementReq emailRes);
	
	public Mono<ApyStatusResponse> getApyStatus(ExistingAccountReq request);
	
	public Mono<InvestmentAccountApy> getApyAccountDetails(ApyAccReq accReq);

	public Mono<InvestmentAccountApy> getApyDetailsToResume(ApyDetailsReq detailReq);

	public Mono<GenericResponse> checkExistingAccounts(ApyRequest apyRequest);

	public Mono<InvestmentAccountsResp> getInvestmentAccounts(ExistingAccountReq existingReq);

	public Mono<PremiumPayableResp> getPremiumPayable(PremiumPayableReq premiumPayableReq);

	public Mono<FinancialYearsResp> getFinancialYears(FinancialYearReq financialYearReq);

	Mono<FileData> getApyTermsAndCondition(TAndCRequest tAndCRequest);

//	public Mono<FileData> getSSATermsAndCondition(TAndCRequest tAndCRequest);
	
}