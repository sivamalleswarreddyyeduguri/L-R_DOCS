/*
 * package com.ubi.dbp.investment.ssa.bff.controller;
 * 
 * import java.util.Iterator; import java.util.List; import java.util.UUID;
 * import java.util.stream.Collectors;
 * 
 * import org.springframework.http.HttpHeaders; import
 * org.springframework.http.HttpStatus; import
 * org.springframework.http.MediaType; import
 * org.springframework.http.ResponseEntity; import
 * org.springframework.web.bind.MethodArgumentNotValidException; import
 * org.springframework.web.bind.annotation.ControllerAdvice; import
 * org.springframework.web.bind.annotation.ExceptionHandler; import
 * org.springframework.web.bind.annotation.ResponseBody; import
 * org.springframework.web.bind.annotation.ResponseStatus;
 * 
 * import com.google.gson.Gson; import
 * com.ubi.dbp.investment.ssa.bff.exception.InvestmentException;
 * 
 * import dbp.framework.common.application.exception.ErrorMessage; import
 * dbp.framework.common.application.exception.ErrorResponse; import
 * dbp.framework.common.application.handler.ErrorDTO; import
 * dbp.framework.proxy.common.client.DbpHttpClientException; import
 * jakarta.validation.ConstraintViolation; import
 * jakarta.validation.ConstraintViolationException; import
 * jakarta.validation.ValidationException; import lombok.extern.slf4j.Slf4j;
 * import reactor.core.publisher.Mono;
 * 
 * @Slf4j
 * 
 * @ControllerAdvice public class GlobalExceptionHandling {
 * 
 * @ExceptionHandler(DbpHttpClientException.class) public
 * Mono<ResponseEntity<String>>
 * handleDbpHttpClientException(DbpHttpClientException ex) {
 * log.info("error message from service {} ,{} ",
 * ex.getMessage(),ex.getHttpCode()); HttpHeaders headers = new HttpHeaders();
 * headers.setContentType(MediaType.APPLICATION_JSON); return Mono.just(new
 * ResponseEntity<String>(ex.getMessage(),headers,
 * HttpStatus.resolve(ex.getHttpCode()))); }
 * 
 * // @ResponseBody // @ExceptionHandler({InvestmentException.class,
 * MethodArgumentNotValidException.class})
 * // @ResponseStatus(HttpStatus.BAD_REQUEST) // public ErrorDTO
 * handleException(InvestmentException exception) { // ErrorDTO errorDTO; //
 * String exceptionMessage = exception.getMessage(); //
 * log.error(exceptionMessage, exception); // errorDTO =
 * ErrorDTO.builder().code(exception.getCode()).message(exceptionMessage) //
 * .build(); // return errorDTO; // }
 * 
 * 
 * @ExceptionHandler(ValidationException.class) public
 * Mono<ResponseEntity<ErrorResponse>>
 * handleRequestException(ValidationException ex) { String uid =
 * UUID.randomUUID().toString(); ErrorResponse errorResponse;
 * log.error("Validation exception occurred.....", ex); if (ex instanceof
 * ConstraintViolationException) { String violations =
 * extractViolationsFromException((ConstraintViolationException) ex);
 * ErrorMessage error =
 * ErrorMessage.builder().code(HttpStatus.BAD_REQUEST.name()).message(violations
 * ).build(); errorResponse =
 * ErrorResponse.builder().errorId(uid).errors(List.of(error)).build(); } else {
 * 
 * ErrorMessage error =
 * ErrorMessage.builder().code(HttpStatus.BAD_REQUEST.name())
 * .message(ex.getMessage()).build(); errorResponse =
 * ErrorResponse.builder().errorId(uid).errors(List.of(error)).build();
 * 
 * } return Mono.just(new ResponseEntity<>(errorResponse,
 * HttpStatus.BAD_REQUEST)); }
 * 
 * @ExceptionHandler({ InvestmentException.class,
 * MethodArgumentNotValidException.class }) public
 * Mono<ResponseEntity<ErrorResponse>>
 * handleInvalidMethodBodyException(InvestmentException exception) { return
 * buildErrorResponse(exception, HttpStatus.INTERNAL_SERVER_ERROR); }
 * 
 * 
 * 
 * // @ResponseBody // @ExceptionHandler(ValidationException.class)
 * // @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR) // public ErrorDTO
 * handleException(ValidationException exception) { // ErrorDTO errorDTO; //
 * String exceptionMessage = exception.getCause().getMessage(); //
 * log.error(exceptionMessage, exception); // errorDTO =
 * ErrorDTO.builder().code(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase()).
 * message(exceptionMessage) // .build(); // return errorDTO; // }
 * 
 * @ResponseBody
 * 
 * @ExceptionHandler(value = { Exception.class })
 * 
 * @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR) public ErrorDTO
 * handleException(Exception exception) { log.error(exception.getMessage(),
 * exception); return
 * ErrorDTO.builder().code(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase()).
 * message("Unexpected error!") .build(); }
 * 
 * private Mono<ResponseEntity<ErrorResponse>>
 * buildErrorResponse(InvestmentException exception, HttpStatus status) { String
 * uid = UUID.randomUUID().toString(); try { Gson gson = new Gson();
 * ErrorResponse error = gson.fromJson(exception.getMessage(),
 * ErrorResponse.class); return Mono.just(new ResponseEntity<>(error, status));
 * } catch (Exception e) { ErrorResponse errorResponse =
 * ErrorResponse.builder().errorId(uid) .errors(List.of(new
 * ErrorMessage(exception.getCode().toString(),
 * exception.getMessage()))).build(); return Mono.just(new
 * ResponseEntity<>(errorResponse, status)); } }
 * 
 * // private String extractViolationsFromException(ConstraintViolationException
 * validationException) { // return
 * validationException.getConstraintViolations().stream().map(
 * ConstraintViolation::getMessage) // .collect(Collectors.joining("--")); // }
 * 
 * private String extractViolationsFromException(ConstraintViolationException
 * validationException) {
 * log.info("extractViolationsFromException{}",validationException.getMessage())
 * ; for (Iterator iterator =
 * validationException.getConstraintViolations().iterator();
 * iterator.hasNext();) { String type = (String) iterator.next();
 * log.info(type);
 * 
 * }
 * 
 * return validationException.getConstraintViolations().stream().map(
 * ConstraintViolation::getMessage) .collect(Collectors.joining("--")); }
 * 
 * }
 */
//package com;

