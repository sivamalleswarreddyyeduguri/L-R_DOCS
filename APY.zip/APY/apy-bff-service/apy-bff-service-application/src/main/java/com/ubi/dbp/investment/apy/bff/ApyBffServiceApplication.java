package com.ubi.dbp.investment.apy.bff;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages = { "dbp.framework.proxy.common.client", "dbp.framework.schema.validator",
		"com.ubi.dbp.investment.apy.bff", "dbp.framework.schema" , "com.ubi.dbp.security.filter"})
public class ApyBffServiceApplication {

	public static void main(String[] args) {

		SpringApplication.run(ApyBffServiceApplication.class, args);
	}
}
