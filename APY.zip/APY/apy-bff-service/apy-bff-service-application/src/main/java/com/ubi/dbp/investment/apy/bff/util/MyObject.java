package com.ubi.dbp.investment.apy.bff.util;
import java.time.LocalDate;
import java.util.ArrayList;

public class MyObject {
    private LocalDate date;
    private ArrayList<String> itemList;

    // Getters and setters
    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public ArrayList<String> getItemList() {
        return itemList;
    }

    public void setItemList(ArrayList<String> itemList) {
        this.itemList = itemList;
    }
}
