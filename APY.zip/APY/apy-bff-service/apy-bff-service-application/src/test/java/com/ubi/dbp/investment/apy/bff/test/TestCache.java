//package com.ubi.dbp.investment.apy.bff.test;
//
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.test.context.junit.jupiter.SpringExtension;
//
//import com.fasterxml.jackson.core.type.TypeReference;
//import com.ubi.dbp.investment.apy.bff.service.CacheService;
//
//@ExtendWith(SpringExtension.class)
//@SpringBootTest
//public class TestCache {
//
//	@Autowired
//	private CacheService cacheService;
//	
//	//@Test
//	void testPutInCache() {
//		String response = "{\"data\":\"data\",\"key\":\"key\"}";
//		cacheService.putInCache("test_key", response);
//	}
//	
////	@Test
//	void testGetFromCache() {
//		//String response = "{\"data\":\"data\",\"key\":\"key\"}";
//		String resp = cacheService.getFromCache("test_key", String.class);
//		//assertNotNull(resp);
//	}
//	
////	@Test
//	void testGetFromCacheType() {
//		//String response = "{\"data\":\"data\",\"key\":\"key\"}";
//		String resp = cacheService.getFromCache("test_key", new TypeReference<String>(){}.getType());
//		//assertNotNull(resp);
//	}
//
//
//}
