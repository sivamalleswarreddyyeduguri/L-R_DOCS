//package com.ubi.dbp.investment.apy.bff.test;
//
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.junit.jupiter.api.Assertions.assertNotNull;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.test.context.TestPropertySource;
//
//import com.ubi.dbp.investment.apy.bff.config.InvestmentBFFAppApyDocConfig;
//
//@SpringBootTest
//@TestPropertySource(properties = {
//        "doc.store.base.url=http://test-doc-store-base-url",
//        "doc.store.service.path=/test-doc-store-path",
//        "doc.store.service.download=test-doc-store-download"
//})
//public class InvestmentBFFAppApyDocConfigTest {
//
//    @Autowired
//    private InvestmentBFFAppApyDocConfig config;
//
//    @Test
//    public void testDocStoreBaseUrl() {
//        assertEquals("http://test-doc-store-base-url", config.getDocStoreBaseUrl());
//    }
//
//    @Test
//    public void testDocStorePath() {
//        assertEquals("/test-doc-store-path", config.getDocStoreServicePath());
//    }
//
//    @Test
//    public void testDownload() {
//        assertEquals("test-doc-store-download", config.getDownload());
//    }
//
//    @Test
//    public void testNonNullValues() {
//        assertNotNull(config.getDocStoreBaseUrl());
//        assertNotNull(config.getDocStoreServicePath());
//        assertNotNull(config.getDownload());
//        
//    }
//}
