//package com.ubi.dbp.investment.apy.bff.test;
//
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.junit.jupiter.api.Assertions.assertNotNull;
//import static org.junit.jupiter.api.Assertions.assertThrows;
//import static org.junit.jupiter.api.Assertions.assertTrue;
//import static org.mockito.Mockito.when;
//
//import java.io.ByteArrayInputStream;
//import java.io.IOException;
//import java.io.InputStream;
//import java.math.BigDecimal;
//import java.nio.charset.StandardCharsets;
//import java.time.LocalDate;
//
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.Mockito;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.test.context.junit.jupiter.SpringExtension;
//
//import com.ubi.dbp.investment.apy.bff.config.InvestmentBFFAppApyDocConfig;
//import com.ubi.dbp.investment.apy.bff.config.InvestmentBFFAppApyQryConfig;
//import com.ubi.dbp.investment.apy.bff.exception.InvestmentException;
//import com.ubi.dbp.investment.apy.bff.service.CacheService;
//import com.ubi.dbp.investment.apy.bff.service.AbsCommonService.CallType;
//import com.ubi.dbp.investment.apy.bff.service.impl.CommonService;
//import com.ubi.dbp.investment.apy.bff.service.impl.InvestmentBFFApyQryServiceImpl;
//import com.ubi.dbp.investment.ssa.bff.dto.DownloadResp;
//import com.ubi.dbp.investment.ssa.bff.dto.EmailResponse;
//import com.ubi.dbp.investment.ssa.bff.dto.ExistingAccountsResp;
//import com.ubi.dbp.investment.ssa.bff.dto.FileData;
//import com.ubi.dbp.investment.ssa.bff.dto.InvestmentAccountsResp;
//import com.ubi.dbp.investment.ssa.bff.dto.PDFDownloaderDTO;
//import com.ubi.dbp.investment.ssa.bff.dto.PaymentStatusResp;
//import com.ubi.dbp.investment.ssa.bff.dto.SsaAccountRespDTO;
//import com.ubi.dbp.investment.ssa.bff.dto.SsaDetailsResp;
//import com.ubi.dbp.investment.ssa.bff.dto.SsaStatusResponseDTO;
//import com.ubi.dbp.investment.ssa.bff.dto.TransactionDetailsResp;
//import com.ubi.dbp.investment.ssa.bff.dto.ValidateAmountResp;
//import com.ubi.dbp.investment.ssa.bff.model.ContributionDetails;
//import com.ubi.dbp.investment.ssa.bff.model.DownloadReq;
//import com.ubi.dbp.investment.ssa.bff.model.EmailStatementReq;
//import com.ubi.dbp.investment.ssa.bff.model.ExistingAccountReq;
//import com.ubi.dbp.investment.ssa.bff.model.InvestmentContributionInfo;
//import com.ubi.dbp.investment.ssa.bff.model.PaymentStatusReq;
//import com.ubi.dbp.investment.ssa.bff.model.SourceInfo;
//import com.ubi.dbp.investment.ssa.bff.model.SsaAccReq;
//import com.ubi.dbp.investment.ssa.bff.model.SsaDetailsReq;
//import com.ubi.dbp.investment.ssa.bff.model.TAndCRequest;
//import com.ubi.dbp.investment.ssa.bff.model.TransactionReq;
//import com.ubi.dbp.investment.ssa.bff.model.ValidateReq;
//
//import dbp.framework.proxy.common.client.DbpHttpClient;
//import reactor.core.publisher.Mono;
//import reactor.test.StepVerifier;
//
//@ExtendWith(SpringExtension.class)
//@SpringBootTest
//public class InvestmentServiceTest {
//	@Mock
//	private DbpHttpClient mockDbpHttpClient;
//	@Mock
//	private InvestmentBFFAppApyQryConfig mockInvestBFFAppConfig;
//	@Mock
//	private InvestmentBFFAppApyDocConfig mockInvestmentDocConfig;
//	@Mock
//	CacheService cacheServiceMock;
//	@Mock
//	CommonService commonService;
//
//	@InjectMocks
//	InvestmentBFFApyQryServiceImpl bffServiceImplUnderTest;
//
////	private static FileData ssaFileData = null;
//	
//	@Test
//	public void testGetSSATransactions() {
//		// Mock data
//		TransactionReq transactionReq = new TransactionReq();
//		transactionReq.setAcctNum("1234567890");
//		TransactionDetailsResp expectedResponse = new TransactionDetailsResp();
//
//		// Mock behavior
//		Mockito.when(mockInvestBFFAppConfig.getSsaQrySvcBaseUrl())
//				.thenReturn("http://ssa-qry-svc-dev.apps.ubidev.ibmubi.local");
//		Mockito.when(mockInvestBFFAppConfig.getSsaQryInvestmentPath()).thenReturn("/ssa/api/v1");
//		Mockito.when(mockInvestBFFAppConfig.getSsaTransactions()).thenReturn("/getSSATransactions");
//		Mockito.when(commonService.getData(null,
//				"http://ssa-qry-svc-dev.apps.ubidev.ibmubi.local/ssa/api/v1/getSSATransactions", transactionReq,
//				TransactionDetailsResp.class, CallType.POST, false)).thenReturn(expectedResponse);
//
//
//		StepVerifier.create(bffServiceImplUnderTest.getSSATransactions(transactionReq)).expectNext(expectedResponse)
//				.verifyComplete();
//	}
//
//	@Test
//	void testGetSSATransactionsAcctNumBlank() {
//		// Setup
//		TransactionReq transactionReq = new TransactionReq("6576876875","", LocalDate.of(2023, 8, 20), LocalDate.of(2023, 12, 31));
//
//		Throwable exception = assertThrows(InvestmentException.class, () -> {
//
//			bffServiceImplUnderTest.getSSATransactions(transactionReq);
//		});
//
//		assertEquals("Account Number is empty or invalid", exception.getMessage());
//	}
//
//	@Test
//	void testDownloadStatement() {
//		EmailStatementReq statementReq = new EmailStatementReq();
//		statementReq.setCif("217867679");
//		statementReq.setAcctNum("1234567890");
//		PDFDownloaderDTO expectedResponse = new PDFDownloaderDTO();
//
//		// Mock behavior
//		Mockito.when(mockInvestBFFAppConfig.getSsaQrySvcBaseUrl())
//				.thenReturn("http://ssa-qry-svc-dev.apps.ubidev.ibmubi.local");
//		Mockito.when(mockInvestBFFAppConfig.getSsaQryInvestmentPath()).thenReturn("/ssa/api/v1");
//		Mockito.when(mockInvestBFFAppConfig.getDownloadStatement()).thenReturn("/downloadSSAStatement");
//		Mockito.when(commonService.getData(null,
//				"http://ssa-qry-svc-dev.apps.ubidev.ibmubi.local/ssa/api/v1/downloadSSAStatement", statementReq,
//				PDFDownloaderDTO.class, CallType.POST, false)).thenReturn(expectedResponse);
//
//		// Call the method
////		Mono<PDFDownloaderDTO> actualResponse = bffServiceImplUnderTest.downloadStatement(transactionReq);
//
////		assertEquals(expectedResponse, actualResponse.block());
//
//		StepVerifier.create(bffServiceImplUnderTest.downloadStatement(statementReq)).expectNext(expectedResponse)
//				.verifyComplete();
//	}
//
//	@Test
//	void testDownloadStatementAcctNumBlank() {
//		// Setup
//		EmailStatementReq statementReq = new EmailStatementReq("216576698", "", LocalDate.of(2023, 8, 20),
//				LocalDate.of(2023, 12, 31));
//
//		Throwable exception = assertThrows(InvestmentException.class, () -> {
//			bffServiceImplUnderTest.downloadStatement(statementReq);
//		});
//
//		assertEquals("Account Number is empty or invalid", exception.getMessage());
//	}
//
//	@Test
//	void testEmailStatement() {
//
//		EmailStatementReq emailStatementReq = new EmailStatementReq();
//		emailStatementReq.setCif("12343242432");
//		emailStatementReq.setAcctNum("34534223353");
//
//		EmailResponse expectedResponse = new EmailResponse();
//
//		// Mock behavior
//		Mockito.when(mockInvestBFFAppConfig.getSsaQrySvcBaseUrl())
//				.thenReturn("http://ssa-qry-svc-dev.apps.ubidev.ibmubi.local");
//		Mockito.when(mockInvestBFFAppConfig.getSsaQryInvestmentPath()).thenReturn("/ssa/api/v1");
//		Mockito.when(mockInvestBFFAppConfig.getEmailStatement()).thenReturn("/emailStatement");
//		Mockito.when(
//				commonService.getData(null, "http://ssa-qry-svc-dev.apps.ubidev.ibmubi.local/ssa/api/v1/emailStatement",
//						emailStatementReq, EmailResponse.class, CallType.POST, false))
//				.thenReturn(expectedResponse);
//
//		// Call the method
////		Mono<EmailResponse> actualResponse = bffServiceImplUnderTest.emailStatement(emailStatementReq);
//
////		assertEquals(expectedResponse, actualResponse.block());
//
//		StepVerifier.create(bffServiceImplUnderTest.emailStatement(emailStatementReq)).expectNext(expectedResponse)
//				.verifyComplete();
//	}
//
//	@Test
//	void testEmailStatementCIFBlank() {
//		EmailStatementReq emailStatementReq = new EmailStatementReq("", "117931100003703", LocalDate.of(2023, 8, 20),
//				LocalDate.of(2023, 12, 31));
//		Throwable exception = assertThrows(InvestmentException.class, () -> {
//
//			bffServiceImplUnderTest.emailStatement(emailStatementReq);
//		});
//
//		assertEquals("Customer id is not initialized (empty).", exception.getMessage());
//	}
//
//	@Test
//	void testEmailStatementAcctNumBlank() {
//		// Setup
//		EmailStatementReq emailStatementReq = new EmailStatementReq("04989529", "", LocalDate.of(2023, 8, 20),
//				LocalDate.of(2023, 12, 31));
//		Throwable exception = assertThrows(InvestmentException.class, () -> {
//
//			bffServiceImplUnderTest.emailStatement(emailStatementReq);
//		});
//
//		assertEquals("Account Number is empty or invalid", exception.getMessage());
//	}
//
//	@Test
//	void testSSACertificate() {
//		SsaAccReq ssaReq = new SsaAccReq();
//		ssaReq.setCif("121212132");
//		SourceInfo source = new SourceInfo();
//		source.setAcctNum("86876875857855");
//		ssaReq.setSource(source);
//
//		PDFDownloaderDTO expectedResponse = new PDFDownloaderDTO();
//
//		// Mock behavior
//		Mockito.when(mockInvestBFFAppConfig.getSsaQrySvcBaseUrl())
//				.thenReturn("http://ssa-qry-svc-dev.apps.ubidev.ibmubi.local");
//		Mockito.when(mockInvestBFFAppConfig.getSsaQryInvestmentPath()).thenReturn("/ssa/api/v1");
//		Mockito.when(mockInvestBFFAppConfig.getSsaCertificate()).thenReturn("/SSACertificate");
//		Mockito.when(
//				commonService.getData(null, "http://ssa-qry-svc-dev.apps.ubidev.ibmubi.local/ssa/api/v1/SSACertificate",
//						ssaReq, PDFDownloaderDTO.class, CallType.POST, false))
//				.thenReturn(expectedResponse);
//
//		// Call the method
////		Mono<PDFDownloaderDTO> actualResponse = bffServiceImplUnderTest.SSACertificate(ssaReq);
//
////		assertEquals(expectedResponse, actualResponse.block());
//
//		StepVerifier.create(bffServiceImplUnderTest.getSSACertificate(ssaReq)).expectNext(expectedResponse)
//				.verifyComplete();
//	}
//
//	@Test
//	void testSSACertificateCIFBlank() {
//		// Setup
//		SsaAccReq ssaReq = new SsaAccReq();
//		ssaReq.setCif("");
//		SourceInfo source = new SourceInfo();
//		source.setAcctNum("86876875857855");
//		ssaReq.setSource(source);
//
//		Throwable exception = assertThrows(InvestmentException.class, () -> {
//			bffServiceImplUnderTest.getSSACertificate(ssaReq);
//		});
//
//		assertEquals("Customer id is not initialized (empty).", exception.getMessage());
//	}
//
//	@Test
//	void testSSACertificateAcctNumBlank() {
//		// Setup
//		SsaAccReq ssaReq = new SsaAccReq();
//		ssaReq.setCif("121212132");
//		SourceInfo source = new SourceInfo();
//		source.setAcctNum("");
//		ssaReq.setSource(source);
//
//		Throwable exception = assertThrows(InvestmentException.class, () -> {
//			bffServiceImplUnderTest.getSSACertificate(ssaReq);
//		});
//
//		assertEquals("Account Number is empty or invalid", exception.getMessage());
//	}
//
//	@Test
//	void testSSAAcknowledgement() {
//		SsaDetailsReq ssaDetailsReq = new SsaDetailsReq("7865006", "190090");
//		PDFDownloaderDTO expectedResponse = new PDFDownloaderDTO();
//
//		// Mock behavior
//		Mockito.when(mockInvestBFFAppConfig.getSsaQrySvcBaseUrl())
//				.thenReturn("http://ssa-qry-svc-dev.apps.ubidev.ibmubi.local");
//		Mockito.when(mockInvestBFFAppConfig.getSsaQryInvestmentPath()).thenReturn("/ssa/api/v1");
//		Mockito.when(mockInvestBFFAppConfig.getSsaAcknowledgement()).thenReturn("/DownloadAcknowledgementLetter");
//		Mockito.when(commonService.getData(null,
//				"http://ssa-qry-svc-dev.apps.ubidev.ibmubi.local/ssa/api/v1/DownloadAcknowledgementLetter",
//				ssaDetailsReq, PDFDownloaderDTO.class, CallType.POST, false)).thenReturn(expectedResponse);
//
//		// Call the method
////		Mono<PDFDownloaderDTO> actualResponse = bffServiceImplUnderTest.SSAAcknowledgement(ssaDetailsReq);
////
////		assertEquals(expectedResponse, actualResponse.block());
//
//		StepVerifier.create(bffServiceImplUnderTest.getSSAAcknowledgement(ssaDetailsReq)).expectNext(expectedResponse)
//				.verifyComplete();
//	}
//
//	@Test
//	void testSSAAcknowledgementCIFBlank() {
//		// Setup
//		SsaDetailsReq ssaDetailsReq = new SsaDetailsReq("", "190090");
//
//		Throwable exception = assertThrows(InvestmentException.class, () -> {
//			bffServiceImplUnderTest.getSSAAcknowledgement(ssaDetailsReq);
//		});
//
//		assertEquals("Customer id is not initialized (empty).", exception.getMessage());
//	}
//
//	@Test
//	void testSSAAcknowledgementApplicationFrmNumBlank() {
//		// Setup
//		SsaDetailsReq ssaDetailsReq = new SsaDetailsReq("7865006", "");
//		Throwable exception = assertThrows(InvestmentException.class, () -> {
//			bffServiceImplUnderTest.getSSAAcknowledgement(ssaDetailsReq);
//		});
//
//		assertEquals("Application form number is empty or invalid", exception.getMessage());
//	}
//
//	@Test
//	void testGetSSAStatus() {
//
//		SsaDetailsReq ssaStatusReq = new SsaDetailsReq();
//		ssaStatusReq.setCif("12345");
//		ssaStatusReq.setApplicationFrmNum("67890");
//		SsaStatusResponseDTO expectedResponse = null;
//
//		// Mock behavior
//		Mockito.when(mockInvestBFFAppConfig.getSsaQrySvcBaseUrl())
//				.thenReturn("http://ssa-qry-svc-dev.apps.ubidev.ibmubi.local");
//		Mockito.when(mockInvestBFFAppConfig.getSsaQryInvestmentPath()).thenReturn("/ssa/api/v1");
//		Mockito.when(mockInvestBFFAppConfig.getSsaStatus()).thenReturn("/getSSAStatus");
//		Mockito.when(commonService
//				.getData(ssaStatusReq.getCif() + "_" + ssaStatusReq.getApplicationFrmNum() + "_" + new Object() {
//				}.getClass().getEnclosingMethod().getName(),
//						"http://ssa-qry-svc-dev.apps.ubidev.ibmubi.local/ssa/api/v1/getSSAStatus", ssaStatusReq,
//						SsaStatusResponseDTO.class, CallType.POST, false))
//				.thenReturn(expectedResponse);
//		// Call the method
//		Mono<SsaStatusResponseDTO> actualResponse = bffServiceImplUnderTest.getSSAStatus(ssaStatusReq);
//		assertEquals(expectedResponse, actualResponse.block());
//
//	}
//
//	@Test
//	void testGetSSAStatusCIFBlank() {
//		// Setup
//		SsaDetailsReq ssaDetailsReq = new SsaDetailsReq("", "190090");
//
//		Throwable exception = assertThrows(InvestmentException.class, () -> {
//			bffServiceImplUnderTest.getSSAStatus(ssaDetailsReq);
//		});
//
//		assertEquals("Customer id is not initialized (empty).", exception.getMessage());
//	}
//
//	@Test
//	void testGetSSAStatusApplicationFrmNumBlank() {
//		// Setup
//		SsaDetailsReq ssaDetailsReq = new SsaDetailsReq("7865006", "");
//
//		Throwable exception = assertThrows(InvestmentException.class, () -> {
//			bffServiceImplUnderTest.getSSAStatus(ssaDetailsReq);
//		});
//
//		assertEquals("Application form number is empty or invalid", exception.getMessage());
//	}
//
//	@Test
//	void testGetSSAAccountDetails() {
//		SsaAccReq accReq = new SsaAccReq();
//		accReq.setCif("121212132");
//		SourceInfo source = new SourceInfo();
//		source.setAcctNum("86876875857855");
//		accReq.setSource(source);
//
//		SsaAccountRespDTO expectedResponse = null;
//
//		// Mock behavior
//		Mockito.when(mockInvestBFFAppConfig.getSsaQrySvcBaseUrl())
//				.thenReturn("http://ssa-qry-svc-dev.apps.ubidev.ibmubi.local");
//		Mockito.when(mockInvestBFFAppConfig.getSsaQryInvestmentPath()).thenReturn("/ssa/api/v1");
//		Mockito.when(mockInvestBFFAppConfig.getSsaAccountDetails()).thenReturn("/getSSAAccountDetails");
//		Mockito.when(commonService.getData(null,
//				"http://ssa-qry-svc-dev.apps.ubidev.ibmubi.local/ssa/api/v1/getSSAAccountDetails", accReq,
//				SsaAccountRespDTO.class, CallType.POST, false)).thenReturn(expectedResponse);
//
//		// Call the method
//		Mono<SsaAccountRespDTO> actualResponse = bffServiceImplUnderTest.getSSAAccountDetails(accReq);
//		assertEquals(expectedResponse, actualResponse.block());
//
////		 StepVerifier.create(bffServiceImplUnderTest.getSSAAccountDetails(accReq))
////         .expectNext(expectedResponse)
////         .verifyComplete();
//	}
//
//	@Test
//	void testGetSSAAccountDetailsCIFBlank() {
//		// Setup
//		SsaAccReq accReq = new SsaAccReq();
//		accReq.setCif("");
//		SourceInfo source = new SourceInfo();
//		source.setAcctNum("86876875857855");
//		accReq.setSource(source);
//
//		Throwable exception = assertThrows(InvestmentException.class, () -> {
//			bffServiceImplUnderTest.getSSAAccountDetails(accReq);
//		});
//
//		assertEquals("Customer id is not initialized (empty).", exception.getMessage());
//	}
//
//	@Test
//	void testGetSSAAccountDetailsAccountNumberBlank() {
//		// Setup
//		SsaAccReq accReq = new SsaAccReq();
//		accReq.setCif("121212132");
//		SourceInfo source = new SourceInfo();
//		source.setAcctNum("");
//		accReq.setSource(source);
//
//		Throwable exception = assertThrows(InvestmentException.class, () -> {
//			bffServiceImplUnderTest.getSSAAccountDetails(accReq);
//		});
//
//		assertEquals("Account Number is empty or invalid", exception.getMessage());
//	}
//
//	@Test
//	void testGetSSADetailsToResume() {
//		SsaDetailsReq ssaDetailsReq = new SsaDetailsReq("12345", "12345678");
//		SsaDetailsResp expectedResponse = new SsaDetailsResp();
//		expectedResponse.setCif("12345");
//		expectedResponse.setApplNum("12345678");
//
//		// Mock behavior
//		Mockito.when(mockInvestBFFAppConfig.getSsaQrySvcBaseUrl())
//				.thenReturn("http://ssa-qry-svc-dev.apps.ubidev.ibmubi.local");
//		Mockito.when(mockInvestBFFAppConfig.getSsaQryInvestmentPath()).thenReturn("/ssa/api/v1");
//		Mockito.when(mockInvestBFFAppConfig.getSsaDetailsToResume()).thenReturn("/getSSADetailsToResume");
//		Mockito.when(commonService.getData(null,
//				"http://ssa-qry-svc-dev.apps.ubidev.ibmubi.local/ssa/api/v1/getSSADetailsToResume", ssaDetailsReq,
//				SsaDetailsResp.class, CallType.POST, false)).thenReturn(expectedResponse);
//
//		StepVerifier.create(bffServiceImplUnderTest.getSSADetailsToResume(ssaDetailsReq)).expectNext(expectedResponse)
//				.verifyComplete();
//	}
//
//	@Test
//	void testGetSSADetailsToResumeCIFBlank() {
//		// Setup
//		SsaDetailsReq ssaDetailsReq = new SsaDetailsReq("", "190090");
//
//		Throwable exception = assertThrows(InvestmentException.class, () -> {
//			bffServiceImplUnderTest.getSSADetailsToResume(ssaDetailsReq);
//		});
//
//		assertEquals("Customer id is not initialized (empty).", exception.getMessage());
//	}
//
//	@Test
//	void testGetSSADetailsToResumeApplicationFrmNumBlank() {
//		// Setup
//		SsaDetailsReq ssaDetailsReq = new SsaDetailsReq("7865006", "");
//
//		Throwable exception = assertThrows(InvestmentException.class, () -> {
//			bffServiceImplUnderTest.getSSADetailsToResume(ssaDetailsReq);
//		});
//
//		assertEquals("Application form number is empty or invalid", exception.getMessage());
//	}
//
//	@Test
//	void testCheckExistingAccounts() {
//		ExistingAccountReq existingAccountReq = new ExistingAccountReq("7865006");
//		ExistingAccountsResp expectedResponse = null;
//		// Mock behavior
//		Mockito.when(mockInvestBFFAppConfig.getSsaQrySvcBaseUrl())
//				.thenReturn("http://ssa-qry-svc-dev.apps.ubidev.ibmubi.local");
//		Mockito.when(mockInvestBFFAppConfig.getSsaQryInvestmentPath()).thenReturn("/ssa/api/v1");
//		Mockito.when(mockInvestBFFAppConfig.getSsaExistingAccounts()).thenReturn("/checkExistingAcct");
//		Mockito.when(commonService.getData(existingAccountReq.getCif() + "_" + new Object() {
//		}.getClass().getEnclosingMethod().getName(),
//				"http://ssa-qry-svc-dev.apps.ubidev.ibmubi.local/ssa/api/v1/checkExistingAcct", existingAccountReq,
//				ExistingAccountsResp.class, CallType.POST, false)).thenReturn(expectedResponse);
//
//		// Call the method
//		Mono<ExistingAccountsResp> actualResponse = bffServiceImplUnderTest.checkExistingAccounts(existingAccountReq);
//		assertEquals(expectedResponse, actualResponse.block());
//
////		 StepVerifier.create(bffServiceImplUnderTest.checkExistingAccounts(existingAccountReq))
////         .expectNext(expectedResponse)
////         .verifyComplete();
//
//	}
//
//	@Test
//	void testCheckExistingAccountsCIFBlank() {
//		// Setup
//		ExistingAccountReq existingAccountReq = new ExistingAccountReq("");
//
//		Throwable exception = assertThrows(InvestmentException.class, () -> {
//			bffServiceImplUnderTest.checkExistingAccounts(existingAccountReq);
//		});
//
//		assertEquals("Customer id is not initialized (empty).", exception.getMessage());
//	}
//
//	@Test
//	void testGetInvestmentAccounts() {
//		ExistingAccountReq existingAccountReq = new ExistingAccountReq("7865006");
//		InvestmentAccountsResp expectedResponse = null;
//		// Mock behavior
//		Mockito.when(mockInvestBFFAppConfig.getSsaQrySvcBaseUrl())
//				.thenReturn("http://ssa-qry-svc-dev.apps.ubidev.ibmubi.local");
//		Mockito.when(mockInvestBFFAppConfig.getSsaQryInvestmentPath()).thenReturn("/ssa/api/v1");
//		Mockito.when(mockInvestBFFAppConfig.getInvestmentAccounts()).thenReturn("/getSsaInvestmentAccounts");
//		Mockito.when(commonService.getData(existingAccountReq.getCif() + "_" + new Object() {
//		}.getClass().getEnclosingMethod().getName(),
//				"http://ssa-qry-svc-dev.apps.ubidev.ibmubi.local/ssa/api/v1/getSsaInvestmentAccounts",
//				existingAccountReq, InvestmentAccountsResp.class, CallType.POST, false)).thenReturn(expectedResponse);
//
//		// Call the method
//		Mono<InvestmentAccountsResp> actualResponse = bffServiceImplUnderTest.getInvestmentAccounts(existingAccountReq);
//		assertEquals(expectedResponse, actualResponse.block());
//
//	}
//
//	@Test
//	void testGetInvestmentAccountsCIFBlank() {
//		// Setup
//		ExistingAccountReq existingAccountReq = new ExistingAccountReq("");
//
//		Throwable exception = assertThrows(InvestmentException.class, () -> {
//			bffServiceImplUnderTest.getInvestmentAccounts(existingAccountReq);
//		});
//
//		assertEquals("Customer id is not initialized (empty).", exception.getMessage());
//	}
//
//	@Test
//	void testGetPaymentStatus() {
//		PaymentStatusReq paymentReq = new PaymentStatusReq();
//		paymentReq.setCif("214827460");
//		SourceInfo source = new SourceInfo();
//		source.setAcctNum("54370SSA000000000054");
//		InvestmentContributionInfo investment = new InvestmentContributionInfo();
//		investment.setChannelTxnId("106699334565");
//		paymentReq.setSource(source);
//		paymentReq.setInvestmentContribution(investment);
//
//		PaymentStatusResp expectedResponse = null;
//
//		Mockito.when(mockInvestBFFAppConfig.getSsaQrySvcBaseUrl())
//				.thenReturn("http://ssa-qry-svc-dev.apps.ubidev.ibmubi.local");
//		Mockito.when(mockInvestBFFAppConfig.getSsaQryInvestmentPath()).thenReturn("/ssa/api/v1");
//		Mockito.when(mockInvestBFFAppConfig.getInvestmentAccounts()).thenReturn("/getPaymentStatus");
//		Mockito.when(commonService.getData(paymentReq.getCif() + "_" + new Object() {
//		}.getClass().getEnclosingMethod().getName(),
//				"http://ssa-qry-svc-dev.apps.ubidev.ibmubi.local/ssa/api/v1/getPaymentStatus", paymentReq,
//				PaymentStatusResp.class, CallType.POST, false)).thenReturn(expectedResponse);
//
//		Mono<PaymentStatusResp> actualResponse = bffServiceImplUnderTest.getPaymentStatus(paymentReq);
//		assertEquals(expectedResponse, actualResponse.block());
//
//	}
//
//	@Test
//	void testGetPaymentStatusCifBlank() {
//		PaymentStatusReq paymentReq = new PaymentStatusReq();
//		paymentReq.setCif("");
//
//		Throwable exception = assertThrows(InvestmentException.class, () -> {
//			bffServiceImplUnderTest.getPaymentStatus(paymentReq);
//		});
//
//		assertEquals("Customer id is not initialized (empty).", exception.getMessage());
//	}
//
//	@Test
//	void testGetPaymentStatusAcctNumBlank() {
//		PaymentStatusReq paymentReq = new PaymentStatusReq();
//		paymentReq.setCif("7687687696");
//		SourceInfo source = new SourceInfo();
//		source.setAcctNum("");
//		paymentReq.setSource(source);
//		InvestmentContributionInfo investment = new InvestmentContributionInfo();
//		investment.setChannelTxnId("96768757747965");
//		paymentReq.setInvestmentContribution(investment);
//
//		Throwable exception = assertThrows(InvestmentException.class, () -> {
//			bffServiceImplUnderTest.getPaymentStatus(paymentReq);
//		});
//
//		assertEquals("Account Number is empty or invalid", exception.getMessage());
//	}
//
//	@Test
//	void testGetPaymentStatusTxnIdBlank() {
//		PaymentStatusReq paymentReq = new PaymentStatusReq();
//		paymentReq.setCif("7687687696");
//		SourceInfo source = new SourceInfo();
//		source.setAcctNum("8768758757467");
//		paymentReq.setSource(source);
//		InvestmentContributionInfo investment = new InvestmentContributionInfo();
//		investment.setChannelTxnId("");
//		paymentReq.setInvestmentContribution(investment);
//
//		Throwable exception = assertThrows(InvestmentException.class, () -> {
//			bffServiceImplUnderTest.getPaymentStatus(paymentReq);
//		});
//
//		assertEquals("Transaction Id is empty or invalid", exception.getMessage());
//	}
//
//	@Test
//	void testValidateContribution() {
//		ValidateReq validateReq = new ValidateReq();
//		ContributionDetails contributionDetails = new ContributionDetails();
//		contributionDetails.setContribAcctNum("968768587446");
//		contributionDetails.setContribAmt(new BigDecimal(8000));
//		validateReq.setInvestmentContribution(contributionDetails);
//
//		ValidateAmountResp expectedResponse = new ValidateAmountResp();
//		expectedResponse.setRemarks("SUCCESS");
//
//		Mockito.when(mockInvestBFFAppConfig.getSsaQrySvcBaseUrl())
//				.thenReturn("http://ssa-qry-svc-dev.apps.ubidev.ibmubi.local");
//		Mockito.when(mockInvestBFFAppConfig.getSsaQryInvestmentPath()).thenReturn("/ssa/api/v1");
//		Mockito.when(mockInvestBFFAppConfig.getSsaDetailsToResume()).thenReturn("/validateContribution");
//		Mockito.when(commonService.getData(null,"http://ssa-qry-svc-dev.apps.ubidev.ibmubi.local/ssa/api/v1/validateContribution",
//				validateReq,ValidateAmountResp.class, CallType.POST, false)).thenReturn(expectedResponse);
//
//		StepVerifier.create(bffServiceImplUnderTest.validateContribution(validateReq))
//		//.expectNext(expectedResponse)
//				.verifyComplete();
//	}
//	
////	@Test
////	void testValidateContributionAcctNumBlank() {
////		ValidateReq validateReq = new ValidateReq();
////		ContributionDetails contributionDetails = new ContributionDetails();
////		contributionDetails.setContribAcctNum("");
////		contributionDetails.setContribAmt(new BigDecimal(8000));
////		validateReq.setInvestmentContribution(contributionDetails);
////		
////		Throwable exception = assertThrows(InvestmentException.class, () -> {
////			bffServiceImplUnderTest.validateContribution(validateReq);
////		});
////
////		assertEquals("Account Number is empty or invalid", exception.getMessage());
////	}
//	
////	@Test
////	void testValidateContributionAmtNull() {
////		ValidateReq validateReq = new ValidateReq();
////		ContributionDetails contributionDetails = new ContributionDetails();
////		contributionDetails.setContribAcctNum("768574767353");
////		contributionDetails.setContribAmt(null);
////		validateReq.setInvestmentContribution(contributionDetails);
////		
////		Throwable exception = assertThrows(InvestmentException.class, () -> {
////			bffServiceImplUnderTest.validateContribution(validateReq);
////		});
////
////		assertEquals("Amount Entered is not Valid", exception.getMessage());
////	}
//	
//	@Test
//    public void testGetSSATermsAndCondition_SuccessfulWithNewFileData() throws IOException {
//        TAndCRequest tAndCRequest = new TAndCRequest();
//        tAndCRequest.setTandCType("SSA");
//        InputStream inputStream = new ByteArrayInputStream("Sample PDF Content".getBytes(StandardCharsets.UTF_8));
//        when(mockInvestBFFAppConfig.getTermsAndConditionforSSA()).thenReturn("TnCDocument/SSA_TandC.pdf");
//        Mono<FileData> result = bffServiceImplUnderTest.getSSATermsAndCondition(tAndCRequest);
//        assertNotNull(result);
//        assertTrue(result.block() != null);
//        assertEquals("SSA_T&C.pdf", result.block().getFileName());
//    }
//	
//	@Test
//	public void testGetSSATermsAndCondition_InvalidTandCType() {
//	    TAndCRequest tAndCRequest = new TAndCRequest("687575545","INVALID_TYPE");
//	    Throwable exception = assertThrows(InvestmentException.class, () -> {
//			bffServiceImplUnderTest.getSSATermsAndCondition(tAndCRequest);
//		});
//
//		assertEquals("Type Should only be SSA", exception.getMessage());
//	}
//	
//	@Test
//	public void testDownloadDocuments() {
//		DownloadReq downloadReq = new DownloadReq();
//		downloadReq.setCif("cif");
//		downloadReq.setUri("URI");
//		
//		DownloadResp expectedResponse = new DownloadResp();
//		expectedResponse.setFileName("fileName");
//		expectedResponse.setContent("File Content");
//
//		Mockito.when(mockInvestmentDocConfig.getDocStoreBaseUrl()).thenReturn("http://ssa-qry-svc-dev.apps.ubidev.ibmubi.local");
//		Mockito.when(mockInvestmentDocConfig.getDocStoreServicePath()).thenReturn("/ssa/api/v1");
//		Mockito.when(mockInvestmentDocConfig.getDownload()).thenReturn("/download");
//		Mockito.when(commonService.getData(null,"http://ssa-qry-svc-dev.apps.ubidev.ibmubi.local/ssa/api/v1/download",
//				downloadReq,DownloadResp.class, CallType.POST, false)).thenReturn(expectedResponse);
//
//		StepVerifier.create(bffServiceImplUnderTest.downloadDocuments(downloadReq))
//		//.expectNext(expectedResponse)
//				.verifyComplete();
//		
//	}
//	
//	public void getPaymentStatusWebClient() {
//		
//	}
//	
//	@Test
//	void testGetPaymentStatusWebClientCifBlank() {
//		PaymentStatusReq paymentReq = new PaymentStatusReq();
//		paymentReq.setCif("");
//
//		Throwable exception = assertThrows(InvestmentException.class, () -> {
//			bffServiceImplUnderTest.getPaymentStatusWebClient(paymentReq);
//		});
//
//		assertEquals("Customer id is not initialized (empty).", exception.getMessage());
//	}
//
//	@Test
//	void testGetPaymentStatusWebClientAcctNumBlank() {
//		PaymentStatusReq paymentReq = new PaymentStatusReq();
//		paymentReq.setCif("7687687696");
//		SourceInfo source = new SourceInfo();
//		source.setAcctNum("");
//		paymentReq.setSource(source);
//		InvestmentContributionInfo investment = new InvestmentContributionInfo();
//		investment.setChannelTxnId("96768757747965");
//		paymentReq.setInvestmentContribution(investment);
//
//		Throwable exception = assertThrows(InvestmentException.class, () -> {
//			bffServiceImplUnderTest.getPaymentStatusWebClient(paymentReq);
//		});
//
//		assertEquals("Account Number is empty or invalid", exception.getMessage());
//	}
//
//	@Test
//	void testGetPaymentStatusWebClientTxnIdBlank() {
//		PaymentStatusReq paymentReq = new PaymentStatusReq();
//		paymentReq.setCif("7687687696");
//		SourceInfo source = new SourceInfo();
//		source.setAcctNum("8768758757467");
//		paymentReq.setSource(source);
//		InvestmentContributionInfo investment = new InvestmentContributionInfo();
//		investment.setChannelTxnId("");
//		paymentReq.setInvestmentContribution(investment);
//
//		Throwable exception = assertThrows(InvestmentException.class, () -> {
//			bffServiceImplUnderTest.getPaymentStatusWebClient(paymentReq);
//		});
//
//		assertEquals("Transaction Id is empty or invalid", exception.getMessage());
//	}
//}