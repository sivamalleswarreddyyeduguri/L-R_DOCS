//package com.ubi.dbp.investment.apy.bff.test;
//
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.junit.jupiter.api.Assertions.assertNotNull;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.test.context.TestPropertySource;
//
//import com.ubi.dbp.investment.apy.bff.config.InvestmentBFFAppApyQryConfig;
//
//@SpringBootTest
//@TestPropertySource(properties = {
//        "ssa.query.service.base.url=http://test-query-base-url",
//        "ssa.query.service.investment.path=/test-query-investment-path",
//        "ssa.query.service.ssa.transaction=test-ssa-transactions",
//        "ssa.query.service.ssa.download.statement=test-download-statement",
//        "ssa.query.service.ssa.download.email=test-email-statement",
//        "ssa.query.service.ssa.status=test-ssa-status",
//        "ssa.query.service.ssa.certificate=test-ssa-certificate",
//        "ssa.query.service.ssa.accountDetails=test-ssa-account-details",
//        "ssa.query.service.ssa.acknowledgement=test-ssa-acknowledgement",
//        "ssa.query.service.ssa.contribution=test-ssa-contribution",
//        "ssa.query.service.ssa.penalty=test-ssa-penalty",
//        "ssa.query.service.ssa.detailsToResume=test-ssa-details-to-resume",
//        "ssa.query.service.ssa.existingAccts=test-ssa-existing-accts",
//        "ssa.query.service.ssa.investmentAccounts=test-ssa-investment-accounts",
//        "ssa.query.service.ssa.paymentStatus=test-ssa-payment-status",
//        "ssa.query.service.ssa.validateAmount=test-ssa-validate-amount",
//        "ssa.path.tnc=test-ssa-tnc"
//})
//public class InvestmentBFFAppApyQryConfigTest {
//
//    @Autowired
//    private InvestmentBFFAppApyQryConfig config;
//
//    @Test
//    public void testSsaQrySvcBaseUrl() {
//        assertEquals("http://test-query-base-url", config.getSsaQrySvcBaseUrl());
//    }
//
//    @Test
//    public void testSsaQryInvestmentPath() {
//        assertEquals("/test-query-investment-path", config.getSsaQryInvestmentPath());
//    }
//
//    @Test
//    public void testSsaTransactions() {
//        assertEquals("test-ssa-transactions", config.getSsaTransactions());
//    }
//
//    @Test
//    public void testDownloadStatement() {
//        assertEquals("test-download-statement", config.getDownloadStatement());
//    }
//
//    @Test
//    public void testEmailStatement() {
//        assertEquals("test-email-statement", config.getEmailStatement());
//    }
//
//    @Test
//    public void testSsaStatus() {
//        assertEquals("test-ssa-status", config.getSsaStatus());
//    }
//    
//    @Test
//    public void testSsaCertificate() {
//        assertEquals("test-ssa-certificate", config.getSsaCertificate());
//    }
//    
//    @Test
//    public void testSsaAccountDetails() {
//        assertEquals("test-ssa-account-details", config.getSsaAccountDetails());
//    }
//    
//    @Test
//    public void testSsaAcknowledgement() {
//        assertEquals("test-ssa-acknowledgement", config.getSsaAcknowledgement());
//    }
//    
//    @Test
//    public void testSsaDetailsToResume() {
//        assertEquals("test-ssa-details-to-resume", config.getSsaDetailsToResume());
//    }
//    
//    @Test
//    public void testSsaExistingAccts() {
//        assertEquals("test-ssa-existing-accts", config.getSsaExistingAccounts());
//    }
//    
//    @Test
//    public void testSsaInvestmentAccounts() {
//        assertEquals("test-ssa-investment-accounts", config.getInvestmentAccounts());
//    }
//    
//    @Test
//    public void testSsaPaymentStatus() {
//        assertEquals("test-ssa-payment-status", config.getPaymentStatus());
//    }
//    
//    @Test
//    public void testSsaValidateAmount() {
//        assertEquals("test-ssa-validate-amount", config.getValidateAmount());
//    }
//
//    @Test
//    public void testTnC() {
//    	assertEquals("test-ssa-tnc", config.getTermsAndConditionforSSA());
//    }
//    @Test
//    public void testNonNullValues() {
//        assertNotNull(config.getSsaQrySvcBaseUrl());
//        assertNotNull(config.getSsaQryInvestmentPath());
//        assertNotNull(config.getSsaTransactions());
//        assertNotNull(config.getDownloadStatement());
//        assertNotNull(config.getEmailStatement());
//        assertNotNull(config.getSsaStatus());
//        assertNotNull(config.getSsaCertificate());
//        assertNotNull(config.getSsaAccountDetails());
//        assertNotNull(config.getSsaAcknowledgement());
//        assertNotNull(config.getSsaDetailsToResume());
//        assertNotNull(config.getSsaExistingAccounts());
//        assertNotNull(config.getInvestmentAccounts());
//        assertNotNull(config.getPaymentStatus());
//        assertNotNull(config.getValidateAmount());
//        assertNotNull(config.getTermsAndConditionforSSA());
//    }
//}
