//package com.ubi.dbp.investment.apy.bff.test;
//
//import static org.junit.Assert.assertEquals;
//import static org.mockito.Mockito.*;
//
//
//import dbp.framework.proxy.common.client.DbpHttpClientException;
//import dbp.framework.support.exception.ErrorResponse;
//import jakarta.validation.ValidationException;
//import org.junit.jupiter.api.Test;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.server.MethodNotAllowedException;
//import org.springframework.web.server.ServerWebInputException;
//
//import com.ubi.dbp.investment.apy.bff.controller.ApyBffGlobalExceptionHandler;
//import com.ubi.dbp.investment.apy.bff.exception.InvestmentException;
//
//import reactor.core.publisher.Mono;
//
//
//public class ApyBffGlobalExceptionHandlerTest {
//	@Test
//    void handleDbpHttpClientException_Test() {
//        DbpHttpClientException mockException = mock(DbpHttpClientException.class);
//        when(mockException.getMessage()).thenReturn("Client error");
//        when(mockException.getHttpCode()).thenReturn(400);
//
//        ApyBffGlobalExceptionHandler controller = new ApyBffGlobalExceptionHandler();
//
//        Mono<ResponseEntity<String>> result = controller.handleDbpHttpClientException(mockException);
//
//    }
//    @Test
//    void handleEmptyBodyException_Test() {
//        // Arrange
//        ServerWebInputException mockException = mock(ServerWebInputException.class);
//        when(mockException.getMessage()).thenReturn("Failed to read HTTP message");
//
//        ApyBffGlobalExceptionHandler controller = new ApyBffGlobalExceptionHandler();
//
//        // Act
//        ResponseEntity<ErrorResponse> result = controller.handleEmptyBodyException(mockException).block();
//
//        // Assert
//        assertEquals(HttpStatus.BAD_REQUEST, result.getStatusCode());
//        assertEquals("Failed to read HTTP message", result.getBody().getErrors().get(0).getMessage());
//    }
//    
//    @Test
//    void handleMethodNotSupportedException_Test() {
//        // Arrange
//    	MethodNotAllowedException mockException = mock(MethodNotAllowedException.class);
//        when(mockException.getMessage()).thenReturn("Method Not Allowed");
//
//        ApyBffGlobalExceptionHandler controller = new ApyBffGlobalExceptionHandler();
//
//        // Act
//        ResponseEntity<ErrorResponse> result = controller.handleMethodNotSupportedException(mockException).block();
//
//        // Assert
//        assertEquals(HttpStatus.METHOD_NOT_ALLOWED, result.getStatusCode());
//        assertEquals("Method Not Allowed", result.getBody().getErrors().get(0).getMessage());
//    }
//    
//    @Test
//    void handleIllegalArgumentException_Test() {
//        // Arrange
//    	IllegalArgumentException mockException = mock(IllegalArgumentException.class);
//        when(mockException.getMessage()).thenReturn("Illegal Argument Exception");
//
//        ApyBffGlobalExceptionHandler controller = new ApyBffGlobalExceptionHandler();
//
//        // Act
//        ResponseEntity<ErrorResponse> result = controller.handleIllegalArgumentException(mockException).block();
//
//        // Assert
//        assertEquals(HttpStatus.BAD_REQUEST, result.getStatusCode());
//        assertEquals("Illegal Argument Exception", result.getBody().getErrors().get(0).getMessage());
//    }
//    
//    @Test
//    void handleInvalidBodyException_Test() {
//        // Arrange
//    	InvestmentException mockException = mock(InvestmentException.class);
//        when(mockException.getMessage()).thenReturn("Invalid customer data");
//
//        ApyBffGlobalExceptionHandler controller = new ApyBffGlobalExceptionHandler();
//
//        // Act
//        ResponseEntity<ErrorResponse> result = controller.handleInvalidBodyException(mockException).block();
//
//        // Assert
//        assertEquals(HttpStatus.BAD_REQUEST, result.getStatusCode());
//        assertEquals("Invalid customer data", result.getBody().getErrors().get(0).getMessage());
//    }
//    
//    @Test
//    void handleGenericException_Test() {
//        // Arrange
//        Exception mockException = mock(Exception.class);
//        when(mockException.getMessage()).thenReturn("Generic error");
//
//        ApyBffGlobalExceptionHandler controller = new ApyBffGlobalExceptionHandler();
//
//        // Act
//        ResponseEntity<ErrorResponse> result = controller.handleGenericException(mockException).block();
//
//        // Assert
//        assertEquals(HttpStatus.BAD_REQUEST, result.getStatusCode());
//        assertEquals("Generic error", result.getBody().getErrors().get(0).getMessage());
//    }
//    
//    @Test
//    void handleRequestException_Test() {
//        // Arrange
//        ValidationException mockException = mock(ValidationException.class);
//        when(mockException.getMessage()).thenReturn("Validation error");
//
//        ApyBffGlobalExceptionHandler controller = new ApyBffGlobalExceptionHandler();
//
//        // Act
//        ResponseEntity<ErrorResponse> result = controller.handleRequestException(mockException).block();
//
//        // Assert
//        assertEquals(HttpStatus.BAD_REQUEST, result.getStatusCode());
//        assertEquals("Validation error", result.getBody().getErrors().get(0).getMessage());
//    }
//}
