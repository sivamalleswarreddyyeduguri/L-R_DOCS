//package com.ubi.dbp.investment.apy.bff.test;
//
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.Mockito;
//import org.mockito.MockitoAnnotations;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.test.context.junit.jupiter.SpringExtension;
//
//import com.ubi.dbp.investment.apy.bff.config.InvestmentBFFAppApyCmdConfig;
//import com.ubi.dbp.investment.apy.bff.service.CacheService;
//import com.ubi.dbp.investment.apy.bff.service.AbsCommonService.CallType;
//import com.ubi.dbp.investment.apy.bff.service.impl.CommonService;
//import com.ubi.dbp.investment.apy.bff.service.impl.InvestmentBFFApyCmdServiceImpl;
//import com.ubi.dbp.investment.apy.bff.service.impl.InvestmentBFFApyQryServiceImpl;
//import com.ubi.dbp.investment.ssa.bff.dto.OpenResponse;
//import com.ubi.dbp.investment.ssa.bff.dto.PaymentStatusResp;
//import com.ubi.dbp.investment.ssa.bff.dto.RemoveResp;
//import com.ubi.dbp.investment.ssa.bff.dto.SaveResponse;
//import com.ubi.dbp.investment.ssa.bff.dto.UploadResp;
//import com.ubi.dbp.investment.ssa.bff.model.ContributionReq;
//import com.ubi.dbp.investment.ssa.bff.model.InvestmentContributionInfo;
//import com.ubi.dbp.investment.ssa.bff.model.OpenSsaReq;
//import com.ubi.dbp.investment.ssa.bff.model.PaymentStatusReq;
//import com.ubi.dbp.investment.ssa.bff.model.SaveSsaReq;
//import com.ubi.dbp.investment.ssa.bff.model.SourceInfo;
//import com.ubi.dbp.investment.ssa.bff.model.UploadReq;
//
//import dbp.framework.proxy.common.client.DbpHttpClient;
//import reactor.core.publisher.Mono;
//import reactor.test.StepVerifier;
//
//@ExtendWith(SpringExtension.class)
//@SpringBootTest
//public class InvestmentCmdServiceTest {
//
//	@Mock
//	private DbpHttpClient mockDbpHttpClient;
//	@Mock
//	private InvestmentBFFAppApyCmdConfig mockInvestBFFAppCmdConfig;
//	@Mock
//	CacheService cacheServiceMock;
//	@Mock
//	CommonService commonService;
//
//	@InjectMocks
//	InvestmentBFFApyCmdServiceImpl bffServiceImplUnderTest;
//
//	@InjectMocks
//	InvestmentBFFApyQryServiceImpl queryBffServiceImpl;
//
//	@BeforeEach
//	void setUp() {
//		MockitoAnnotations.openMocks(this);
//	}
//
//	@Test
//	public void testSaveSsa() {
//		// Mock data
//		SaveSsaReq saveSsaReq = new SaveSsaReq();
//		saveSsaReq.setCif("1321445436");
//		SaveResponse expectedResponse = new SaveResponse();
//
//		// Mock behavior
//		Mockito.when(mockInvestBFFAppCmdConfig.getSsaCmdSvcBaseUrl())
//				.thenReturn("http://ssa-command-service-dev.apps.ubidev.ibmubi.local");
//		Mockito.when(mockInvestBFFAppCmdConfig.getSsaCmdInvestmentPath()).thenReturn("/investment/ssa/api/v1");
//		Mockito.when(mockInvestBFFAppCmdConfig.getSaveSsa()).thenReturn("/save");
//		Mockito.when(commonService.getData(null,
//				"http://ssa-command-service-dev.apps.ubidev.ibmubi.local/investment/ssa/api/v1/save", saveSsaReq,
//				SaveResponse.class, CallType.POST, false)).thenReturn(expectedResponse);
//
//		StepVerifier.create(bffServiceImplUnderTest.saveSsa(saveSsaReq)).expectNext(expectedResponse).verifyComplete();
//	}
//
//	@Test
//	public void testOpenSsa() {
//		// Mock data
//		OpenSsaReq openSsaReq = new OpenSsaReq();
//		openSsaReq.setCif("1321445436");
//		OpenResponse expectedResponse = new OpenResponse();
//
//		// Mock behavior
//		Mockito.when(mockInvestBFFAppCmdConfig.getSsaCmdSvcBaseUrl())
//				.thenReturn("http://ssa-command-service-dev.apps.ubidev.ibmubi.local");
//		Mockito.when(mockInvestBFFAppCmdConfig.getSsaCmdInvestmentPath()).thenReturn("/investment/ssa/api/v1");
//		Mockito.when(mockInvestBFFAppCmdConfig.getOpenSsa()).thenReturn("/open");
//		Mockito.when(commonService.getData(null,
//				"http://ssa-command-service-dev.apps.ubidev.ibmubi.local/investment/ssa/api/v1/open", openSsaReq,
//				OpenResponse.class, CallType.POST, false)).thenReturn(expectedResponse);
//
//		StepVerifier.create(bffServiceImplUnderTest.openSsa(openSsaReq)).expectNext(expectedResponse).verifyComplete();
//	}
//
//	@Test
//	public void testMakeContribution() {
//		// Mock data
//		ContributionReq contributionReq = new ContributionReq();
//		contributionReq.setCif("1321445436");
//		OpenResponse expectedResponse = new OpenResponse();
//
//		// Mock behavior
//		Mockito.when(mockInvestBFFAppCmdConfig.getSsaCmdSvcBaseUrl())
//				.thenReturn("http://ssa-command-service-dev.apps.ubidev.ibmubi.local");
//		Mockito.when(mockInvestBFFAppCmdConfig.getSsaCmdInvestmentPath()).thenReturn("/investment/ssa/api/v1");
//		Mockito.when(mockInvestBFFAppCmdConfig.getContribution()).thenReturn("/contribute");
//		Mockito.when(commonService.getData(null,
//				"http://ssa-command-service-dev.apps.ubidev.ibmubi.local/investment/ssa/api/v1/contribute",
//				contributionReq, OpenResponse.class, CallType.POST, false)).thenReturn(expectedResponse);
//
//		StepVerifier.create(bffServiceImplUnderTest.makeContribution(contributionReq)).expectNext(expectedResponse)
//				.verifyComplete();
//	}
//
//	@Test
//	public void testUploadDocument() {
//		// Mock data
//		UploadReq uploadReq = new UploadReq();
//		uploadReq.setCif("cif");
//
//		UploadResp expectedResponse = new UploadResp();
//
//		// Mock behavior
//		Mockito.when(mockInvestBFFAppCmdConfig.getSsaCmdSvcBaseUrl())
//				.thenReturn("http://ssa-command-service-dev.apps.ubidev.ibmubi.local");
//		Mockito.when(mockInvestBFFAppCmdConfig.getSsaCmdInvestmentPath()).thenReturn("/investment/ssa/api/v1");
//		Mockito.when(mockInvestBFFAppCmdConfig.getUpload()).thenReturn("/upload");
//		Mockito.when(commonService.getData(null,
//				"http://ssa-command-service-dev.apps.ubidev.ibmubi.local/investment/ssa/api/v1/upload", uploadReq,
//				UploadResp.class, CallType.POST, false)).thenReturn(expectedResponse);
//
//		StepVerifier.create(bffServiceImplUnderTest.uploadDocuments(uploadReq)).expectNext(expectedResponse)
//				.verifyComplete();
//	}
//
//	@Test
//	public void testRemoveDocument() {
//		// Mock data
//		UploadReq removeReq = new UploadReq();
//		removeReq.setCif("1321445436");
//		RemoveResp expectedResponse = new RemoveResp();
//
//		// Mock behavior
//		Mockito.when(mockInvestBFFAppCmdConfig.getSsaCmdSvcBaseUrl())
//				.thenReturn("http://ssa-command-service-dev.apps.ubidev.ibmubi.local");
//		Mockito.when(mockInvestBFFAppCmdConfig.getSsaCmdInvestmentPath()).thenReturn("/investment/ssa/api/v1");
//		Mockito.when(mockInvestBFFAppCmdConfig.getRemove()).thenReturn("/remove");
//		Mockito.when(commonService.getData(null,
//				"http://ssa-command-service-dev.apps.ubidev.ibmubi.local/investment/ssa/api/v1/remove", removeReq,
//				RemoveResp.class, CallType.POST, false)).thenReturn(expectedResponse);
//
//		StepVerifier.create(bffServiceImplUnderTest.removeDocument(removeReq)).expectNext(expectedResponse)
//				.verifyComplete();
//	}
//
////	@Test
//	public void testMakeContributionBlock() {
//		ContributionReq contributionReq = new ContributionReq();
//		contributionReq.setCif("1321445436");
//		SourceInfo source = new SourceInfo();
//		source.setAcctNum("875757474747547");
//		contributionReq.setSource(source);
//		PaymentStatusReq req = new PaymentStatusReq();
//		req.setCif(contributionReq.getCif());
//		req.setSource(contributionReq.getSource());
//		InvestmentContributionInfo contributionInfo = new InvestmentContributionInfo();
//		contributionInfo.setChannelTxnId("98685764764");
//		req.setInvestmentContribution(contributionInfo);
//		PaymentStatusResp response = new PaymentStatusResp();
//		OpenResponse expectedResponse = new OpenResponse();
//		Mockito.when(mockInvestBFFAppCmdConfig.getSsaCmdSvcBaseUrl())
//				.thenReturn("http://ssa-command-service-dev.apps.ubidev.ibmubi.local");
//		Mockito.when(mockInvestBFFAppCmdConfig.getSsaCmdInvestmentPath()).thenReturn("/investment/ssa/api/v1");
//		Mockito.when(mockInvestBFFAppCmdConfig.getContribution()).thenReturn("/contribute");
//		Mockito.when(commonService.getData(null,
//				"http://ssa-command-service-dev.apps.ubidev.ibmubi.local/investment/ssa/api/v1/contribute",
//				contributionReq, OpenResponse.class, CallType.POST, false)).thenReturn(expectedResponse);
//
//		Mockito.when(queryBffServiceImpl.getPaymentStatusWebClient(req)).thenReturn(Mono.just(response));
//		Mockito.when(bffServiceImplUnderTest.makeContribution(contributionReq)).thenReturn(Mono.just(expectedResponse));
//
//	}
//
//}
