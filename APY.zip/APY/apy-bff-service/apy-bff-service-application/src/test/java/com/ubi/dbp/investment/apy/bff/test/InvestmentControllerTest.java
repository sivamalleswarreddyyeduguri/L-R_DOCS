//package com.ubi.dbp.investment.apy.bff.test;
//
//import static org.mockito.Mockito.reset;
//import static org.mockito.Mockito.verify;
//import static org.mockito.Mockito.when;
//
//import java.math.BigDecimal;
//import java.time.LocalDate;
//import java.time.LocalDateTime;
//import java.util.ArrayList;
//import java.util.List;
//
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.test.context.junit.jupiter.SpringExtension;
//
//import com.ubi.dbp.investment.apy.bff.controller.InvestmentController;
//import com.ubi.dbp.investment.apy.bff.service.InvestmentBFFApyQryService;
//import com.ubi.dbp.investment.ssa.bff.dto.AccountStatus;
//import com.ubi.dbp.investment.ssa.bff.dto.Accounts;
//import com.ubi.dbp.investment.ssa.bff.dto.AccountsDetailsForPayment;
//import com.ubi.dbp.investment.ssa.bff.dto.BankDetails;
//import com.ubi.dbp.investment.ssa.bff.dto.DownloadResp;
//import com.ubi.dbp.investment.ssa.bff.dto.EmailResponse;
//import com.ubi.dbp.investment.ssa.bff.dto.Entity;
//import com.ubi.dbp.investment.ssa.bff.dto.ExistingAccounts;
//import com.ubi.dbp.investment.ssa.bff.dto.ExistingAccountsResp;
//import com.ubi.dbp.investment.ssa.bff.dto.FileData;
//import com.ubi.dbp.investment.ssa.bff.dto.InvestAccounts;
//import com.ubi.dbp.investment.ssa.bff.dto.InvestmentAccountsResp;
//import com.ubi.dbp.investment.ssa.bff.dto.InvestmentContributionDetails;
//import com.ubi.dbp.investment.ssa.bff.dto.PDFDownloaderDTO;
//import com.ubi.dbp.investment.ssa.bff.dto.PaymentStatusResp;
//import com.ubi.dbp.investment.ssa.bff.dto.PostalAddress;
//import com.ubi.dbp.investment.ssa.bff.dto.SsaAccountRespDTO;
//import com.ubi.dbp.investment.ssa.bff.dto.SsaDetailsResp;
//import com.ubi.dbp.investment.ssa.bff.dto.SsaStatusResponseDTO;
//import com.ubi.dbp.investment.ssa.bff.dto.TransactionDetails;
//import com.ubi.dbp.investment.ssa.bff.dto.TransactionDetailsResp;
//import com.ubi.dbp.investment.ssa.bff.dto.ValidateAmountResp;
//import com.ubi.dbp.investment.ssa.bff.model.ContributionDetails;
//import com.ubi.dbp.investment.ssa.bff.model.DownloadReq;
//import com.ubi.dbp.investment.ssa.bff.model.EmailStatementReq;
//import com.ubi.dbp.investment.ssa.bff.model.ExistingAccountReq;
//import com.ubi.dbp.investment.ssa.bff.model.InvestmentContributionInfo;
//import com.ubi.dbp.investment.ssa.bff.model.PaymentStatusReq;
//import com.ubi.dbp.investment.ssa.bff.model.SourceInfo;
//import com.ubi.dbp.investment.ssa.bff.model.SsaAccReq;
//import com.ubi.dbp.investment.ssa.bff.model.SsaDetailsReq;
//import com.ubi.dbp.investment.ssa.bff.model.TAndCRequest;
//import com.ubi.dbp.investment.ssa.bff.model.TransactionReq;
//import com.ubi.dbp.investment.ssa.bff.model.ValidateReq;
//
//import reactor.core.publisher.Mono;
//
//@ExtendWith(SpringExtension.class)
//@SpringBootTest
//public class InvestmentControllerTest {
//
//	@InjectMocks
//	InvestmentController investmentControllerUnderTest;
//
//	@Mock
//	InvestmentBFFApyQryService bffssaQryServiceMock;
//
//	public static TransactionReq sampleTransactionReq() {
//		return new TransactionReq("6769873","86876875857855", LocalDate.of(2023, 12, 04), LocalDate.of(2024, 12, 04));
//	}
//
//	public static EmailStatementReq sampleEmailReq() {
//		return new EmailStatementReq("2149034236", "86876875857855", LocalDate.of(2023, 12, 04),
//				LocalDate.of(2024, 12, 04));
//	}
//
//	public static SsaAccReq sampleSsaAccReq() {
//		SsaAccReq ssaReq = new SsaAccReq();
//		ssaReq.setCif("121212132");
//		SourceInfo source = new SourceInfo();
//		source.setAcctNum("86876875857855");
//		ssaReq.setSource(source);
//		return ssaReq;
//	}
//
//	public static SsaDetailsReq sampleSsaDetailsReq() {
//		return new SsaDetailsReq("7865006", "190090");
//	}
//
//	public static PaymentStatusReq samplePaymentStatusReq() {
//		PaymentStatusReq paymentReq = new PaymentStatusReq();
//		paymentReq.setCif("7687687696");
//		SourceInfo source = new SourceInfo();
//		source.setAcctNum("8768758757467");
//		InvestmentContributionInfo investment = new InvestmentContributionInfo();
//		investment.setChannelTxnId("96768757747965");
//		paymentReq.setSource(source);
//		paymentReq.setInvestmentContribution(investment);
//		return paymentReq;
//	}
//
//	public static PaymentStatusResp samplePaymentStatusResp() {
//		PaymentStatusResp paymentResp = new PaymentStatusResp();
//		paymentResp.setCif("687696999");
//		paymentResp.setApplNum("6757646364577");
//		paymentResp.setRemarks("remarks");
//		InvestmentContributionDetails contriDetails = new InvestmentContributionDetails();
//		contriDetails.setPaymentTxnDate(LocalDateTime.now());
//		contriDetails.setChannelTxnId("875764847635");
//		contriDetails.setContribAcctNum("64560998764323");
//		contriDetails.setContribAmt(new BigDecimal(500));
//		contriDetails.setPaymentTxnId("87576463452376");
//
//		List<AccountsDetailsForPayment> acctList = new ArrayList<AccountsDetailsForPayment>();
//		AccountsDetailsForPayment acctDetails = new AccountsDetailsForPayment();
//		acctDetails.setAcctNum("658746857656464");
//		acctDetails.setMaturityDate(LocalDate.now());
//		AccountStatus status = new AccountStatus();
//		status.setStatusFlg("Success");
//		acctDetails.setAcctStatus(status);
//		acctList.add(acctDetails);
//
//		paymentResp.setInvestmentContribution(contriDetails);
//		paymentResp.setAccts(acctList);
//		return paymentResp;
//	}
//	
//	public static ValidateReq sampleValidateReq() {
//		ValidateReq validateReq = new ValidateReq();
//		ContributionDetails contributionDetails = new ContributionDetails();
//		contributionDetails.setContribAcctNum("968768587446");
//		contributionDetails.setContribAmt(new BigDecimal(8000));
//		validateReq.setInvestmentContribution(contributionDetails);
//		return validateReq;
//	}
//	
//	public static ValidateAmountResp sampleValidateAmountResp() {
//		ValidateAmountResp validateAmountResp = new ValidateAmountResp();
//		validateAmountResp.setRemarks("Remarks");
//		return validateAmountResp;
//	}
//
//	public static TAndCRequest sampleTAndCRequest() {
//		TAndCRequest tAndCRequest = new TAndCRequest();
//		tAndCRequest.setTandCType("SSA");
//		return tAndCRequest;
//	}
//	
//	public static DownloadReq sampleDownloadReq() {
//		DownloadReq downloadReq = new DownloadReq();
//		downloadReq.setCif("cif");
//		downloadReq.setUri("URI");
//		return downloadReq;
//	}
//	
//	public static DownloadResp sampleDownloadResp() {
//		DownloadResp downloadResp = new DownloadResp();
//		downloadResp.setFileName("fileName");
//		downloadResp.setContent("File Content");
//		return downloadResp;
//	}
//	
//	public static FileData sampleFileData() {
//		FileData fileData = new FileData();
//		fileData.setFileName("name");
//		fileData.setData("DATA");
//		return fileData;
//	}
//	
//	public static TransactionDetailsResp sampleTransactionDetailsResp() {
//
//		TransactionDetailsResp transactionResp = new TransactionDetailsResp();
//
//		List<TransactionDetails> list = new ArrayList<TransactionDetails>();
//		TransactionDetails transaction1 = new TransactionDetails();
//		transaction1.setAcctNum("86876875857855");
//		transaction1.setAmount(new BigDecimal(300));
//		transaction1.setTransactionDate(LocalDate.of(2023, 11, 16));
//		transaction1.setTransactionCurrencyCode("INR");
//		transaction1.setValueDate(LocalDate.of(2023, 11, 16));
//
//		TransactionDetails transaction2 = new TransactionDetails();
//		transaction2.setAcctNum("86876875857855");
//		transaction2.setAmount(new BigDecimal(-75.5));
//		transaction2.setTransactionDate(LocalDate.of(2023, 11, 15));
//		transaction2.setTransactionCurrencyCode("INR");
//		transaction2.setValueDate(LocalDate.of(2023, 11, 15));
//
//		TransactionDetails transaction3 = new TransactionDetails();
//		transaction3.setAcctNum("86876875857855");
//		transaction3.setAmount(new BigDecimal(1000.75));
//		transaction3.setTransactionDate(LocalDate.of(2023, 11, 14));
//		transaction3.setTransactionCurrencyCode("INR");
//		transaction3.setValueDate(LocalDate.of(2023, 11, 14));
//
//		TransactionDetails transaction4 = new TransactionDetails();
//		transaction4.setAcctNum("86876875857855");
//		transaction4.setAmount(new BigDecimal(-50.25));
//		transaction4.setTransactionDate(LocalDate.of(2023, 11, 13));
//		transaction4.setTransactionCurrencyCode("INR");
//		transaction4.setValueDate(LocalDate.of(2023, 11, 13));
//
//		TransactionDetails transaction5 = new TransactionDetails();
//		transaction5.setAcctNum("86876875857855");
//		transaction5.setAmount(new BigDecimal(600.0));
//		transaction5.setTransactionDate(LocalDate.of(2023, 11, 12));
//		transaction5.setTransactionCurrencyCode("INR");
//		transaction5.setValueDate(LocalDate.of(2023, 11, 12));
//
//		TransactionDetails transaction6 = new TransactionDetails();
//		transaction6.setAcctNum("86876875857855");
//		transaction6.setAmount(new BigDecimal(-120.0));
//		transaction6.setTransactionDate(LocalDate.of(2023, 11, 11));
//		transaction6.setTransactionCurrencyCode("INR");
//		transaction6.setValueDate(LocalDate.of(2023, 11, 11));
//
//		TransactionDetails transaction7 = new TransactionDetails();
//		transaction7.setAcctNum("86876875857855");
//		transaction7.setAmount(new BigDecimal(200.5));
//		transaction7.setTransactionDate(LocalDate.of(2023, 11, 10));
//		transaction7.setTransactionCurrencyCode("INR");
//		transaction7.setValueDate(LocalDate.of(2023, 11, 10));
//
//		TransactionDetails transaction8 = new TransactionDetails();
//		transaction8.setAcctNum("86876875857855");
//		transaction8.setAmount(new BigDecimal(-80.75));
//		transaction8.setTransactionDate(LocalDate.of(2023, 11, 9));
//		transaction8.setTransactionCurrencyCode("INR");
//		transaction8.setValueDate(LocalDate.of(2023, 11, 9));
//
//		list.add(transaction1);
//		list.add(transaction2);
//		list.add(transaction3);
//		list.add(transaction4);
//		list.add(transaction5);
//		list.add(transaction6);
//		list.add(transaction7);
//		list.add(transaction8);
//		transactionResp.setTransactions(list);
//		return transactionResp;
//
//	}
//
//	@Test
//	void testGetSSATransactions() {
//
//		when(bffssaQryServiceMock.getSSATransactions(sampleTransactionReq())).thenReturn(Mono.just(sampleTransactionDetailsResp()));
//		
//		Mono<TransactionDetailsResp> actual = investmentControllerUnderTest.getSSATransactions(sampleTransactionReq());
//		
//		verify(bffssaQryServiceMock).getSSATransactions(sampleTransactionReq());
//		
//		reset(bffssaQryServiceMock);
//	}
//
//	@Test
//	void testEmailStatement() {
//		EmailStatementReq emailStatementReq = new EmailStatementReq();
//
//		EmailResponse emailResponse = new EmailResponse();
//		emailResponse.setMessage("email sent Successfully");
//		when(bffssaQryServiceMock.emailStatement(emailStatementReq)).thenReturn(Mono.just(emailResponse));
//
//		Mono<EmailResponse> emailRep = investmentControllerUnderTest.emailStatement(emailStatementReq);
//
//		verify(bffssaQryServiceMock).emailStatement(emailStatementReq);
//
//		reset(bffssaQryServiceMock);
//	}
//
//	@Test
//	void testSSACertificate() {
//		PDFDownloaderDTO downloaderDTO = new PDFDownloaderDTO();
//		FileData fileData = new FileData();
//		fileData.setData(
//				"JVBERi0xLjQKJeLjz9MKNSAwIG9iago8PC9MZW5ndGggMjI1NS9GaWx0ZXIvRmxhdGVEZWNvZGU+PnN0cmVhbQp4nI2a247byBGG7/kUfbNIYmR7eD7sVex1svACMbIZBXEQ5IIj9YzoFUmZpGzP26f6UM3qGkIa+GJUEuur/68qNjW2v0TvdlEs6jyRdS12h+ivu+i36EsUyzirCvEtSsWv8PnnKInF36P//i8WhygrRR0X+vo+KopGpjXGJ4yzUsY5hHApeemvOkb/jgbA6j/TUwTFy0xUSSLzBJhJXssswfgEcSWLEuJYliXEeSqzeg2P0SNL8YiyyWXTrIiyKWSVbyAJw+X0TpVH2Kqc4GNNCDL60NYL2YxnFThVzkUKzWxII3ScENXeNXER5niGt+EYvi5nEoY34r36brpOhYwtL5xBhhpq50zaT/NW/+ISLgs76sJgphyRMkQm82YDGTBSy0BVDoFVOcHF1AcDFCGAudjIN28RE7wkU5TSadCUFVFVMi4JAuI62UBShs3xNhDhqnICxsQHA6ANJpvxgp1yLvyeOoLfQz/dcNrBbjMG2kAG1uVMykAjxGtMd5kztrxwxjpUvqkhM+xnnYRD5SNgE4r5mfcCkTNEoX+8RAaM3DJQlUNgVU5wMfXBAFUIYC428s1bxAQvyRTldBo0ZUXowdFzAuK62UBShs3xNhDhqnICxsQHA6ANJpvxgp1yLvyeOoLfQz/dcNrBbjMG2kAG1uVMykAjxGtCd5kztrxwxjpUvqkhM+xn3YRD5SNgE0r4mfcCUTJEJct8AxkwSstAVQ6BVTnBxdQHAzQhgLnYyDdvERO8JFNU0mnQlBUB5JSeExA35QaSMmyOt4EIV5UTMCY+GABtMNmMF+yUc+H31BH8HvrphtMOdpsx0AYysC5nUgYaIV5TusucseWFM9ah8k0NmWE/mzIcKh8Bm1DKzzyOyOoQkTWySjaQlGFz/FgR4apyAsbEBwOgDSab8Wi+eYuY4CWZoppOg6asiDSTKT0n0tz+MsSRlGFzvA1EuKqcgDHxwQBog8lmPLpT6AL3FAm4h+t0w2nT3eYMtIEMrMuZlIFGvFffTdcpxtjywhnrUPmmhkzaT/NW/+ISLgs76sJgphyRMEQiq2YDGTASy0BVDoFVOcHF1AcD5CGAudjMr5rQBC/JFMX8GcgRcSEzek7EpUySDSRl2BxvAxGuKidgTHwwANpgshkv2Cnnwu+pI/g99NMNpx3sNmOgDWRgXc6kDDTivfpuuk4xxpYXzliHyjc1ZNJ+mrf6F5dwWdhRFwYz5YiMITJZlxvIgJFZBqpyCKzKCS6mPhigDAHMxWZ+XYYmeEmmKOHPQIYo6krm5Jwo6lomzQaSMFwO2vAIW5UTfLz6YABvg8lmvGCnnAu/p47g99BPN5x2sNshw9twDF+XMwnDG/FefTddp0LGlhfOIEPlmxoyNaPMZAwtSgqZVoDA0Jy7ZWqDzASxrHMM9hHIKRMMi9oGOQ0MES50YSkLgUkg0/P0632EpcwnTkNJXjsYURwnOt8rjmONtpi8MXVsBRegYhc6VTYLA0P0imMLtpfHYK1CzTbwot1nTof5EWiksnPofZ562TmMDkbhZNelCaxsG3jZNrTSXBYGhoiy8xqux07nTawDbIQJUDZ+5nQ0NHBEIrtMZLHuRw7EDPcjh1oZ7ocLvGwbOmk2CwND9LKBhc3OoUiNPPPaa7afOA0pee1gRHGWy4o0OjN/Z+UwWWoCW8EGXrENnSqbhYEhesVZIRvf6KzUARJN4EW7z5yOggaOqGW/20V3f0tEUosd3Nnmnx0SkSa1rAtR1eY22/XRH/81dOMg3rXD72J8FB+GQ9f+afdZ/5MIAlIKgDlWRS6zxiTfX35vh+dW3Lf91B0Ox078Z/zcDq34WU1L99jt20VRWrpBS2H3MkN7r9pJXCtewnGT0YyfL/My9mq6WiPTV5dwmyaFTVq1iY+jfPPmWnaSN/qv4Ej6/f1bcSc+ffr0YxnHdQq/Y72ieg2/iKWBZPHh/WvqrolJav5k6SvKwTq4Bo3DMnUPl2WcxMe2vz4Mm5sX+hmnk9+pQUGfunZ6fm0yjCYvwsp6vd7242VYXpEfN7Kwyj8Mi5rUvIh/3tgh7NSa+oM4y1berlY08LC3m3d7T4silnYQb8Su/e4siW4WD+2sDgJcLkcl9pdpUvD+ApdMesPa4bC+eQRHx/F0EF/b00WJ+az2sImQ/fBssn8Zvy7S4G+pgTOgqowcXWUW7QS4y8NntYcyo9gf2+FJWdS8tMtlNkK0qtYK79tndxXN++laXThaCuhyY9vwdvCAbvB+5Q5snMGm9msbsIhvx25/NJdAuw7qcNkv4BleJ/EPV+cEFfNGP7Z1QU1exqU9QT23G51t+uN46sDzNM5zNzyZt9ZWn7q+W+CSyQhQ31V/Njup+5EUv2j3fQeJ43BTij41K3fwYZI+Nf/x9iPYWtruNNtCqEnCATOQCnjxt/ECytplmVroeyvOamhPy7PYvb+/OnktojRPVi3iL+kr2leUeIC4jT1Pun1mYU/q8AQn0XxUCobUnU6wl3CvP05jL5au1+22P/2KrwPfr+eYaewtHbl+umoZdh1v6k4bPIb8SaC+75U64ITXSZoJSz3LfTsM4yIelO35sqy3lls70P5oFyTcpFtyEvOY1XKg4EGdx7lbZqdo3tKjR53C98E4vvvxGrzR/1sglamFv3mzM1oNX0xqr7qzPmTmi71hgltcfYEzZFLtqZtbXfjOJ0Dtx8sAwvSgxv4MD+k/zFc9ahnwbb62q9Lu93pXJHwfgJ7OSgNdvUMHt9UwXqa7Aazygn92vQ71w8i1GJjOXp1g6W4qgS819ttJC0+uHszt29Pp+erO6DT4vb2x9+fHcVE/iQ921H7IrT+z9ZbMl0f9dDMH86i1jl+VvXf1bWivtX5mePiZAxMW65aGuJaFnaUjgl17Q5mDsRv23RkWz0kZrcLH7jtc5toW2MxelkjhO0HlTkT9+FH6jmjNnC9gVDzBY1ufvAdz8qteaRuHUVnXE0yx0w+L7mmAG3FSWE7/D5jfov8D24K67gplbmRzdHJlYW0KZW5kb2JqCjEgMCBvYmoKPDwvVHlwZS9QYWdlL01lZGlhQm94WzAgMCA1OTUuMjggODQxLjg4XS9SZXNvdXJjZXM8PC9Gb250PDwvRjEgMiAwIFIvRjIgMyAwIFIvRjMgNCAwIFI+Pj4+L0NvbnRlbnRzIDUgMCBSL1BhcmVudCA2IDAgUj4+CmVuZG9iago5IDAgb2JqCjw8L1RpdGxlKFN1a2FueWEgU2FtcmlkZGhpIFlvamFuYSBDZXJ0aWZpY2F0ZSkvUGFyZW50IDggMCBSL0Rlc3RbMSAwIFIvWFlaIDAgNzY1LjYgMF0+PgplbmRvYmoKOCAwIG9iago8PC9UaXRsZShVbmlvbiBCYW5rIG9mIEluZGlhKS9QYXJlbnQgNyAwIFIvRmlyc3QgOSAwIFIvTGFzdCA5IDAgUi9EZXN0WzEgMCBSL1hZWiAwIDc5OS44OCAwXS9Db3VudCAxPj4KZW5kb2JqCjcgMCBvYmoKPDwvVHlwZS9PdXRsaW5lcy9GaXJzdCA4IDAgUi9MYXN0IDggMCBSL0NvdW50IDI+PgplbmRvYmoKMiAwIG9iago8PC9UeXBlL0ZvbnQvU3VidHlwZS9UeXBlMS9CYXNlRm9udC9UaW1lcy1Cb2xkL0VuY29kaW5nL1dpbkFuc2lFbmNvZGluZz4+CmVuZG9iagozIDAgb2JqCjw8L1R5cGUvRm9udC9TdWJ0eXBlL1R5cGUxL0Jhc2VGb250L1RpbWVzLVJvbWFuL0VuY29kaW5nL1dpbkFuc2lFbmNvZGluZz4+CmVuZG9iago0IDAgb2JqCjw8L1R5cGUvRm9udC9TdWJ0eXBlL1R5cGUxL0Jhc2VGb250L1RpbWVzLUl0YWxpYy9FbmNvZGluZy9XaW5BbnNpRW5jb2Rpbmc+PgplbmRvYmoKNiAwIG9iago8PC9UeXBlL1BhZ2VzL0NvdW50IDEvS2lkc1sxIDAgUl0+PgplbmRvYmoKMTAgMCBvYmoKPDwvVHlwZS9DYXRhbG9nL1BhZ2VzIDYgMCBSL091dGxpbmVzIDcgMCBSL1BhZ2VNb2RlL1VzZU91dGxpbmVzPj4KZW5kb2JqCjExIDAgb2JqCjw8L1Byb2R1Y2VyKGlUZXh0riA1LjUuMTMuMyCpMjAwMC0yMDIyIGlUZXh0IEdyb3VwIE5WIFwoQUdQTC12ZXJzaW9uXCkpL0NyZWF0aW9uRGF0ZShEOjIwMjMxMjIzMTA1MDQyWikvTW9kRGF0ZShEOjIwMjMxMjIzMTA1MDQyWikvVGl0bGUoU3VrYW55YSBTYW1yaWRkaGkgWW9qYW5hIENlcnRpZmljYXRlKT4+CmVuZG9iagp4cmVmCjAgMTIKMDAwMDAwMDAwMCA2NTUzNSBmIAowMDAwMDAyMzM4IDAwMDAwIG4gCjAwMDAwMDI3NjAgMDAwMDAgbiAKMDAwMDAwMjg0OSAwMDAwMCBuIAowMDAwMDAyOTM5IDAwMDAwIG4gCjAwMDAwMDAwMTUgMDAwMDAgbiAKMDAwMDAwMzAzMCAwMDAwMCBuIAowMDAwMDAyNjk1IDAwMDAwIG4gCjAwMDAwMDI1NzcgMDAwMDAgbiAKMDAwMDAwMjQ3NCAwMDAwMCBuIAowMDAwMDAzMDgxIDAwMDAwIG4gCjAwMDAwMDMxNjMgMDAwMDAgbiAKdHJhaWxlcgo8PC9TaXplIDEyL1Jvb3QgMTAgMCBSL0luZm8gMTEgMCBSL0lEIFs8NWM2M2IzYzQyMTQ4NmIzYzBiMGRiZTFmYzYyMDM1NjA+PDVjNjNiM2M0MjE0ODZiM2MwYjBkYmUxZmM2MjAzNTYwPl0+PgolaVRleHQtNS41LjEzLjMKc3RhcnR4cmVmCjMzNTYKJSVFT0YK");
//		fileData.setFileName("2368484XXXX.pdf");
//		downloaderDTO.setFileData(fileData);
//		when(bffssaQryServiceMock.getSSACertificate(sampleSsaAccReq())).thenReturn(Mono.just(downloaderDTO));
//
//		Mono<PDFDownloaderDTO> pDFDownloaderDTO = investmentControllerUnderTest.getSSACertificate(sampleSsaAccReq());
//		verify(bffssaQryServiceMock).getSSACertificate(sampleSsaAccReq());
//		reset(bffssaQryServiceMock);
//	}
//
//	@Test
//	void testSSAAcknowledgementLetter() {
//		PDFDownloaderDTO downloaderDTO = new PDFDownloaderDTO();
//		FileData fileData = new FileData();
//		fileData.setData(
//				"JVBERi0xLjQKJeLjz9MKMyAwIG9iago8PC9MZW5ndGggNjExL0ZpbHRlci9GbGF0ZURlY29kZT4+c3RyZWFtCnichVTLbtswELzzK/bYAjJLvWXfkjQBEiAtUqsI2iAHWqRtJjQpU1Rc/32XEhK3aApBEkCudoazswvuyXlNGFRZTKsKakEua3JH9oRRlpY5HEgCN/j/icQMbsnDIwNB0gIqlof8HcnzOU2q171+3acFZRluMfWP5VvWltwTg7ThcZsg4dNVDHEC9ZrEQzSGLIEyK2meQr0jHz5zLxeQsCSdxcmMlR/rpyD1v8iE0SQZkF/4DpE3dmsmMMU8ofMTBuwazrl5XsB3o6wZ1iF2bYTiU1RFTotR+NI7KT2cCeFk1y0CjXAcLnnnYQa3/W7F1RRbWtF0ZLtQ/hjB0qMbEfxULVxYgdWNNBDBLd9yx7utdzyCjLGSVVPkcYytHj2W3A1GRROYvEppOTp1L4E7/JpnYw9aio0yG3Cykar1wa2j7R3wttWq4T7YiO9DaGb4+W3Me6ToSicF9G1IQIAyyiuuYUpHMadVPuhw8kXJQ/Rer2Dfc63WSnbA8TUgtdqolZawwrQIIwL8Vv6l8gRZWzcpI8/pvBxkyF+tFMpjLaMgioI09h2M9YFPgMWj3EF12L9/vOm2ttcCVsHPwIGh1XG065FOiUgqWowiftj+lUqZRvdCDvVdnF0vobHGO6vB4MRIF07g5ohRh9OJ7gtpGonaNQ/ne4tAhR4ojW2dVMBimlaDguuh8bDlL3Lg3/eyCxV2EbRaYq8HHVjke/2aOicrM8rGSpdYn0S1x6mJzbKCliNmtlQbw33v5BQmxfvgdB2EMamV15MwvOSKAdY0C/i6XqsmjPKVekOG+/WO/AbyXXhbCmVuZHN0cmVhbQplbmRvYmoKMSAwIG9iago8PC9UeXBlL1BhZ2UvTWVkaWFCb3hbMCAwIDU5NS4yOCA4NDEuODhdL1Jlc291cmNlczw8L0ZvbnQ8PC9GMSAyIDAgUj4+Pj4vQ29udGVudHMgMyAwIFIvUGFyZW50IDQgMCBSPj4KZW5kb2JqCjIgMCBvYmoKPDwvVHlwZS9Gb250L1N1YnR5cGUvVHlwZTEvQmFzZUZvbnQvSGVsdmV0aWNhL0VuY29kaW5nL1dpbkFuc2lFbmNvZGluZz4+CmVuZG9iago0IDAgb2JqCjw8L1R5cGUvUGFnZXMvQ291bnQgMS9LaWRzWzEgMCBSXT4+CmVuZG9iago1IDAgb2JqCjw8L1R5cGUvQ2F0YWxvZy9QYWdlcyA0IDAgUj4+CmVuZG9iago2IDAgb2JqCjw8L1Byb2R1Y2VyKGlUZXh0riA1LjUuMTMuMyCpMjAwMC0yMDIyIGlUZXh0IEdyb3VwIE5WIFwoQUdQTC12ZXJzaW9uXCkpL0NyZWF0aW9uRGF0ZShEOjIwMjMxMjIzMTEwMjEwWikvTW9kRGF0ZShEOjIwMjMxMjIzMTEwMjEwWikvVGl0bGUoQWNrbm93bGVkZ21lbnQgTGV0dGVyKT4+CmVuZG9iagp4cmVmCjAgNwowMDAwMDAwMDAwIDY1NTM1IGYgCjAwMDAwMDA2OTMgMDAwMDAgbiAKMDAwMDAwMDgxMSAwMDAwMCBuIAowMDAwMDAwMDE1IDAwMDAwIG4gCjAwMDAwMDA4OTkgMDAwMDAgbiAKMDAwMDAwMDk1MCAwMDAwMCBuIAowMDAwMDAwOTk1IDAwMDAwIG4gCnRyYWlsZXIKPDwvU2l6ZSA3L1Jvb3QgNSAwIFIvSW5mbyA2IDAgUi9JRCBbPGY4ZjZhZDE1NDIxNzBmNjQ1Y2Q3N2NiMDYwZjkzMjkzPjxmOGY2YWQxNTQyMTcwZjY0NWNkNzdjYjA2MGY5MzI5Mz5dPj4KJWlUZXh0LTUuNS4xMy4zCnN0YXJ0eHJlZgoxMTcyCiUlRU9GCg==");
//		fileData.setFileName("SSY_Meera.pdf");
//		downloaderDTO.setFileData(fileData);
//
//		when(bffssaQryServiceMock.getSSAAcknowledgement(sampleSsaDetailsReq())).thenReturn(Mono.just(downloaderDTO));
//		Mono<PDFDownloaderDTO> pDFDownloaderDTO = investmentControllerUnderTest
//				.getSSAAcknowledgementLetter(sampleSsaDetailsReq());
//		verify(bffssaQryServiceMock).getSSAAcknowledgement(sampleSsaDetailsReq());
//		reset(bffssaQryServiceMock);
//
//	}
//
//	@Test
//	void testGetSSAAccountDetails() {
//		SsaAccountRespDTO accountRespDTO = new SsaAccountRespDTO();
//		accountRespDTO.setCif("121212132");
//		accountRespDTO.setRelationWithChild("Father");
//
//		when(bffssaQryServiceMock.getSSAAccountDetails(sampleSsaAccReq())).thenReturn(Mono.just(accountRespDTO));
//		Mono<SsaAccountRespDTO> accountResp = investmentControllerUnderTest.getSSAAccountDetails(sampleSsaAccReq());
//		verify(bffssaQryServiceMock).getSSAAccountDetails(sampleSsaAccReq());
//		reset(bffssaQryServiceMock);
//
//	}
//
//	@Test
//	void testGetSSAStatus() {
//		SsaStatusResponseDTO responseDTO = new SsaStatusResponseDTO();
//		responseDTO.setApplicationFrmNum("190090");
//		responseDTO.setOpsStatus("SUCCESS");
//		Entity entity = new Entity();
//		entity.setCif("7865006");
//		entity.setApplNum("190090");
//		Accounts accounts = new Accounts();
//		accounts.setAcctNum("5670");
//		accounts.setName("MR CHANDU RAJU");
//
//		BankDetails bankDetails = new BankDetails();
//		PostalAddress address = new PostalAddress();
//		address.setAddrLine1("GAUR CITY NOIDA WEST");
//		address.setAddrLine2("SHOP NO.8,9,10,11,12, VKG PALM COURT");
//		address.setAddrLine3("SECTOR 16 C GAUR CITY");
//		address.setAddrLine4("address4");
//		address.setCityCode("ND");
//		address.setPinCode("20301");
//		address.setStateCode("UP");
//		bankDetails.setAddress(address);
//		bankDetails.setBranchId("577995");
//		bankDetails.setBranchSolId("77990");
//		bankDetails.setBranchName("GAUR CITY NOIDA WEST");
//		accounts.setBankInfo(bankDetails);
//		AccountStatus accountStatus = new AccountStatus();
//		accountStatus.setStatusFlg("A");
//		accounts.setAcctStatus(accountStatus);
//		List<Accounts> accountList = new ArrayList<Accounts>();
//		entity.setAccts(accountList);
//		entity.setRelationWithChild("Son");
//		entity.setBirthType("NATURAL");
//		responseDTO.setEntity(entity);
//
//		when(bffssaQryServiceMock.getSSAStatus(sampleSsaDetailsReq())).thenReturn(Mono.just(responseDTO));
//		Mono<SsaStatusResponseDTO> statusResp = investmentControllerUnderTest.getSSAStatus(sampleSsaDetailsReq());
//		verify(bffssaQryServiceMock).getSSAStatus(sampleSsaDetailsReq());
//		reset(bffssaQryServiceMock);
//
//	}
//
//	@Test
//	void testGetSSADetailsToResume() {
//		SsaDetailsResp detailsResp = new SsaDetailsResp();
//		Accounts accounts = new Accounts();
//		accounts.setAcctNum("5670");
//		accounts.setName("MR CHANDU RAJU");
//
//		BankDetails bankDetails = new BankDetails();
//		PostalAddress address = new PostalAddress();
//		address.setAddrLine1("GAUR CITY NOIDA WEST");
//		address.setAddrLine2("SHOP NO.8,9,10,11,12, VKG PALM COURT");
//		address.setAddrLine3("SECTOR 16 C GAUR CITY");
//		address.setAddrLine4("address4");
//		address.setCityCode("ND");
//		address.setPinCode("20301");
//		address.setStateCode("UP");
//		bankDetails.setAddress(address);
//		bankDetails.setBranchId("577995");
//		bankDetails.setBranchSolId("77990");
//		bankDetails.setBranchName("GAUR CITY NOIDA WEST");
//		accounts.setBankInfo(bankDetails);
//		AccountStatus accountStatus = new AccountStatus();
//		accountStatus.setStatusFlg("A");
//		accounts.setAcctStatus(accountStatus);
//		detailsResp.setApplNum("190090");
//		detailsResp.setBirthType("NATURAL");
//		detailsResp.setCif("7865006");
//		detailsResp.setRelationWithChild("Son");
//
//		when(bffssaQryServiceMock.getSSADetailsToResume(sampleSsaDetailsReq())).thenReturn(Mono.just(detailsResp));
//		Mono<SsaDetailsResp> accountResp = investmentControllerUnderTest.getSSADetailsToResume(sampleSsaDetailsReq());
//		verify(bffssaQryServiceMock).getSSADetailsToResume(sampleSsaDetailsReq());
//		reset(bffssaQryServiceMock);
//	}
//
//	@Test
//	void testDownloadStatement() {
//		PDFDownloaderDTO downloaderDTO = new PDFDownloaderDTO();
//		FileData fileData = new FileData();
//		fileData.setData(
//				"JVBERi0xLjQKJeLjz9MKNCAwIG9iago8PC9MZW5ndGggMjk5Mi9GaWx0ZXIvRmxhdGVEZWNvZGU+PnN0cmVhbQp4nI2cUY/bxhWF3/Ur+JgUNUNRokQ+1nYLpEADJN2iD00fNl453tTSOtpdBPn3pai5d879hlAIB4hH3vvNnDPkORtgnV9Xb+9WTdVv13XfV3cPq7/erb5f/bpq6maz76rfVm319/HPf1mtm+ofq//8t6keVptd1Tfd5euPq64b6ra39Wdbb3Z1sx2X45fKb/2rPq3+vTqN2Muv88+rcfPdptoNfb3djsx1u6uH3tafp3V7+fN9vRvG9batN31eflp9xEhG9G3drAUxrve7GaQyrjNHO5Uh0q4k2PpCCBPHKKs4Nnh2glaN2O/rfidGjOv1OiNctaoIM5nhTiSG6wBTGSZEtLqbQ18y5rSQoZeqZyfTzjGdLWlpx2dpvc2MdtPVm0EYpl20xJnMMC3GsH3JVIZryXrd0+RXYMxpIUPvVs9O5vUc6WymZdfLetx3Nw5vM8O1q5YwkxnuR2K4FjCVYVpEb/LU/QqMOS1k5LuNZyfzeo50tqRl0wwhOC5rfctdu2iJM5lhWoxh+5KpDNeS9SZP+/A8kKlayMh3G89Opp1D82PT7epePL2s1VPXrlrCTGa4H128BzKVYVpEr3uq7zqZqoUMvVs9O5kxj8ePjmVsIdZyIk9LdEJA7Hb1RqtpvKxmmEEq4zrjtWCItCsJthYdAJgMHBs8ZPFVBbKlyDO0JzohMNyJxHAdYCrDhLhWcXPoS8acFjL0Utn8A/0IfXUs8wp5xg5FJwSGaTGG7UumMlyL6RVPJ7/AmNNCht4t+1+ZyOKrFmRLkWfoUHRCYLgfieFawFSGaXG97mnyC4w5LWTku2X/RyayeNJS5BXyjB2KTggM02IM25dMZbgW0+ue9uF5IFO1kJHvlv3fF89Y7KvQCcxv5nvWEmYyw/3o4j2QqQzT4nrFU33XyVQtZOjdsv+ZH5bH00fHMrYQa5bIaRk6AYiuqXdaTd263q5nkMq4zngtGCLtSoKtRQcAJgPHBi9ksalAthR5hvYMnQCGO5EYrgNMZZgQ1ypuDn3JmNNChl4qm3+gH6GvjmVeIc/YoaETwDAtxrB9yVSGazG94unkFxhzWsjQu2X/KzNksWlBthR5hg4NnQCG+5EYrgVMZZgW1+ueJr/AmNNCRr5b9n9khixOWoq8Qp6xQ0MngGFajGH7kqkM12J63dM+PA9kqhYy8t2y//viGYt9JZ3A/Ga+q5YwkxnuRxfvgUxlmBbXK57qu06maiFD75b9z/ywPJ4+OpaxhVizRE7L0AlAbLb1oNU0Prz77QxSGdcZrwVDpF1JsLXoAMBk4NjghSw2FciWIs/QnqETwHAnEsN1gKkME+Jaxc2hLxlzWsjQS2XzD/Qj9NWxzCvkGTs0dAIYpsUYti+ZynAtplc8nfwCY04LGXq37H9lhiw2LciWIs/QoaETwHA/EsO1gKkM0+J63dPkFxhzWsjId8v+j8yQxUlLkVfIM3Zo6AQwTIsxbF8yleFaTK972ofngUzVQka+W/Z/Xzxjsa+kE5jfzHfVEmYyw/3o4j2QqQzT4nrFU33XyVQtZOjdsv+ZH5bH00fHMrYQa5bIaRk6AYj1UG+0mtqmbnYzSGVcZ7wWDJF2JcHWogMAk4Fjgxey2FQgW4o8Q3uGTgDDnUgM1wGmMkyInUvdHPqSMaeFDL1UNv9AP0JfHcu8Qp6xQ0MngGFajGH7kqkM15LOpZ5e9iVjTgsZerfsf2WGLDYtyJYiz9ChoRPAcD8Sw7WAqQzTYufKnl73JWNOCxn5btn/kRmyOGkp8gp5xg4NnQCGaTGG7UumMlxLOlf2tA/PA5mqhYx8t+z/vnjGYl9JJzC/me+qJcxkhvvRxXsgUxmmxc6lnuq7TqZqIUPvlv3P/EgBfP3oWMYWYi0lsi21E4hoNpfLyYhme7mMEqmM64zXgiHSriTYWnQAYDJwbPA0i10FsqXIM7SndgIZ7kRiuA4wlWFCXKu4OfQlY04LGXqpbP6BfoS+OpZ5hTxjh2onkGFajGH7kqkM12J6xdPJLzDmtJChd8v+V6ZmsWtBthR5hg7VTiDD/UgM1wKmMkyL63VPk19gzGkhI98t+z8yNYtNS5FXyDN2qHYCGabFGLYvmcpwLabXPe3D80CmaiEj3y37vy+esdhXuROY38z3oCXMZIb70cV7IFMZpsX1iqf6rpOpWsjQu2X/Mz8sj6ePjmVsIdYskdMydEJEdP2+HqSaur6v9+sZpDDSjNWCI667kuDrrAMAl4Fjgxey2FQgW4o8Q3uGToiM7MSVkXWAKQwX4lrFzaEvGHNayAiXyuYf6Efoq2OZV8gzdmjohMhwLYnh+5IpjKzF9Iqnk1+RMaeFjHC37H9lhiw2LciWIs/QoaETIiP7cWVkLWAKw7W4Xvc0+RUZc1rIkLtl/0dmyOKkpcgr5Bk7NHRCZLiWxPB9yRRG1mJ63dM+PA9kihYy5G7Z/33xjMW+kk5gfjPfVUuYcUb2o4v3QKYwXIvrFU/1XSdTtJAR7pb9z/ywPJ4+OpaxhVizRE7L0AlA7Nu6lWrq9pvrDz0TqYzrjPeKIdKuJNhadABgMnBs8EIWmwpkS5FnaM/QCWC4E4nhOsBUhglxreLm0JeMOS1k6KWy+Qf6EfrqWOYV8owdGjoBDNNiDNuXTGW4FtMrnk5+gTGnhQy9W/a/MkMWmxZkS5Fn6NDQCWC4H4nhWsBUhmlxve5p8guMOS1k5Ltl/0dmyOKkpcgr5Bk7NHQCGKbFGLYvmcpwLabXPe3D80CmaiEj3y37vy+esdhX0gnMb+a7agkzmeF+dPEeyFSGaXG94qm+62SqFjL0btn/zA/L4+mjYxlbiDVL5LQMnQDEeOCdVlO3rze7GaQyrjNeC4ZIu5Jga9EBgMnAscELWWwqkC1FnqE9QyeA4U4khusAUxkmxLWKm0NfMua0kKGXyuYf6Efoq2OZV8gzdmjoBDBMizFsXzKV4VpMr3g6+QXGnBYy9G7Z/8oMWWxakC1FnqFDQyeA4X4khmsBUxmmxfW6p8kvMOa0kJHvlv0fmSGLk5Yir5Bn7NDQCWCYFmPYvmQqw7WYXve0D88DmaqFjHy37P++eMZiX0knML+Z76olzGSG+9HFeyBTGabF9Yqn+q6TqVrI0Ltl/zM/3t6tvvnbulr31d34Ak5/W3Jdteu+7rtq30+gu+Pqq3+dHp9O1dv70/+qp4/Vt6eHx/uv7365/E1OA7QK2LbVvpv+q+ky/M+X+5fD8XB60ZF2ZqTd110/jbw/3J+rd6/PL0/Hw7n68avdvt+Nv/Y/fv3n6svnw/3zofr4eHqofjp8fvqterYNqo9P5+r+mw83N9rU68sPY49+7qe97s73p+f7Dy8Xhe9H0K3h9XjEfZj+4fDxcD6cPtwe2/eXK5Kx94fnD+fHL5dNbw1eXunpR9rzaX//cnOrdjdcf6jdJ/5yfHq97f1m3UDVu9fzRdTvC4zcN3U3zbRNu3mzXr9Z75Y46GN3P3zXNJsl7vnI26fT6/MS23zi3fnw8HjTA/PNRzZNUzdLXPOJb7/7YYFf43vRb6Jh3RLD8tzk2HaJY3lmsWV55P3hp2WW5ZE3+66+KcY8yyPLTNuMO+Epu21AMi3PTabdNjqZlmcWm5ZHlj9oeWbdjI/afpFveWiZb+2m3u6jb7dfteRbnpt8u/1GJ9/yzGLf8sjihy2PvOmaul3kWp5Z5lozfl8ZTWuXmOZjk2f7JZ75yGLLfGL5k+Yju6WR5hOL/OqG9vKvYNh6gWEyNznWL3BMZpZaJiNLnzIZGe9+mWkys8y1/a7eItNu7mOu5bnJtWGJa3lmsWt5ZPGTFiQ1i5pARpa5thvHYqL9gQPJtTx3ce0PnE6u5ZnFruWRxc9aHnnTL+wBmfkj19pqOz6YXTt98Z+qu0+Pz9X4z4en45fXl/F7658Pp8N5/K73oXp4+vA6fRN9f7osDs/V6emlOh9+fX08H6rnx59P9y+vZ/vm8/J/cPl+9X96HADXCmVuZHN0cmVhbQplbmRvYmoKMSAwIG9iago8PC9UeXBlL1BhZ2UvTWVkaWFCb3hbMCAwIDU5NS4yOCA4NDEuODhdL1Jlc291cmNlczw8L0ZvbnQ8PC9GMSAyIDAgUi9GMiAzIDAgUj4+Pj4vQ29udGVudHMgNCAwIFIvUGFyZW50IDUgMCBSPj4KZW5kb2JqCjggMCBvYmoKPDwvVGl0bGUoU3RhdGVtZW50KS9QYXJlbnQgNyAwIFIvRGVzdFsxIDAgUi9YWVogMCA3NjUuNiAwXT4+CmVuZG9iago3IDAgb2JqCjw8L1RpdGxlKFVuaW9uIEJhbmsgb2YgSW5kaWEpL1BhcmVudCA2IDAgUi9GaXJzdCA4IDAgUi9MYXN0IDggMCBSL0Rlc3RbMSAwIFIvWFlaIDAgNzk5Ljg4IDBdL0NvdW50IDE+PgplbmRvYmoKNiAwIG9iago8PC9UeXBlL091dGxpbmVzL0ZpcnN0IDcgMCBSL0xhc3QgNyAwIFIvQ291bnQgMj4+CmVuZG9iagoyIDAgb2JqCjw8L1R5cGUvRm9udC9TdWJ0eXBlL1R5cGUxL0Jhc2VGb250L1RpbWVzLUJvbGQvRW5jb2RpbmcvV2luQW5zaUVuY29kaW5nPj4KZW5kb2JqCjMgMCBvYmoKPDwvVHlwZS9Gb250L1N1YnR5cGUvVHlwZTEvQmFzZUZvbnQvVGltZXMtUm9tYW4vRW5jb2RpbmcvV2luQW5zaUVuY29kaW5nPj4KZW5kb2JqCjUgMCBvYmoKPDwvVHlwZS9QYWdlcy9Db3VudCAxL0tpZHNbMSAwIFJdPj4KZW5kb2JqCjkgMCBvYmoKPDwvVHlwZS9DYXRhbG9nL1BhZ2VzIDUgMCBSL091dGxpbmVzIDYgMCBSL1BhZ2VNb2RlL1VzZU91dGxpbmVzPj4KZW5kb2JqCjEwIDAgb2JqCjw8L1Byb2R1Y2VyKGlUZXh0riA1LjUuMTMuMyCpMjAwMC0yMDIyIGlUZXh0IEdyb3VwIE5WIFwoQUdQTC12ZXJzaW9uXCkpL0NyZWF0aW9uRGF0ZShEOjIwMjMxMjIzMTI1MTU2WikvTW9kRGF0ZShEOjIwMjMxMjIzMTI1MTU2WikvVGl0bGUoU3RhdGVtZW50KT4+CmVuZG9iagp4cmVmCjAgMTEKMDAwMDAwMDAwMCA2NTUzNSBmIAowMDAwMDAzMDc1IDAwMDAwIG4gCjAwMDAwMDM0NjEgMDAwMDAgbiAKMDAwMDAwMzU1MCAwMDAwMCBuIAowMDAwMDAwMDE1IDAwMDAwIG4gCjAwMDAwMDM2NDAgMDAwMDAgbiAKMDAwMDAwMzM5NiAwMDAwMCBuIAowMDAwMDAzMjc4IDAwMDAwIG4gCjAwMDAwMDMyMDIgMDAwMDAgbiAKMDAwMDAwMzY5MSAwMDAwMCBuIAowMDAwMDAzNzcyIDAwMDAwIG4gCnRyYWlsZXIKPDwvU2l6ZSAxMS9Sb290IDkgMCBSL0luZm8gMTAgMCBSL0lEIFs8NTNkMmRhMWNiZGU4MTU0YmU2ODdhZmQ5OGYzMmMyYmE+PDUzZDJkYTFjYmRlODE1NGJlNjg3YWZkOThmMzJjMmJhPl0+PgolaVRleHQtNS41LjEzLjMKc3RhcnR4cmVmCjM5MzgKJSVFT0YK");
//		fileData.setFileName("6786XXXX.pdf");
//		downloaderDTO.setFileData(fileData);
//
//		when(bffssaQryServiceMock.downloadStatement(sampleEmailReq())).thenReturn(Mono.just(downloaderDTO));
//		Mono<PDFDownloaderDTO> pDFDownloaderDTO = investmentControllerUnderTest.downloadStatement(sampleEmailReq());
//		verify(bffssaQryServiceMock).downloadStatement(sampleEmailReq());
//		reset(bffssaQryServiceMock);
//
//	}
//
//	@Test
//	void testCheckExistingAccounts() {
//		ExistingAccountReq existingAccountReq = new ExistingAccountReq();
//		existingAccountReq.setCif("7865006");
//
//		ExistingAccountsResp existingAccountsResp = new ExistingAccountsResp();
//
//		ExistingAccounts existingAccounts = new ExistingAccounts();
//		existingAccounts.setAcctNum("5670");
//		existingAccounts.setName("MR CHANDU RAJU");
//		List<ExistingAccounts> list = new ArrayList<ExistingAccounts>();
//		list.add(existingAccounts);
//		existingAccountsResp.setAccts(list);
//
//		when(bffssaQryServiceMock.checkExistingAccounts(existingAccountReq))
//				.thenReturn(Mono.just(existingAccountsResp));
//		Mono<ExistingAccountsResp> resp = investmentControllerUnderTest.checkExistingAccounts(existingAccountReq);
//		verify(bffssaQryServiceMock).checkExistingAccounts(existingAccountReq);
//		reset(bffssaQryServiceMock);
//	}
//
//	@Test
//	void testInvestmentAccounts() {
//
//		ExistingAccountReq existingAccountReq = new ExistingAccountReq();
//		existingAccountReq.setCif("7865006");
//		InvestmentAccountsResp accountsList = new InvestmentAccountsResp();
//		InvestAccounts accounts = new InvestAccounts();
//		accounts.setCif("7865777");
//		accounts.setAcctNum("5670");
//		accounts.setCustomerName("MR CHANDU RAJU");
//		accounts.setAcctName(" CHAND RAJU");
//		accounts.setAcctType("SSY");
//		accounts.setActiveFlag(false);
//
//		List<InvestAccounts> expectedResponse = new ArrayList<InvestAccounts>();
//		expectedResponse.add(accounts);
//
//		when(bffssaQryServiceMock.getInvestmentAccounts(existingAccountReq)).thenReturn(Mono.just(accountsList));
//
//		Mono<InvestmentAccountsResp> resp = investmentControllerUnderTest.getInvestmentAccounts(existingAccountReq);
//		verify(bffssaQryServiceMock).getInvestmentAccounts(existingAccountReq);
//		reset(bffssaQryServiceMock);
//	}
//
//	@Test
//	void testPaymentStatus() {
//		when(bffssaQryServiceMock.getPaymentStatus(samplePaymentStatusReq())).thenReturn(Mono.just(samplePaymentStatusResp()));
//		
//		Mono<PaymentStatusResp> actual = investmentControllerUnderTest.getPaymentStatus(samplePaymentStatusReq());
//		
//		verify(bffssaQryServiceMock).getPaymentStatus(samplePaymentStatusReq());
//		
//		reset(bffssaQryServiceMock);
//	}
//	
//	@Test
//	void testValidateContribution() {
//		when(bffssaQryServiceMock.validateContribution(sampleValidateReq())).thenReturn(Mono.just(sampleValidateAmountResp()));
//		
//		Mono<ValidateAmountResp> actual = investmentControllerUnderTest.validateContribution(sampleValidateReq());
//		
//		verify(bffssaQryServiceMock).validateContribution(sampleValidateReq());
//		
//		reset(bffssaQryServiceMock);
//	}
//	
//	@Test
//	void testGetSSATermsAndCondition() {
//		when(bffssaQryServiceMock.getSSATermsAndCondition(sampleTAndCRequest())).thenReturn(Mono.just(sampleFileData()));
//		
//		Mono<FileData> actual = investmentControllerUnderTest.getSSATermsAndCondition(sampleTAndCRequest());
//		
//		verify(bffssaQryServiceMock).getSSATermsAndCondition(sampleTAndCRequest());
//		
//		reset(bffssaQryServiceMock);
//	}
//	
//	@Test
//	void testdownload() {
//		when(bffssaQryServiceMock.downloadDocuments(sampleDownloadReq())).thenReturn(Mono.just(sampleDownloadResp()));
//		
//		Mono<DownloadResp> actual = investmentControllerUnderTest.downloadDocuments(sampleDownloadReq());
//		
//		verify(bffssaQryServiceMock).downloadDocuments(sampleDownloadReq());
//		
//		reset(bffssaQryServiceMock);
//	}
//}
