//package com.ubi.dbp.investment.apy.bff.test;
//
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.junit.jupiter.api.Assertions.assertNotNull;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.test.context.TestPropertySource;
//
//import com.ubi.dbp.investment.apy.bff.config.InvestmentBFFAppApyCmdConfig;
//
//@SpringBootTest
//@TestPropertySource(properties = {
//        "ssa.command.service.base.url=http://test-base-url",
//        "ssa.command.service.investment.path=/test-investment-path",
//        "ssa.command.service.ssa.save=test-save-ssa",
//        "ssa.command.service.ssa.open=test-open-ssa",
//        "ssa.command.service.ssa.contribution=test-contribution",
//        "ssa.command.service.ssa.upload=test-upload",
//        "ssa.command.service.ssa.remove=test-remove"
//})
//public class InvestmentBFFAppApyCmdConfigTest {
//
//    @Autowired
//    private InvestmentBFFAppApyCmdConfig config;
//
//    @Test
//    public void testSsaCmdSvcBaseUrl() {
//        assertEquals("http://test-base-url", config.getSsaCmdSvcBaseUrl());
//    }
//
//    @Test
//    public void testSsaCmdInvestmentPath() {
//        assertEquals("/test-investment-path", config.getSsaCmdInvestmentPath());
//    }
//
//    @Test
//    public void testSaveSsa() {
//        assertEquals("test-save-ssa", config.getSaveSsa());
//    }
//
//    @Test
//    public void testOpenSsa() {
//        assertEquals("test-open-ssa", config.getOpenSsa());
//    }
//
//    @Test
//    public void testContribution() {
//        assertEquals("test-contribution", config.getContribution());
//    }
//    
//    @Test
//    public void testUpload() {
//        assertEquals("test-upload", config.getUpload());
//    }
//    
//    @Test
//    public void testRemove() {
//        assertEquals("test-remove", config.getRemove());
//    }
//
//    @Test
//    public void testNonNullValues() {
//        assertNotNull(config.getSsaCmdSvcBaseUrl());
//        assertNotNull(config.getSsaCmdInvestmentPath());
//        assertNotNull(config.getSaveSsa());
//        assertNotNull(config.getOpenSsa());
//        assertNotNull(config.getContribution());
//        assertNotNull(config.getUpload());
//        assertNotNull(config.getRemove());
//    }
//}
