//package com.ubi.dbp.investment.apy.bff.test;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.server.reactive.ServerHttpResponse;
//import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
//import org.springframework.mock.web.server.MockServerWebExchange;
//import org.springframework.test.web.reactive.server.WebTestClient;
//import org.springframework.web.server.ServerWebExchange;
//import org.springframework.web.server.WebFilterChain;
//
//import com.ubi.dbp.investment.apy.bff.config.ContentLengthFilter;
//
//import reactor.core.publisher.Mono;
//
//public class ContentLengthFilterTest {
//
//    @Test
//    void filterShouldAddContentLengthHeader() {
//        // Create an instance of ContentLengthFilter
//        ContentLengthFilter contentLengthFilter = new ContentLengthFilter();
//
//        // Create a mock ServerWebExchange for testing
//        MockServerHttpRequest request = MockServerHttpRequest.get("/test").build();
//        ServerWebExchange exchange = MockServerWebExchange.from(request);  // Updated this line
//
//        // Create a mock WebFilterChain for testing
//        WebFilterChain filterChain = (filterExchange) -> {
//            // Simulate processing the request
//            ServerHttpResponse serverHttpResponse = filterExchange.getResponse();
//            serverHttpResponse.setStatusCode(HttpStatus.OK);
//            serverHttpResponse.getHeaders().setContentLength(42L);
//
//            return Mono.empty();
//        };
//
//        // Call the filter method and verify the Content-Length header is added
//        contentLengthFilter.filter(exchange, filterChain).block();
//        Long actualContentLength = exchange.getResponse().getHeaders().getContentLength();
//        assert actualContentLength != null;
//        assert actualContentLength.equals(42L);
//    }
//
//    @Test
//    void webTestClientShouldApplyFilter() {
//        // Create an instance of ContentLengthFilter
//        ContentLengthFilter contentLengthFilter = new ContentLengthFilter();
//
//        // Create a WebTestClient to test the filter in a more integrated way
//        WebTestClient webTestClient = WebTestClient.bindToController(new TestController())
//                .webFilter(contentLengthFilter)
//                .build();
//
//        // Perform a request and verify the Content-Length header is present in the response
//        webTestClient.get()
//                .uri("/test")
//                .exchange();
////                .expectStatus().isOk()
////                .expectHeader().contentLength(42L);
//    }
//
//    // Example controller for testing
//    static class TestController {
//    }
//}
