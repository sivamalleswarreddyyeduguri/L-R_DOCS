//package com.ubi.dbp.investment.apy.bff.dto;
//
//import com.ubi.dbp.investment.ssa.model.SsaResponse;
//
//import io.swagger.v3.oas.annotations.media.Schema;
//import lombok.AllArgsConstructor;
//import lombok.Data;
//import lombok.NoArgsConstructor;
//
//@Data
//@AllArgsConstructor
//@NoArgsConstructor
//public class ApyOpenSaveStatusResp {
//
//	@Schema(required = true, description = "opsStatus",example = "SUCCESS/FAILED")
//	private String opsStatus;
//	@Schema(required = true, description = "applicationFrmNum",example = "70000012344567")
//	private String applicationFrmNum;
//	@Schema(required = false, description = "transRefNumber",example = "70000012344567")
//	private String transRefNumber;
//	@Schema(required = true, description = "entity")
//	private SsaResponse entity;
//}
