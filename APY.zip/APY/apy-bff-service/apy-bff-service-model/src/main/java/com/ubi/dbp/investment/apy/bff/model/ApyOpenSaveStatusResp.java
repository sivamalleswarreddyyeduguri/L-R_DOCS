package com.ubi.dbp.investment.apy.bff.model;

public class ApyOpenSaveStatusResp {

}
