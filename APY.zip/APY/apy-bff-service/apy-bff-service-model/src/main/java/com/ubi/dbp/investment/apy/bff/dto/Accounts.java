package com.ubi.dbp.investment.apy.bff.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Accounts {
	private String acctNum;
	private String name;
	AccountStatus acctStatus;
	BankDetails bankInfo;
}
