package com.ubi.dbp.investment.apy.bff.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class NomineeInfo {
    private String firstName;
    //dob gender field not available in db
    //private String middleName;
    //private String lastName;
    //private String accountType;
    private BigDecimal allocationPercent;
    //private String relationshipCode;
    private String relationship;
    //private Integer age;
    private String dateOfBirth;
    //private Boolean isSameAddr;
    private String addressline1;
    private String addressline2;
    private String addressline3;
    private String addressline4;
    private String addressPincode;
    //private String cityCode;
    private String city;
    //private String districtCode;
    private String district;
    private String stateCode;
    private String state;
    //private Boolean minorFlag;
    //private String guardianRelationshipCode;
    private String guardianRelationship;
    private String guardianFirstName;
    //private String guardianMiddleName;
    //private String guardianLastName;
    //private LocalDateTime guardianDateOfBirth;
    //private Integer guardianAge;
    private String guardianAddressline1;
    private String guardianAddressline2;
    private String guardianAddressline;
    private String guardianAddressline4;
    private String guardianAddressPincode;
    //private String guardianCityCode;
    private String guardianCity;
    //private String guardianDistrictCode;
    private String guardianDistrict;
    //private String guardianStateCode;
    private String guardianState;
	
//	public boolean isEmpty()  {
//
//	    for (Field field : this.getClass().getDeclaredFields()) {
//	        try {
//	            field.setAccessible(true);
//	            if (field.get(this)!=null) {
//	                return false;
//	            }
//	        } catch (Exception e) {
//	          e.printStackTrace();
//	        }
//	    }
//    	return true;
//    }
}
