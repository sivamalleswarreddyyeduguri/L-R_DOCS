package com.ubi.dbp.investment.apy.bff.dto;

import lombok.Data;

@Data
public class SaveResponse {
	private String opsStatus;
	private String applicationFrmNum;
}
