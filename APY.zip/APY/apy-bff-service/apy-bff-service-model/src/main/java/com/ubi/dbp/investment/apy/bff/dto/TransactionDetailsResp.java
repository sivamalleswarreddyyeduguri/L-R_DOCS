package com.ubi.dbp.investment.apy.bff.dto;

import java.util.List;

import lombok.Data;

@Data
public class TransactionDetailsResp {
	private String cif;
	private String hasMoreData;
	private List<TransactionDetails> transactions;
}
