package com.ubi.dbp.investment.apy.bff.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AccountsDetailsForJourney {
	
	private String acctNum;
	private String name;
	AccountStatus acctStatus;
//	private LocalDate acctOpenDate;
	BankDetails bankInfo;
	BeneficiaryDetails beneficiary;

}
