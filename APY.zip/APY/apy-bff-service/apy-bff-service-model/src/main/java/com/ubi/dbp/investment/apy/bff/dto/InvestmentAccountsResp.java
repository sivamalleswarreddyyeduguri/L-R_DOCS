package com.ubi.dbp.investment.apy.bff.dto;

import java.math.BigDecimal;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class InvestmentAccountsResp {
	//private List<InvestAccounts> investmentAccts ;
	private String cif ;
	//private String acctNum;
	private String customerName;
	private String pran;
	private BigDecimal acctBal;
}
