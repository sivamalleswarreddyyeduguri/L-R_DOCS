package com.ubi.dbp.investment.apy.bff.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Data
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class ApyRequest {
    String cif,acctNum,nameOfSub,dob;

}
