package com.ubi.dbp.investment.apy.bff.model;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.ToString;


@ToString
@Data
public class BeneficiaryDetailsForSave {
	@Schema(required = false, description = "dob")
	private String dob;
	@Schema(required = true, description = "first name")
	private String fname;
	private String mname;
	@Schema(required = true, description = "last name")
	private String lname;
	@Schema(required = true, description = "relationship")
	private String relShipId;	
	@Schema(required = true, description = "isSameAddr")
	private String isSameAddr;
	@Schema(required = true, description = "contact details")
	ContactDetailsForSave contactInfo;
}
