package com.ubi.dbp.investment.apy.bff.model;

import dbp.framework.common.investment.model.InvestmentContribution;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;

@Data
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@AllArgsConstructor
public class ApyContributionDetails extends InvestmentContribution {
	private String monthlyPensionAmt;
	private String contribFrequency;
	private String premiumPayable;
	private String contribYears;
	private List<String> financialYears;
	private LocalDate fromDate;
	private LocalDate toDate;
}
