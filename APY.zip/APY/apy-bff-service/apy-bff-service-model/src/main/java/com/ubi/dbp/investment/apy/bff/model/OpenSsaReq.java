package com.ubi.dbp.investment.apy.bff.model;

import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;


@ToString
@Data
@NoArgsConstructor
@AllArgsConstructor
public class OpenSsaReq {
	private String rqType;
	private String referenceNum;
	@NotNull
	@NotBlank
	@Schema(required = true, description = "cif")
	private String cif;
	@NotNull
	@NotBlank
	@Schema(required = true, description = "applNum")
	private String applNum;
	@NotNull
	@NotBlank
	@Schema(required = true, description = "channel")
	private String channel;
	@NotNull
	@NotBlank
	@Schema(required = true, description = "birth type")
	private String birthType;
	@NotBlank
	@Schema(required = true, description = "birthOrder")
	@NotBlank
	private String birthOrder;
	@NotNull
	@NotBlank
	@Schema(required = true, description = "source")
	SourceInfo source;
	@NotNull
	@NotBlank
	@Schema(required = true, description = "bank information")
	BankInfo bankInfo;
	@NotNull
	@NotBlank
	@Schema(required = true, description = "customer details")
	CustomerInfo customer;
	@NotNull
	@NotBlank
	@Schema(required = true, description = "beneficiary details")
	BeneficiaryDetails beneficiary;
	List<Documents> documents;
	@NotNull
	@NotBlank
	@Schema(required = true, description = "declaration details")
	DeclarationInfo declarationDetails;

}

