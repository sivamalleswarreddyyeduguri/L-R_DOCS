package com.ubi.dbp.investment.apy.bff.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class InvestmentAccountApy {
    private String cif;
    private String applicationFormNumber;
    private String accountNumber;
    //private Boolean activeFlag;
    private String branchAddressPincode;
    private String branchAddressline1;
    private String branchAddressline2;
    private String branchAddressline3;
    private String branchAddressline4;
    private String branchCity;
    //private String branchCityCode;
    //private String branchCode;
    private String branchDistrict;
    //private String branchDistrictCode;
    private String branchName;
    private String branchPostoffice;
    //private String branchSolId;
    private String branchState;
    //private String branchStateCode;
    //rivate String branchSubDistrict;
    //private String branchWorkingDays;
    //private String branchWorkingHrs;
    //private String channel;
    private String contrubutionFrequency;
    private Integer contributionPeriod;
    //private String createdBy;
    //private LocalDateTime createdDate;
    //private LocalDateTime dateOfDeposit;
    //private LocalDateTime declarationDate;
    //private Boolean declarationIndicator;
    //private Boolean incomeTaxFlag;
    //private String martialStatus;
    //private String modifiedBy;
    //private LocalDateTime modifiedDate;
    private String name;
    private NomineeInfo nomineeDetail;
    //private Boolean notificationIndicator;
    //private String paymentMode;
    private BigDecimal pensionAmount;
    //private String pranNumber;
    private BigDecimal premium;
    //private Boolean setMandateFlag;
    private String sourceAccountName;
    private String sourceAccountNumber;
    //private String status;
    //private String transRefNumber;


}
