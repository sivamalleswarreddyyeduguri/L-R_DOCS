package com.ubi.dbp.investment.apy.bff.dto;

import java.util.Map;
import java.util.Optional;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DownloadResp {
	private String fileName;
	private String content;
	private Map<String,String> metadata;
}
