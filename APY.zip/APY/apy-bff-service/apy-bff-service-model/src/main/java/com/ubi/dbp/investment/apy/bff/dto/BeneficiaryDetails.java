package com.ubi.dbp.investment.apy.bff.dto;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BeneficiaryDetails {
	private String fname;
	private String mname;
	private String lname;
	private LocalDate dob;
	BeneficiaryContactInfo contactInfo;
	private String birthType;
	private String birthOrder;
	private Boolean isSameAddr;
}
