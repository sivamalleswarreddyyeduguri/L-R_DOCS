package com.ubi.dbp.investment.apy.bff.model;

import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SaveSsaReq {
	@NotNull
	@NotBlank
	@Schema(required = true, description = "cif")
	private String cif;
	private String applNum;
	@NotNull
	@NotBlank
	@Schema(required = true, description = "source")
	SourceInfo source;
	@NotNull
	@NotBlank
	@Schema(required = true, description = "bankInfo")
	BankInfo bankInfo;
	@NotNull
	@NotBlank
	@Schema(required = true, description = "customer details")
	CustomerInfo customer;
	BeneficiaryDetailsForSave beneficiary;
	List<Documents> documents;
	private String birthType;
	private String birthOrder;
	@NotNull
	@NotBlank
	@Schema(required = true, description = "channel")
	private String channel;
}
