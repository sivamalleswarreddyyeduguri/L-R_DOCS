package com.ubi.dbp.investment.apy.bff.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ApyStatusResponse {
	private String opsStatus;
	private String applicationFrmNum;
	private String pranNum;
	private String transRefNum;
	private Entity entity;

}
