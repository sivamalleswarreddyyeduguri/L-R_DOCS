package com.ubi.dbp.investment.apy.bff.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class GenericResponse<T> {


    private String status;
    private String errorDescription;
    protected T data;
}