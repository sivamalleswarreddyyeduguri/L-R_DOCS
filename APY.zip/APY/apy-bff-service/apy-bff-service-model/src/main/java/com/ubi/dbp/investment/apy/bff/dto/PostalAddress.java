package com.ubi.dbp.investment.apy.bff.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PostalAddress {
	@Schema(required = true, description = "addrLine1 ")
	private String addrLine1;
	@Schema(required = true, description = "addrLine2 ")
	private String addrLine2;
	private String addrLine3;
	private String addrLine4;
	@Schema(required = true, description = "pinCode ")
	private String pinCode;
	@Schema(required = true, description = "cityCode ")
	private String cityCode;
	@Schema(required = true, description = "stateCode ")
	private String stateCode;

}
