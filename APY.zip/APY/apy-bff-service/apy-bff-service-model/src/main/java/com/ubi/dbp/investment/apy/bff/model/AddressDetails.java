package com.ubi.dbp.investment.apy.bff.model;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AddressDetails {
	@Schema(required = true, description = "addrLine1 required for open and within flow required for save ")
	private String addrLine1;
	@Schema(required = true, description = "addrLine2 required for open and within flow required for save")
	private String addrLine2;
	private String addrLine3;
	private String addrLine4;
	@Schema(required = true, description = "pinCode required for open and within flow required for save")
	private String pinCode;
	@Schema(required = true, description = "cityCode required for open and within flow required for save")
	private String cityCode;
	@Schema(required = true, description = "city required for open and within flow required for save")
	private String city;
	@Schema(required = true, description = "stateCode required for open and within flow required for save")
	private String stateCode;
	@Schema(required = true, description = "state required for open and within flow required for save")
	private String state;

}