package com.ubi.dbp.investment.apy.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;


@Data
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class TodoResponse {
	private Integer userId;
	private Integer id;
	private String title;
	private Boolean completed;
	}
