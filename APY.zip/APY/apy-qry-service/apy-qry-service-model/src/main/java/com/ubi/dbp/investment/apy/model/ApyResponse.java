package com.ubi.dbp.investment.apy.model;

import java.math.BigDecimal;
import dbp.framework.common.investment.model.InvestmentResponse;
import dbp.framework.common.model.Person;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ApyResponse extends InvestmentResponse{

	private String rqType;		//Request Type -- ACCT_OPERATION or CONTRIBUTION to identify message request type at Proxy level
	private BigDecimal currFYContriAmt;		//Current FY Contribution for Apy
	private BigDecimal penaltyAmt;		//Current penalty for Apy
	private Boolean isSuccess;
	private Person person;
	private ApyContributionDetails investmentContribution;
	private String contribStatus;		//For overall contribution status
	private String message;	//For error / desc messages
    private String pranNum;  //pran Number
}