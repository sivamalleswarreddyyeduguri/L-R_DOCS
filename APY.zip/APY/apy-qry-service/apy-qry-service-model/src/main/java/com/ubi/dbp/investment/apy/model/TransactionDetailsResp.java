package com.ubi.dbp.investment.apy.model;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;


@Data
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class TransactionDetailsResp {
	private List<TransactionDetails> transactions;
	private String cif;
	private String hasMoreData;
	}
