package com.ubi.dbp.investment.apy.model;

import lombok.*;

@Data
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class GetStatusReq {

    String cif;

}
