package com.ubi.dbp.investment.apy.model;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;


@Data
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class TransactionReq {
	//@Schema(required = true, description = "cif")
	private String cif;
	//@Schema(required = true, description = "startDate")
	private LocalDateTime startDate;
	//@Schema(required = true, description = "acctNum")
	private String acctNum;
	//@Schema(required = true, description = "endDate")
	private LocalDateTime endDate;
	}
