package com.ubi.dbp.investment.apy.model;

import dbp.framework.common.investment.model.InvestmentAcct;
import dbp.framework.common.investment.model.InvestmentAcctBuilder;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = true)
//@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Apy extends InvestmentAcct {
	
	public static enum RqTypes {
		ACCT_OPEN("ACCT_OPEN"), CONTRIBUTION("CONTRIBUTION"), OTH("OTH");
		public String rqType;
		private RqTypes(String rqType) {
			this.rqType = rqType;
		}
		public static RqTypes byRq(String rq) {
			for(RqTypes rqTyp : RqTypes.values()) {
				if(rq.equals(rqTyp.rqType))
					return rqTyp;
			}
			return OTH;
		}
	}
	
	String rqType;		//Request Type -- ACCT_OPERATION or CONTRIBUTION to identify meapyge request type at Proxy level
	String referenceNum; //GBM reference number to be passed
	String relationship; //relationship with investor
	ApyContributionDetails investmentContribution; //For contribution

	public static class Builder extends InvestmentAcctBuilder {
		private String rqType;
		private String referenceNum;
		private String relationship;
		private ApyContributionDetails investmentContribution;
		
		public Builder referenceNum(String referenceNum) {
			this.referenceNum = referenceNum;
			return this;
		}


		public Builder relationship(String relationship) {
			this.relationship = relationship;
			return this;
		}

		public Builder rqType(String rqType) {
			this.rqType = rqType;
			return this;
		}

		public Builder investmentContribution(ApyContributionDetails investmentContribution) {
			this.investmentContribution = investmentContribution;
			return this;
		}

		public Apy build() {
			return new Apy(this);
		}
	}


	private Apy(Builder builder) {
		super(builder);
		this.rqType = builder.rqType;
		this.referenceNum = builder.referenceNum;
		this.relationship = builder.relationship;
		this.investmentContribution = builder.investmentContribution;
	}
}
