package com.ubi.dbp.investment.apy.model;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;


@Data
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class TransactionDetails {
	private String id;
	private String acctNum;
	private LocalDateTime transactionDate;
	private LocalDateTime valueDate;
	private BigDecimal amount;
	private String transactionType;
	private String transactionCurrencyCode;
	private String transactionStatus;
	}
