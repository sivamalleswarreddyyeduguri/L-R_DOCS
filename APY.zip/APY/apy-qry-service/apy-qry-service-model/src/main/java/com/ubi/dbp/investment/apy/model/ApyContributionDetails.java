package com.ubi.dbp.investment.apy.model;

import java.time.LocalDate;
import java.util.List;

import dbp.framework.common.investment.model.InvestmentContribution;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@AllArgsConstructor
public class ApyContributionDetails extends InvestmentContribution {
	private String monthlyPensionAmt;
	private String contribFrequency;
	private String premiumPayable;
	private String contribYears;
	private List<String> financialYears;
	private LocalDate fromDate;
	private LocalDate toDate;
}
