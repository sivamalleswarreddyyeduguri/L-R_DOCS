package com.ubi.dbp.investment.apy.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.ubi.dbp.investment.apy.model.TodoResponse;

import reactor.core.publisher.Mono;

@Service
public interface ApyProxyService {
//	Mono<TodoResponse> fetchTodos(Integer id);	
//	Mono<List<TodoResponse>> fetchAllTodos();	
//	Mono<TodoResponse> saveTodos(TodoResponse todoResponse);
}


