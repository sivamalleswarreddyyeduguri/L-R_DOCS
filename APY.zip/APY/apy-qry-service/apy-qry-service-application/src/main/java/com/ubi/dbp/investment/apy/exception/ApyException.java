package com.ubi.dbp.investment.apy.exception;

import dbp.framework.common.domain.exception.DomainException;

public class ApyException extends DomainException{

    private static final long serialVersionUID = 1L;

    public ApyException(Error error) {
        super(error.getCode(), error.getMessage());
    }
    public ApyException(String code, String error) {
        super(code,error);
    }

    public ApyException(Error error, Object... values) {
        super(error.getCode(), String.format(error.getMessage(), values));
    }

}