package com.ubi.dbp.investment.apy.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ubi.dbp.investment.apy.client.ApyProxyClient;
import com.ubi.dbp.investment.apy.model.TodoResponse;
import com.ubi.dbp.investment.apy.service.ApyProxyService;

import reactor.core.publisher.Mono;


@Service
public class ApyProxyServiceImpl implements ApyProxyService {
   @Autowired
  ApyProxyClient ssyProxyClient;
	
//    @Override
//	public Mono<TodoResponse> fetchTodos(Integer id){	
//	  return ssyProxyClient.fetchTodos(id);
//	}
//    @Override
//	public Mono<List<TodoResponse>> fetchAllTodos(){	
//	  return ssyProxyClient.fetchAllTodos();
//	}
//    @Override
//	public Mono<TodoResponse> saveTodos(TodoResponse todoResponse){
//	 return ssyProxyClient.saveTodos(todoResponse);
//	}
}


