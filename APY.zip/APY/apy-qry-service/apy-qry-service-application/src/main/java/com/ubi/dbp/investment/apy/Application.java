package com.ubi.dbp.investment.apy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;


@SpringBootApplication
@ComponentScan(basePackages = { "com.ubi.dbp.investment.apy", "dbp.framework.proxy.common.client"})
public class Application {
	public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
	}
	
}
