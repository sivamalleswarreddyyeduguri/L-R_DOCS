package com.ubi.dbp.investment.apy.config;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Data
@Configuration
public class URLConfiguration {

    @Value("${apy.baseUrl}")
    private String baseURL;
    @Value("${apy.paths.getApyStatus}")
    private String getApyStatus;
    @Value("${apy.paths.acctdetails}")
    private String acctdetails;
    @Value("${apy.paths.checkApyCustomer}")
    private String checkExistingAccount;

}
