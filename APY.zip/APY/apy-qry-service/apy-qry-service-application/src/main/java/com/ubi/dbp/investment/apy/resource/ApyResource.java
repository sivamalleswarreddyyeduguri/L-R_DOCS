package com.ubi.dbp.investment.apy.resource;

import com.ubi.dbp.investment.apy.dal.entity.InvestmentAccountApy;
import com.ubi.dbp.investment.apy.model.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ubi.dbp.investment.apy.service.ApyService;

import reactor.core.publisher.Mono;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping({ "apy/api/v1/" })
public class ApyResource {

	@Autowired
	ApyService apyService;

	@PostMapping(value = { "getPremiumPayable" }, produces = { "application/json" })
	public Mono<ApyResponse> getPremiumPayable(@RequestBody Apy getYearsReq) {
		return apyService.getPremiumPayable(getYearsReq);
	}
	
	@PostMapping(value = { "getFinancialYears" }, produces = { "application/json" })
	public Mono<ApyResponse> getFinancialYears(@RequestBody Apy openingDate) {
		System.out.println("inside controller opening date : " + openingDate);
		return apyService.getFinancialYears(openingDate);
	}

	@PostMapping("checkExistingAccount")
	public Mono<GenericResponse> checkExistingAccount(@RequestBody ApyRequest request) throws Exception {
		return apyService.checkExistingCustomer(request);
	}

	@PostMapping("getApyStatus")
	public Mono<ApyResponse> getApyStatus(@RequestBody GetStatusReq request) throws Exception {
		return apyService.getApyStatus(request);
	}
	@PostMapping("getAcctDetails")
	public Mono<ApyResponse> getAcctDetails(@RequestBody GetStatusReq request) throws Exception {
		return apyService.getAcctDetails(request);
	}
	@PostMapping("detailsToResume")
	public InvestmentAccountApy getDetailsToResume(@RequestBody InvestmentAccountApy investmentAccountApy){
		return apyService.getDetailsToResume(investmentAccountApy);
	}

	@PostMapping("getApyAccountDetails")
	public InvestmentAccountApy getApyAccountDetails(@RequestBody InvestmentAccountApy investmentAccountApy){
		return apyService.getApyAccountDetails(investmentAccountApy);
	}

	@PostMapping("saveAPY")
	public Mono<ApyResponse> getSaveAPY(@Valid @RequestBody InvestmentAccountApy investmentAccountApy){
		return apyService.getSaveAPY(investmentAccountApy);
	}

}
