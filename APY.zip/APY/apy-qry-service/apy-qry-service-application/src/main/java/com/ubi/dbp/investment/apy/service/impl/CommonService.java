package com.ubi.dbp.investment.apy.service.impl;

import org.springframework.stereotype.Component;

import com.ubi.dbp.investment.apy.service.AbsCommonService;

import dbp.framework.proxy.common.client.DbpWebClient;

@Component
public class CommonService extends AbsCommonService{

	public CommonService(DbpWebClient dbpWebClient) {
		super(dbpWebClient);
	}

}
