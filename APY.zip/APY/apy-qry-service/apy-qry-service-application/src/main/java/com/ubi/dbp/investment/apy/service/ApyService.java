 package com.ubi.dbp.investment.apy.service;

import com.ubi.dbp.investment.apy.dal.entity.InvestmentAccountApy;
import com.ubi.dbp.investment.apy.model.*;
import reactor.core.publisher.Mono;

import java.util.List;


 public interface ApyService {

	public Mono<ApyResponse> getPremiumPayable(Apy getYearsReq);
	public Mono<ApyResponse> getFinancialYears(Apy openingDate);
	public Mono<GenericResponse> checkExistingCustomer(ApyRequest request) throws Exception;
	public Mono<ApyResponse> getApyStatus(GetStatusReq request) throws Exception;
	public InvestmentAccountApy getDetailsToResume(InvestmentAccountApy investmentAccountApy);
	public InvestmentAccountApy getApyAccountDetails(InvestmentAccountApy investmentAccountApy);
	 public Mono<ApyResponse> getAcctDetails(GetStatusReq request) throws Exception;

	 Mono<ApyResponse> getSaveAPY(InvestmentAccountApy investmentAccountApy);

}
