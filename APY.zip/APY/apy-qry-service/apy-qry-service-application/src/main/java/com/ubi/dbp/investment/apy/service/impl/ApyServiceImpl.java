package com.ubi.dbp.investment.apy.service.impl;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Random;

import com.ubi.dbp.investment.apy.config.URLConfiguration;
import com.ubi.dbp.investment.apy.dal.entity.InvestmentAccountApy;
import com.ubi.dbp.investment.apy.dal.repository.InvestmentAccountApyRepository;
import com.ubi.dbp.investment.apy.exception.ApyException;
import com.ubi.dbp.investment.apy.model.*;
import com.ubi.dbp.investment.apy.utils.AppUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ubi.dbp.investment.apy.service.ApyService;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import static org.apache.commons.lang3.RandomUtils.nextInt;

@Service
//@Slf4j
public class ApyServiceImpl implements ApyService {
	private static final Logger log = LoggerFactory.getLogger(ApyServiceImpl.class);
	private final Integer contribAgeLimit = 60;

	URLConfiguration urlConfiguration;
	WebClient.Builder webClient;
	InvestmentAccountApyRepository investmentAccountApyRepository;

	@Autowired
	public ApyServiceImpl(URLConfiguration urlConfiguration, WebClient.Builder webClient, InvestmentAccountApyRepository investmentAccountApyRepository) {
		this.urlConfiguration = urlConfiguration;
		this.webClient = webClient;
		this.investmentAccountApyRepository=investmentAccountApyRepository;
	}


	@Override
	public Mono<ApyResponse> getPremiumPayable(Apy getYearsReq) {
		LocalDate dob = getYearsReq.getCustomer().getDob();
		Integer currentAge = LocalDate.now().getYear()- dob.getYear();
		ApyResponse response = new ApyResponse();
		Integer diffYrs = contribAgeLimit - currentAge;
		ApyContributionDetails contDetails = new ApyContributionDetails();
		contDetails.setContribYears(diffYrs.toString());
		contDetails.setPremiumPayable("500");
		response.setInvestmentContribution(contDetails);
		return Mono.just(response);
	}
	
	@Override
	public Mono<ApyResponse> getFinancialYears(Apy openingDate) {
		System.out.println("Inside Service Impl");
		ApyResponse response = new ApyResponse();
		ApyContributionDetails investmentContribution = new ApyContributionDetails();
		List<String> financialYears = new ArrayList<>();
		if(openingDate.getSource()!=null && openingDate.getSource().getAcctOpenDate()!=null) {
			LocalDate startDate = openingDate.getSource().getAcctOpenDate();
			LocalDate endDate = LocalDate.now();
			int startYear = startDate.getYear();
			int startMonth = startDate.getMonthValue();
			int endYear = endDate.getYear();
			if (startMonth < 4) {
				startYear--;
			}
			while (startYear <= endYear) {
				int endYearPart = startYear % 100;
				String startYearStr = String.format("%02d", endYearPart);
				String endYearStr = String.format("%02d", (endYearPart + 1) % 100);
				financialYears.add("FY " + startYearStr + "-" + endYearStr);
				startYear++;
			}
		}
		investmentContribution.setFinancialYears(financialYears);
		response.setInvestmentContribution(investmentContribution);
		return Mono.just(response);
	}


	@Override
	public Mono<GenericResponse> checkExistingCustomer(ApyRequest request) {
		String url = AppUtils.buildUrl(urlConfiguration.getBaseURL(), urlConfiguration.getCheckExistingAccount());
		try {
			return webClient.build()
					.post()
					.uri(url)
					.body(BodyInserters.fromValue(request))
					.retrieve()
					.bodyToMono(GenericResponse.class)
					.flatMap(res -> {
						if (Objects.equals(res.getStatus(), "SUCCESS")) {
							return Mono.just(res);
						} else {
							return Mono.error(new ApyException(res.getStatus(), res.getErrorDescription()));
						}
					});
		} catch (Exception e) {
			throw new ApyException("ApyServiceImpl",e.getMessage());

		}
	}

	@Override
	public Mono<ApyResponse> getApyStatus(GetStatusReq request) throws Exception {
		String url = AppUtils.buildUrl(urlConfiguration.getBaseURL(), urlConfiguration.getGetApyStatus());
		try {
			return webClient.build()
					.post()
					.uri(url)
					.body(BodyInserters.fromValue(request))
					.retrieve()
					.bodyToMono(ApyResponse.class)
					.flatMap(res -> {
						if ((res.getPranNum()!=null) && !(res.getPranNum().isBlank()) && !(res.getPranNum().isEmpty())) {
							return Mono.just(res);
						} else {
							return Mono.error(new ApyException("FAILURE","Invalid APY Cust ID"));
						}
					});
		} catch (Exception e) {
			log.error("ApyServiceImpl",e);
			throw new ApyException("ApyServiceImpl","Bad Request");
		}
	}

	@Override
	public InvestmentAccountApy getDetailsToResume(InvestmentAccountApy investmentAccountApy) {
		String cif=investmentAccountApy.getCif();
		String applNum = investmentAccountApy.getApplicationFormNumber();
		List<InvestmentAccountApy> res=investmentAccountApyRepository.findByCifAndApplicationFormNumber(cif, applNum);

		if (res != null && !res.isEmpty()) {
			return res.get(0);
		}else {
			throw new RuntimeException("Record not found");
		}
	}

	@Override
	public InvestmentAccountApy getApyAccountDetails(InvestmentAccountApy investmentAccountApy) {
		List<InvestmentAccountApy> res=investmentAccountApyRepository.findByCif(investmentAccountApy.getCif());
		for (InvestmentAccountApy account : res) {
			if (account.getAccountNumber() != null && !account.getAccountNumber().isEmpty() &&
					account.getPranNumber() != null && !account.getPranNumber().isEmpty()) {
				return account;
			}
		}
		throw new RuntimeException("Record not found");
	}


	@Override
	public Mono<ApyResponse> getAcctDetails(GetStatusReq cif) {
		String url = AppUtils.buildUrl(urlConfiguration.getBaseURL(), urlConfiguration.getAcctdetails());
		try {
			return webClient.build()
					.post()
					.uri(url)
					.body(BodyInserters.fromValue(cif))
					.retrieve()
					.bodyToMono(ApyResponse.class)
					.flatMap(res -> {
						if ((res.getPranNum()!=null) && !(res.getPranNum().isBlank()) && !(res.getPranNum().isEmpty())) {
							return Mono.just(res);
						} else {
							return Mono.error(new ApyException("FAILURE","Invalid APY Cust ID"));
						}
					});
		} catch (Exception e) {
			log.error("ApyServiceImpl",e);
			throw new ApyException("ApyServiceImpl","Bad Request");
		}
	}


	public Mono<ApyResponse> getSaveAPY(InvestmentAccountApy investmentAccountApy) {
		String cif = investmentAccountApy.getCif();
		String applicationFormNumber = investmentAccountApy.getApplicationFormNumber();
		ApyResponse apyMono=new ApyResponse();
		apyMono.setCif(cif);
		apyMono.setApplNum(applicationFormNumber);
		if (applicationFormNumber == null || applicationFormNumber.isEmpty()) {
			applicationFormNumber = String.valueOf(new Random().nextInt(90000000) + 10000000);
			investmentAccountApy.setApplicationFormNumber(applicationFormNumber);
			apyMono.setApplNum(applicationFormNumber);
			investmentAccountApyRepository.save(investmentAccountApy);
		} else {
			List<InvestmentAccountApy> existingRecords = investmentAccountApyRepository.findByCifAndApplicationFormNumber(cif, applicationFormNumber);
			if (existingRecords.isEmpty()) {
				throw new RuntimeException("Record not found");
			} else {
				investmentAccountApyRepository.save(investmentAccountApy);
				log.info("REQ: {}", investmentAccountApy);
				log.info("UPDATED : {}", investmentAccountApyRepository.findByCifAndApplicationFormNumber(cif,applicationFormNumber));
			}
		}
		return Mono.just(apyMono);
	}

}
