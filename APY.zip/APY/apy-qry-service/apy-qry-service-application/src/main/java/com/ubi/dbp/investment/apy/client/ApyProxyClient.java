package com.ubi.dbp.investment.apy.client;

import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.ubi.dbp.investment.apy.model.TodoResponse;
import com.ubi.dbp.investment.apy.service.AbsCommonService.CallType;
import com.ubi.dbp.investment.apy.service.impl.CommonService;

import jakarta.annotation.PostConstruct;
import reactor.core.publisher.Mono;


@Service
public class ApyProxyClient{
  
//	@Value("${rest-client.\"com.ibm.client.SsyProxyClient\".uri}")
//	private String ssyProxyBaseUrl;
//	    
//    private CommonService commonService;
//    private String proxyBaseUrl;
//
//    public ApyProxyClient(CommonService commonService) {
//        this.commonService = commonService;
//    }
//      
//    @PostConstruct
//    public void init() {
//        this.proxyBaseUrl = ssyProxyBaseUrl +"/todos";
//    } 
//  	
//	public Mono<TodoResponse> fetchTodos(Integer id) {
//        String url = proxyBaseUrl + "/{id}" ;
//        return commonService.handle(url, null, TodoResponse.class, CallType.GET);
//
//    }	
//	public Mono<List<TodoResponse>> fetchAllTodos() {
//         String url = proxyBaseUrl + "/";
//         TypeReference<List<TodoResponse>> respType = new TypeReference<List<TodoResponse>>() {};
//         return commonService.handle(url, null, respType.getType(), CallType.GET);
//    }	
//	public Mono<TodoResponse> saveTodos(TodoResponse todoResponse) {		
//		String url = proxyBaseUrl + "/";
//        return commonService.handle(url, todoResponse, TodoResponse.class, CallType.POST);
//	};
}
