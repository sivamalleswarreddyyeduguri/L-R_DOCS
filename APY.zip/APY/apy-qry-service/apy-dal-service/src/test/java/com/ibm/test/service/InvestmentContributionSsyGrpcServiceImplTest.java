//package com.ibm.test.service;
//
//import com.ibm.model.*;
//import com.google.protobuf.*;
//import com.ibm.grpc.stubs.AllInvestmentContributionSsyPartitionAndClusterKeys;
//import com.ibm.grpc.stubs.AllInvestmentContributionSsyPartitionKeys;
//import com.ibm.grpc.stubs.InvestmentContributionSsyServiceGrpc.InvestmentContributionSsyServiceImplBase;
//import com.ibm.model.*;
//
//import io.grpc.Status;
//import io.grpc.stub.StreamObserver;
//import com.google.protobuf.*;
//
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.junit.jupiter.api.Assertions.assertThrows;
//import org.mockito.Mockito;
//import org.mockito.Mock;
//import static org.mockito.Mockito.mock;
//import org.mockito.InjectMocks;
//import org.junit.jupiter.api.Assertions;
//import org.junit.jupiter.api.BeforeEach;
//import org.mockito.junit.jupiter.MockitoExtension;
//import org.mockito.junit.jupiter.MockitoSettings;
//import org.mockito.quality.Strictness;
//import org.springframework.dao.OptimisticLockingFailureException;
//
//import net.devh.boot.grpc.server.service.GrpcService;
//import org.springframework.util.ObjectUtils;
//
//import com.ibm.repository.InvestmentContributionSsyRepository;
//import com.ibm.service.impl.InvestmentContributionSsyServiceImpl;
//import com.ibm.utils.InvestmentAccountSsyEntityMapper;
//import com.ibm.utils.InvestmentAccountSsyEntityMapper;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import java.util.*;
//import java.math.*;
//import java.time.*;
// import java.time.format.DateTimeFormatter;
//import java.util.NoSuchElementException;
//import org.mapstruct.factory.Mappers;
//import static org.mockito.Mockito.*;
//
//@ExtendWith(MockitoExtension.class)
//public class InvestmentContributionSsyGrpcServiceImplTest {
//
//	@Mock
//    private InvestmentAccountSsyEntityMapper mapper;
//
//    @Mock
//    private InvestmentContributionSsyRepository mockRepository;
//	
//	@InjectMocks
//    private InvestmentContributionSsyServiceImpl investmentContributionSsyGrpcServiceImplUnderTest;
//	
//    private com.ibm.grpc.stubs.BeneficiaryInfo builderBeneficiaryInfo;
//    private BeneficiaryInfo modelBuilderBeneficiaryInfo;
//    private com.ibm.grpc.stubs.DocumentInfo builderDocumentInfo;
//    private DocumentInfo modelBuilderDocumentInfo;
//
//	private String mockStrVal = "test";
//	private int mockIntVal = 1234567;
//	private List<String> mockListVal = new ArrayList<>();
//	private Object mockObjVal = new Object();
//	private BigDecimal mockBigDecimalVal = new BigDecimal(123);
//	private String strBigDecimal = "12345678";
//	private LocalDateTime mockLocalDate = LocalDateTime.now(); 
//	private String strDate = LocalDateTime.now().toString();
//
//	@BeforeEach
//	void setUp() {
//    mapper= Mappers.getMapper(InvestmentAccountSsyEntityMapper.class);
//    
//    
//  }
//
//    
//	
//	private InvestmentContributionSsy createModel(){
//		
//		InvestmentContributionSsy model = InvestmentContributionSsy.builder()
//		.cif(mockStrVal)
//		.applicationFormNumber(mockStrVal)
//		.paymentTxnId(mockStrVal)
//		.accountNumber(mockStrVal)
//		.activeFlag(true)
//		.amount(mockBigDecimalVal)
//		.channel(mockStrVal)
//		.channelTxnId(mockStrVal)
//		.createdBy(mockStrVal)
//		.createdDate(mockLocalDate)
//		.creditAccountNumber(mockStrVal)
//		.debitAccountNumber(mockStrVal)
//		.modifiedBy(mockStrVal)
//		.modifiedDate(mockLocalDate)
//		.mode(mockStrVal)
//		.paymentTxnDate(mockLocalDate)
//		.paymentTxnStatus(mockStrVal)
//		.remarks(mockStrVal)
//		.systemTxnId(mockStrVal)
//		.systemTxnStatus(mockStrVal)
//		.tranParticulars(mockStrVal)
//		
//		.build();
//		return model;
//	
//	}
//	
//	private List<InvestmentContributionSsy> createModelList(){
//	
//		List<InvestmentContributionSsy> response =  new ArrayList<>();
//		response.add(createModel());
//		return response;
//	}
//	
//	private com.ibm.grpc.stubs.InvestmentContributionSsy createProtoModel(){
//		com.ibm.grpc.stubs.InvestmentContributionSsy model = com.ibm.grpc.stubs.InvestmentContributionSsy.newBuilder()
//		.setCif(mockStrVal)
//		.setApplicationFormNumber(mockStrVal)
//		.setPaymentTxnId(mockStrVal)
//		.setAccountNumber(mockStrVal)
//		.setActiveFlag(true)
//		.setAmount(strBigDecimal)
//		.setChannel(mockStrVal)
//		.setChannelTxnId(mockStrVal)
//		.setCreatedBy(mockStrVal)
//		.setCreatedDate(strDate)
//		.setCreditAccountNumber(mockStrVal)
//		.setDebitAccountNumber(mockStrVal)
//		.setModifiedBy(mockStrVal)
//		.setModifiedDate(strDate)
//		.setMode(mockStrVal)
//		.setPaymentTxnDate(strDate)
//		.setPaymentTxnStatus(mockStrVal)
//		.setRemarks(mockStrVal)
//		.setSystemTxnId(mockStrVal)
//		.setSystemTxnStatus(mockStrVal)
//		.setTranParticulars(mockStrVal)
//		
//		.build();
//		return model;
//		
//	}
//	private List<com.ibm.grpc.stubs.InvestmentContributionSsy> createProtoModelList(){
//		List<com.ibm.grpc.stubs.InvestmentContributionSsy> expectedResponse =  new ArrayList<>();		
//		expectedResponse.add(createProtoModel());
//		return expectedResponse;
//	}
//
//
//    @Test
//    @MockitoSettings(strictness = Strictness.LENIENT)
//    void testfindAll() {
//		final StreamObserver<com.ibm.grpc.stubs.InvestmentContributionSsys> responseObserver = mock(
//				StreamObserver.class);
//        List<InvestmentContributionSsy> expectedinvestmentContributionSsy = createModelList();
//		List<com.ibm.grpc.stubs.InvestmentContributionSsy> expectedResponse = createProtoModelList();
//		
//		when(mockRepository.findAll())
//                .thenReturn(expectedinvestmentContributionSsy);
//       // when(mapper.mapToProtoList(expectedinvestmentContributionSsy)).thenReturn(expectedResponse);
//
//        investmentContributionSsyGrpcServiceImplUnderTest.findAll(Empty.newBuilder().build(), responseObserver);
//        verify(mockRepository).findAll();
//    }
//	
//	@Test
//    @MockitoSettings(strictness = Strictness.LENIENT)//As mockito was not able to mock the serviceImpl class
//    public void testFindAll_Exception() {
//		final StreamObserver<com.ibm.grpc.stubs.InvestmentContributionSsys> responseObserver = mock(
//				StreamObserver.class);
//
//		when(mockRepository.findAll()).thenThrow(OptimisticLockingFailureException.class);
//
//		investmentContributionSsyGrpcServiceImplUnderTest.findAll(Empty.newBuilder().build(), responseObserver);
//		verify(mockRepository, times(0)).findAll(any());
//       
//    }
//	
//	 @Test
//    @MockitoSettings(strictness = Strictness.LENIENT)//As mockito was not able to mock the serviceImpl class
//    public  void testFindAll_NoSuchElementException() {
//		final StreamObserver<com.ibm.grpc.stubs.InvestmentContributionSsys> responseObserver = mock(
//				StreamObserver.class);
//
//		when(mockRepository.findAll()).thenThrow(NoSuchElementException.class);
//
//		investmentContributionSsyGrpcServiceImplUnderTest.findAll(Empty.newBuilder().build(), responseObserver);
//		verify(mockRepository, times(0)).findAll(any());
//       
//    }
//	
//	@Test
//    @MockitoSettings(strictness = Strictness.LENIENT)
//    void testSave() {
//        
//		final com.ibm.grpc.stubs.InvestmentContributionSsy request = createProtoModel();
//        final StreamObserver<com.ibm.grpc.stubs.InvestmentContributionSsy> mockResponseObserver = mock(StreamObserver.class);
//        final com.ibm.grpc.stubs.InvestmentContributionSsy expectedResponse =  com.ibm.grpc.stubs.InvestmentContributionSsy.newBuilder().build();
//        final InvestmentContributionSsy expectedEntity = createModel();
//        when(mockRepository.save(createModel()))
//                .thenReturn(createModel());
//       // when(mapper.mapFromProto(request)).thenReturn(expectedEntity);
//       // when(mapper.mapToProto(expectedEntity)).thenReturn(expectedResponse);
//        investmentContributionSsyGrpcServiceImplUnderTest.save(request, mockResponseObserver);
//        verify(mockResponseObserver).onCompleted();
//    }
//
//	@Test
//    @MockitoSettings(strictness = Strictness.LENIENT)//As mockito was not able to mock the serviceImpl class
//    void testSave_Exception() {
//    	  final com.ibm.grpc.stubs.InvestmentContributionSsy request =createProtoModel();
//    	  final InvestmentContributionSsy expectedEntity=createModel();
//          final StreamObserver<com.ibm.grpc.stubs.InvestmentContributionSsy> mockResponseObserver = mock(StreamObserver.class);
//          when(mockRepository.save(any(InvestmentContributionSsy.class)))
//                  .thenThrow(OptimisticLockingFailureException.class);
//
//          investmentContributionSsyGrpcServiceImplUnderTest.save(request, mockResponseObserver);
//         // verify(mockRepository, times(0)).save(any());
//          //verify(mockResponseObserver).onNext(null);
//          
//        //  verify(mockRepository).save(expectedEntity);
//       
//    }
//	
//	@Test
//    @MockitoSettings(strictness = Strictness.LENIENT)//As mockito was not able to mock the serviceImpl class
//    void testSave_NoSuchElementException() {
//    	  final com.ibm.grpc.stubs.InvestmentContributionSsy request =createProtoModel();
//    	  final InvestmentContributionSsy expectedEntity=createModel();
//          final StreamObserver<com.ibm.grpc.stubs.InvestmentContributionSsy> mockResponseObserver = mock(StreamObserver.class);
//          when(mockRepository.save(any(InvestmentContributionSsy.class)))
//                  .thenThrow(NoSuchElementException.class);
//
//          investmentContributionSsyGrpcServiceImplUnderTest.save(request, mockResponseObserver);
//          //verify(mockRepository, times(0)).save(any());
//          //verify(mockResponseObserver).onNext(null);
//          
//        //  verify(mockRepository).save(expectedEntity);
//       
//    }
//
//    @Test
//    @MockitoSettings(strictness = Strictness.LENIENT)
//    void testUpdate() {
//        
//		final com.ibm.grpc.stubs.InvestmentContributionSsy request = createProtoModel();
//        final StreamObserver<com.ibm.grpc.stubs.InvestmentContributionSsy> mockResponseObserver = mock(StreamObserver.class);
//        final com.ibm.grpc.stubs.InvestmentContributionSsy expectedResponse =  com.ibm.grpc.stubs.InvestmentContributionSsy.newBuilder().build();
//        final InvestmentContributionSsy expectedEntity = createModel();
//        when(mockRepository.save(createModel()))
//                .thenReturn(createModel());
//       // when(mapper.mapFromProto(request)).thenReturn(expectedEntity);
//       // when(mapper.mapToProto(expectedEntity)).thenReturn(expectedResponse);
//        investmentContributionSsyGrpcServiceImplUnderTest.update(request, mockResponseObserver);
//        verify(mockResponseObserver).onCompleted();
//		
//    }
//	
//	@Test
//    @MockitoSettings(strictness = Strictness.LENIENT)//As mockito was not able to mock the serviceImpl class
//    void testUpdate_Exception() {
//    	  final com.ibm.grpc.stubs.InvestmentContributionSsy request =createProtoModel();
//
//          final StreamObserver<com.ibm.grpc.stubs.InvestmentContributionSsy> mockResponseObserver = mock(StreamObserver.class);
//          when(mockRepository.save(any(InvestmentContributionSsy.class)))
//                  .thenThrow(OptimisticLockingFailureException.class);
//
//          investmentContributionSsyGrpcServiceImplUnderTest.update(request, mockResponseObserver);
//         // verify(mockRepository, times(0)).save(any());
//  
//       
//    }
//    
//	@Test
//    @MockitoSettings(strictness = Strictness.LENIENT)//As mockito was not able to mock the serviceImpl class
//    void testUpdate_NoSuchElementException() {
//    	  final com.ibm.grpc.stubs.InvestmentContributionSsy request =createProtoModel();
//
//          final StreamObserver<com.ibm.grpc.stubs.InvestmentContributionSsy> mockResponseObserver = mock(StreamObserver.class);
//          when(mockRepository.save(any(InvestmentContributionSsy.class)))
//                  .thenThrow(NoSuchElementException.class);
//
//          investmentContributionSsyGrpcServiceImplUnderTest.update(request, mockResponseObserver);
//          //verify(mockRepository, times(0)).save(any());
//  
//       
//    }
//	
//    @Test
//    @MockitoSettings(strictness = Strictness.LENIENT)//As mockito was not able to mock the serviceImpl class
//    void testFindByCifAndPaymentTxnId() {
//		final StreamObserver<com.ibm.grpc.stubs.InvestmentContributionSsys> responseObserver = mock(StreamObserver.class);
//		InvestmentContributionSsy expectedEntity = createModel();
//		AllInvestmentContributionSsyPartitionKeys request = AllInvestmentContributionSsyPartitionKeys.newBuilder().setCif(expectedEntity.getCif()).setPaymentTxnId(expectedEntity.getPaymentTxnId()).build();
//        List<InvestmentContributionSsy> expectedEntityList = createModelList();
//		List<com.ibm.grpc.stubs.InvestmentContributionSsy> expectedResponse =   createProtoModelList();
//        when(mockRepository.findByCifAndPaymentTxnId(request.getCif(),request.getPaymentTxnId()))
//                .thenReturn(expectedEntityList);
//      //  when(mapper.mapToProtoList(expectedEntityList)).thenReturn(expectedResponse);
//
//        investmentContributionSsyGrpcServiceImplUnderTest.findByCifAndPaymentTxnId(request, responseObserver);
//        verify(mockRepository).findByCifAndPaymentTxnId(request.getCif(),request.getPaymentTxnId());
//        
//    }
//    
//	@Test
//    @MockitoSettings(strictness = Strictness.LENIENT)//As mockito was not able to mock the serviceImpl class
//    public void testFindByCifAndPaymentTxnId_Exception() {
//    	final StreamObserver<com.ibm.grpc.stubs.InvestmentContributionSsys> responseObserver = mock(StreamObserver.class);
//    	InvestmentContributionSsy expectedEntity = createModel();
//    	AllInvestmentContributionSsyPartitionKeys request = AllInvestmentContributionSsyPartitionKeys.newBuilder().setCif(expectedEntity.getCif()).setPaymentTxnId(expectedEntity.getPaymentTxnId()).build();
//
//        
//		when(mockRepository.findByCifAndPaymentTxnId(request.getCif(),request.getPaymentTxnId()))
//		.thenThrow(OptimisticLockingFailureException.class);
//
//		investmentContributionSsyGrpcServiceImplUnderTest.findByCifAndPaymentTxnId(request, responseObserver);
//		//verify(mockRepository, times(0)).findByCifAndPaymentTxnId(any(),any());
//  
//       
//    }
//	
//	@Test
//    @MockitoSettings(strictness = Strictness.LENIENT)//As mockito was not able to mock the serviceImpl class
//    public void testFindByCifAndPaymentTxnIdNoSuchElementException() {
//    	final StreamObserver<com.ibm.grpc.stubs.InvestmentContributionSsys> responseObserver = mock(StreamObserver.class);
//    	InvestmentContributionSsy expectedEntity = createModel();
//    	AllInvestmentContributionSsyPartitionKeys request = AllInvestmentContributionSsyPartitionKeys.newBuilder().setCif(expectedEntity.getCif()).setPaymentTxnId(expectedEntity.getPaymentTxnId()).build();
//
//        
//		when(mockRepository.findByCifAndPaymentTxnId(request.getCif(),request.getPaymentTxnId()))
//		.thenThrow(NoSuchElementException.class);
//
//		investmentContributionSsyGrpcServiceImplUnderTest.findByCifAndPaymentTxnId(request, responseObserver);
//		//verify(mockRepository, times(0)).findByCifAndPaymentTxnId(any(),any());
//  
//       
//    }
//	
//    @Test
//    @MockitoSettings(strictness = Strictness.LENIENT)//As mockito was not able to mock the serviceImpl class
//    void testFindByCifAndPaymentTxnIdAndApplicationFormNumber() {
//        final StreamObserver<com.ibm.grpc.stubs.InvestmentContributionSsys> responseObserver = mock(StreamObserver.class);
//		InvestmentContributionSsy expectedEntity = createModel();
//		AllInvestmentContributionSsyPartitionAndClusterKeys request = AllInvestmentContributionSsyPartitionAndClusterKeys.newBuilder().setCif(expectedEntity.getCif()).setPaymentTxnId(expectedEntity.getPaymentTxnId()).setApplicationFormNumber(expectedEntity.getApplicationFormNumber()).build();
//		List<InvestmentContributionSsy> expectedEntityList = createModelList();
//		List<com.ibm.grpc.stubs.InvestmentContributionSsy> expectedResponse =   createProtoModelList();
//        when(mockRepository.findByCifAndPaymentTxnIdAndApplicationFormNumber(request.getCif() ,request.getPaymentTxnId() ,request.getApplicationFormNumber()))
//                .thenReturn(expectedEntityList);
//       // when(mapper.mapToProtoList(expectedEntityList)).thenReturn(expectedResponse);
//
//        investmentContributionSsyGrpcServiceImplUnderTest.findByCifAndPaymentTxnIdAndApplicationFormNumber(request, responseObserver);
//        verify(mockRepository).findByCifAndPaymentTxnIdAndApplicationFormNumber(request.getCif() ,request.getPaymentTxnId() ,request.getApplicationFormNumber());
//        
//    }
//	
//	@Test
//    @MockitoSettings(strictness = Strictness.LENIENT)//As mockito was not able to mock the serviceImpl class
//    public void testFindByCifAndPaymentTxnIdAndApplicationFormNumber_Exception() {
//    	final StreamObserver<com.ibm.grpc.stubs.InvestmentContributionSsys> responseObserver = mock(StreamObserver.class);
//    	InvestmentContributionSsy expectedEntity = createModel();
//    	AllInvestmentContributionSsyPartitionAndClusterKeys request = AllInvestmentContributionSsyPartitionAndClusterKeys.newBuilder().setCif(expectedEntity.getCif()).setPaymentTxnId(expectedEntity.getPaymentTxnId()).setApplicationFormNumber(expectedEntity.getApplicationFormNumber()).build();
//
//        
//		when(mockRepository.findByCifAndPaymentTxnIdAndApplicationFormNumber(request.getCif() ,request.getPaymentTxnId() ,request.getApplicationFormNumber()))
//		.thenThrow(OptimisticLockingFailureException.class);
//
//		investmentContributionSsyGrpcServiceImplUnderTest.findByCifAndPaymentTxnIdAndApplicationFormNumber(request, responseObserver);
//		//verify(mockRepository, times(0)).findByCifAndPaymentTxnIdAndApplicationFormNumber(any(),any(),any());
//  
//       
//    }
//	
//	@Test
//    @MockitoSettings(strictness = Strictness.LENIENT)//As mockito was not able to mock the serviceImpl class
//    public void testFindByCifAndPaymentTxnIdAndApplicationFormNumberNoSuchElementException() {
//    	final StreamObserver<com.ibm.grpc.stubs.InvestmentContributionSsys> responseObserver = mock(StreamObserver.class);
//    	InvestmentContributionSsy expectedEntity = createModel();
//    	AllInvestmentContributionSsyPartitionAndClusterKeys request = AllInvestmentContributionSsyPartitionAndClusterKeys.newBuilder().setCif(expectedEntity.getCif()).setPaymentTxnId(expectedEntity.getPaymentTxnId()).setApplicationFormNumber(expectedEntity.getApplicationFormNumber()).build();
//
//        
//		when(mockRepository.findByCifAndPaymentTxnIdAndApplicationFormNumber(request.getCif() ,request.getPaymentTxnId() ,request.getApplicationFormNumber()))
//		.thenThrow(NoSuchElementException.class);
//
//		investmentContributionSsyGrpcServiceImplUnderTest.findByCifAndPaymentTxnIdAndApplicationFormNumber(request, responseObserver);
//		//verify(mockRepository, times(0)).findByCifAndPaymentTxnIdAndApplicationFormNumber(any(),any(),any());
//  
//       
//    }
//	
//    
//    @Test
//    @MockitoSettings(strictness = Strictness.LENIENT)//As mockito was not able to mock the serviceImpl class
//    void deleteByCifAndPaymentTxnId() {
//	
//		final StreamObserver<com.google.protobuf.Empty> responseObserver = mock(StreamObserver.class);
//		InvestmentContributionSsy expectedEntity = createModel();
//		AllInvestmentContributionSsyPartitionKeys request = AllInvestmentContributionSsyPartitionKeys.newBuilder().setCif(expectedEntity.getCif()).setPaymentTxnId(expectedEntity.getPaymentTxnId()).build();
//		investmentContributionSsyGrpcServiceImplUnderTest.deleteByCifAndPaymentTxnId(request, responseObserver);
//		verify(responseObserver).onNext(null);
//        
//    }
//	
//	@Test
//    @MockitoSettings(strictness = Strictness.LENIENT)//As mockito was not able to mock the serviceImpl class
//    void deleteByCifAndPaymentTxnId_Exception() {
//	
//		final StreamObserver<com.google.protobuf.Empty> responseObserver = mock(StreamObserver.class);
//		InvestmentContributionSsy expectedEntity = createModel();
//		AllInvestmentContributionSsyPartitionKeys request = AllInvestmentContributionSsyPartitionKeys.newBuilder().setCif(expectedEntity.getCif()).setPaymentTxnId(expectedEntity.getPaymentTxnId()).build();
//		doThrow(OptimisticLockingFailureException.class).when(mockRepository).deleteByCifAndPaymentTxnId(request.getCif(),request.getPaymentTxnId());
//		investmentContributionSsyGrpcServiceImplUnderTest.deleteByCifAndPaymentTxnId(request, responseObserver);
//		verify(mockRepository, times(0)).delete(any());
//        
//    }
//	
//	@Test
//    @MockitoSettings(strictness = Strictness.LENIENT)//As mockito was not able to mock the serviceImpl class
//    void deleteByCifAndPaymentTxnId_NoSuchElementException() {
//	
//		final StreamObserver<com.google.protobuf.Empty> responseObserver = mock(StreamObserver.class);
//		InvestmentContributionSsy expectedEntity = createModel();
//		AllInvestmentContributionSsyPartitionKeys request = AllInvestmentContributionSsyPartitionKeys.newBuilder().setCif(expectedEntity.getCif()).setPaymentTxnId(expectedEntity.getPaymentTxnId()).build();
//		doThrow(NoSuchElementException.class).when(mockRepository).deleteByCifAndPaymentTxnId(request.getCif(),request.getPaymentTxnId());
//		investmentContributionSsyGrpcServiceImplUnderTest.deleteByCifAndPaymentTxnId(request, responseObserver);
//		verify(mockRepository, times(0)).delete(any());
//        
//    }
//	
//    @Test
//    @MockitoSettings(strictness = Strictness.LENIENT)//As mockito was not able to mock the serviceImpl class
//    void deleteByCifAndPaymentTxnIdAndApplicationFormNumber() {
//		final StreamObserver<com.google.protobuf.Empty> responseObserver = mock(StreamObserver.class);
//		InvestmentContributionSsy expectedEntity = createModel();
//		AllInvestmentContributionSsyPartitionAndClusterKeys request = AllInvestmentContributionSsyPartitionAndClusterKeys.newBuilder().setCif(expectedEntity.getCif()).setPaymentTxnId(expectedEntity.getPaymentTxnId()).setApplicationFormNumber(expectedEntity.getApplicationFormNumber()).build();
//        investmentContributionSsyGrpcServiceImplUnderTest.deleteByCifAndPaymentTxnIdAndApplicationFormNumber(request, responseObserver);
//		verify(responseObserver).onNext(null);
//		
//    }
//	
//	@Test
//    @MockitoSettings(strictness = Strictness.LENIENT)//As mockito was not able to mock the serviceImpl class
//    void deleteByCifAndPaymentTxnIdAndApplicationFormNumber_Exception() {
//	
//		final StreamObserver<com.google.protobuf.Empty> responseObserver = mock(StreamObserver.class);
//		InvestmentContributionSsy expectedEntity = createModel();
//		AllInvestmentContributionSsyPartitionAndClusterKeys request = AllInvestmentContributionSsyPartitionAndClusterKeys.newBuilder().setCif(expectedEntity.getCif()).setPaymentTxnId(expectedEntity.getPaymentTxnId()).setApplicationFormNumber(expectedEntity.getApplicationFormNumber()).build();
//		doThrow(OptimisticLockingFailureException.class).when(mockRepository).deleteByCifAndPaymentTxnIdAndApplicationFormNumber(request.getCif() ,request.getPaymentTxnId() ,request.getApplicationFormNumber());
//		investmentContributionSsyGrpcServiceImplUnderTest.deleteByCifAndPaymentTxnIdAndApplicationFormNumber(request, responseObserver);
//		verify(mockRepository, times(0)).delete(any());
//        
//    }
//	
//	@Test
//    @MockitoSettings(strictness = Strictness.LENIENT)//As mockito was not able to mock the serviceImpl class
//    void deleteByCifAndPaymentTxnIdAndApplicationFormNumber_NoSuchElementException() {
//	
//		final StreamObserver<com.google.protobuf.Empty> responseObserver = mock(StreamObserver.class);
//		InvestmentContributionSsy expectedEntity = createModel();
//		AllInvestmentContributionSsyPartitionAndClusterKeys request = AllInvestmentContributionSsyPartitionAndClusterKeys.newBuilder().setCif(expectedEntity.getCif()).setPaymentTxnId(expectedEntity.getPaymentTxnId()).setApplicationFormNumber(expectedEntity.getApplicationFormNumber()).build();
//		doThrow(NoSuchElementException.class).when(mockRepository).deleteByCifAndPaymentTxnIdAndApplicationFormNumber(request.getCif() ,request.getPaymentTxnId() ,request.getApplicationFormNumber());
//		investmentContributionSsyGrpcServiceImplUnderTest.deleteByCifAndPaymentTxnIdAndApplicationFormNumber(request, responseObserver);
//		verify(mockRepository, times(0)).delete(any());
//        
//    }
//	
//    
//}
