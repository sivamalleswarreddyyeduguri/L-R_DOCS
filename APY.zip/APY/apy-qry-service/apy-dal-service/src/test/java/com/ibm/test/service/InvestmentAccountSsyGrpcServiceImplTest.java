//package com.ibm.test.service;
//
//import com.ibm.model.*;
//import com.google.protobuf.*;
//import com.ibm.grpc.stubs.AllInvestmentAccountSsyPartitionAndClusterKeys;
//import com.ibm.grpc.stubs.AllInvestmentAccountSsyPartitionKeys;
//import com.ibm.grpc.stubs.InvestmentAccountSsyServiceGrpc.InvestmentAccountSsyServiceImplBase;
//import com.ibm.model.*;
//
//import io.grpc.Status;
//import io.grpc.stub.StreamObserver;
//import com.google.protobuf.*;
//
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.junit.jupiter.api.Assertions.assertThrows;
//import org.mockito.Mockito;
//import org.mockito.Mock;
//import static org.mockito.Mockito.mock;
//import org.mockito.InjectMocks;
//import org.junit.jupiter.api.Assertions;
//import org.junit.jupiter.api.BeforeEach;
//import org.mockito.junit.jupiter.MockitoExtension;
//import org.mockito.junit.jupiter.MockitoSettings;
//import org.mockito.quality.Strictness;
//import org.springframework.dao.OptimisticLockingFailureException;
//
//import net.devh.boot.grpc.server.service.GrpcService;
//import org.springframework.util.ObjectUtils;
//
//import com.ibm.repository.InvestmentAccountSsyRepository;
//import com.ibm.service.impl.InvestmentAccountSsyServiceImpl;
//import com.ibm.utils.InvestmentContributionSsyEntityMapper;
//import com.ibm.utils.InvestmentContributionSsyEntityMapper;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import java.util.*;
//import java.math.*;
//import java.time.*;
// import java.time.format.DateTimeFormatter;
//import java.util.NoSuchElementException;
//import org.mapstruct.factory.Mappers;
//import static org.mockito.Mockito.*;
//
//@ExtendWith(MockitoExtension.class)
//public class InvestmentAccountSsyGrpcServiceImplTest {
//
//	@Mock
//    private InvestmentContributionSsyEntityMapper mapper;
//
//    @Mock
//    private InvestmentAccountSsyRepository mockRepository;
//	
//	@InjectMocks
//    private InvestmentAccountSsyServiceImpl investmentAccountSsyGrpcServiceImplUnderTest;
//	
//    private com.ibm.grpc.stubs.BeneficiaryInfo builderBeneficiaryInfo;
//    private BeneficiaryInfo modelBuilderBeneficiaryInfo;
//    private com.ibm.grpc.stubs.DocumentInfo builderDocumentInfo;
//    private DocumentInfo modelBuilderDocumentInfo;
//
//	private String mockStrVal = "test";
//	private int mockIntVal = 1234567;
//	private List<String> mockListVal = new ArrayList<>();
//	private Object mockObjVal = new Object();
//	private BigDecimal mockBigDecimalVal = new BigDecimal(123);
//	private String strBigDecimal = "12345678";
//	private LocalDateTime mockLocalDate = LocalDateTime.now(); 
//	private String strDate = LocalDateTime.now().toString();
//
//	@BeforeEach
//	void setUp() {
//    mapper= Mappers.getMapper(InvestmentContributionSsyEntityMapper.class);
//    builderBeneficiaryInfo = com.ibm.grpc.stubs.BeneficiaryInfo.newBuilder()   
//		.setFirstName(mockStrVal)
//		.setMiddleName(mockStrVal)
//		.setLastName(mockStrVal)
//		.setRelationshipCode(mockStrVal)
//		.setRelationship(mockStrVal)
//		.setBirthType(mockStrVal)
//		.setBirthOrder(mockStrVal)
//		.setAddressline1(mockStrVal)
//		.setAddressline2(mockStrVal)
//		.setAddressline3(mockStrVal)
//		.setAddressline4(mockStrVal)
//		.setAddressPincode(mockStrVal)
//		.setCityCode(mockStrVal)
//		.setCity(mockStrVal)
//		.setDistrictCode(mockStrVal)
//		.setDistrict(mockStrVal)
//		.setStateCode(mockStrVal)
//		.setState(mockStrVal)
//		.setAge(mockIntVal)
//		.setDateOfBirth(strDate)
//		.build();
//    builderDocumentInfo = com.ibm.grpc.stubs.DocumentInfo.newBuilder()   
//		.setName(mockStrVal)
//		.setType(mockStrVal)
//		.setUrl(mockStrVal)
//		.setDocRefno(mockStrVal)
//		.setUploadIndicator(true)
//		.build();
//    
//    
//    		modelBuilderBeneficiaryInfo = BeneficiaryInfo.builder().build();
//		
//		modelBuilderBeneficiaryInfo = buildObjectAttrs(modelBuilderBeneficiaryInfo);
//		
//      	modelBuilderDocumentInfo = DocumentInfo.builder().build();
//		modelBuilderDocumentInfo = buildListObjectAttrs(modelBuilderDocumentInfo);
//}
//
//    private BeneficiaryInfo buildObjectAttrs(BeneficiaryInfo obj){
//		obj.setFirstName(mockStrVal);
//		obj.setMiddleName(mockStrVal);
//		obj.setLastName(mockStrVal);
//		obj.setRelationshipCode(mockStrVal);
//		obj.setRelationship(mockStrVal);
//		obj.setBirthType(mockStrVal);
//		obj.setBirthOrder(mockStrVal);
//		obj.setAddressline1(mockStrVal);
//		obj.setAddressline2(mockStrVal);
//		obj.setAddressline3(mockStrVal);
//		obj.setAddressline4(mockStrVal);
//		obj.setAddressPincode(mockStrVal);
//		obj.setCityCode(mockStrVal);
//		obj.setCity(mockStrVal);
//		obj.setDistrictCode(mockStrVal);
//		obj.setDistrict(mockStrVal);
//		obj.setStateCode(mockStrVal);
//		obj.setState(mockStrVal);
//								obj.setAge(mockIntVal);
//				obj.setDateOfBirth(mockLocalDate);
//    	   		return obj;
//    }
//    
//    private DocumentInfo buildListObjectAttrs(DocumentInfo obj){
//		obj.setName(mockStrVal);
//		obj.setType(mockStrVal);
//		obj.setUrl(mockStrVal);
//		obj.setDocRefno(mockStrVal);
//						obj.setUploadIndicator(true);
//				    	   		return obj;
//    }
//	
//	private InvestmentAccountSsy createModel(){
//		
//		InvestmentAccountSsy model = InvestmentAccountSsy.builder()
//		.cif(mockStrVal)
//		.applicationFormNumber(mockStrVal)
//		.accountNumber(mockStrVal)
//		.activeFlag(true)
//		.branchAddressPincode(mockStrVal)
//		.branchAddressline1(mockStrVal)
//		.branchAddressline2(mockStrVal)
//		.branchAddressline3(mockStrVal)
//		.branchAddressline4(mockStrVal)
//		.branchCity(mockStrVal)
//		.branchCityCode(mockStrVal)
//		.branchCode(mockStrVal)
//		.branchDistrict(mockStrVal)
//		.branchDistrictCode(mockStrVal)
//		.branchName(mockStrVal)
//		.branchPostoffice(mockStrVal)
//		.branchSolId(mockStrVal)
//		.branchState(mockStrVal)
//		.branchStateCode(mockStrVal)
//		.branchSubDistrict(mockStrVal)
//		.channel(mockStrVal)
//		.closingAcceptance(true)
//		.createdBy(mockStrVal)
//		.createdDate(mockLocalDate)
//		.declarationDate(mockLocalDate)
//		.declarationIndicator(true)
//		.modifiedBy(mockStrVal)
//		.modifiedDate(mockLocalDate)
//		.name(mockStrVal)
//		.notificationIndicator(true)
//		.openingDate(mockLocalDate)
//		.phyVerifyFlag(true)
//		.prematureClosingAcceptance(true)
//		.sourceAccountName(mockStrVal)
//		.sourceAccountNumber(mockStrVal)
//		.status(mockStrVal)
//		.transRefNumber(mockStrVal)
//		.verifyBy(mockStrVal)
//		.verifyById(mockStrVal)
//		
//		.beneficiaryDetail(modelBuilderBeneficiaryInfo)
//		.documentDetail(new ArrayList<>(List.of(modelBuilderDocumentInfo)))// for DocumentDetail add instead of set
//		.build();
//		return model;
//	
//	}
//	
//	private List<InvestmentAccountSsy> createModelList(){
//	
//		List<InvestmentAccountSsy> response =  new ArrayList<>();
//		response.add(createModel());
//		return response;
//	}
//	
//	private com.ibm.grpc.stubs.InvestmentAccountSsy createProtoModel(){
//		com.ibm.grpc.stubs.InvestmentAccountSsy model = com.ibm.grpc.stubs.InvestmentAccountSsy.newBuilder()
//		.setCif(mockStrVal)
//		.setApplicationFormNumber(mockStrVal)
//		.setAccountNumber(mockStrVal)
//		.setActiveFlag(true)
//		.setBranchAddressPincode(mockStrVal)
//		.setBranchAddressline1(mockStrVal)
//		.setBranchAddressline2(mockStrVal)
//		.setBranchAddressline3(mockStrVal)
//		.setBranchAddressline4(mockStrVal)
//		.setBranchCity(mockStrVal)
//		.setBranchCityCode(mockStrVal)
//		.setBranchCode(mockStrVal)
//		.setBranchDistrict(mockStrVal)
//		.setBranchDistrictCode(mockStrVal)
//		.setBranchName(mockStrVal)
//		.setBranchPostoffice(mockStrVal)
//		.setBranchSolId(mockStrVal)
//		.setBranchState(mockStrVal)
//		.setBranchStateCode(mockStrVal)
//		.setBranchSubDistrict(mockStrVal)
//		.setChannel(mockStrVal)
//		.setClosingAcceptance(true)
//		.setCreatedBy(mockStrVal)
//		.setCreatedDate(strDate)
//		.setDeclarationDate(strDate)
//		.setDeclarationIndicator(true)
//		.setModifiedBy(mockStrVal)
//		.setModifiedDate(strDate)
//		.setName(mockStrVal)
//		.setNotificationIndicator(true)
//		.setOpeningDate(strDate)
//		.setPhyVerifyFlag(true)
//		.setPrematureClosingAcceptance(true)
//		.setSourceAccountName(mockStrVal)
//		.setSourceAccountNumber(mockStrVal)
//		.setStatus(mockStrVal)
//		.setTransRefNumber(mockStrVal)
//		.setVerifyBy(mockStrVal)
//		.setVerifyById(mockStrVal)
//		
//		.setBeneficiaryDetail(builderBeneficiaryInfo)
//		.addDocumentDetail(builderDocumentInfo)// for DocumentDetail add instead of set
//		.build();
//		return model;
//		
//	}
//	private List<com.ibm.grpc.stubs.InvestmentAccountSsy> createProtoModelList(){
//		List<com.ibm.grpc.stubs.InvestmentAccountSsy> expectedResponse =  new ArrayList<>();		
//		expectedResponse.add(createProtoModel());
//		return expectedResponse;
//	}
//
//
//    @Test
//    @MockitoSettings(strictness = Strictness.LENIENT)
//    void testfindAll() {
//		final StreamObserver<com.ibm.grpc.stubs.InvestmentAccountSsys> responseObserver = mock(
//				StreamObserver.class);
//        List<InvestmentAccountSsy> expectedinvestmentAccountSsy = createModelList();
//		List<com.ibm.grpc.stubs.InvestmentAccountSsy> expectedResponse = createProtoModelList();
//		
//		when(mockRepository.findAll())
//                .thenReturn(expectedinvestmentAccountSsy);
//       // when(mapper.mapToProtoList(expectedinvestmentAccountSsy)).thenReturn(expectedResponse);
//
//        investmentAccountSsyGrpcServiceImplUnderTest.findAll(Empty.newBuilder().build(), responseObserver);
//        verify(mockRepository).findAll();
//    }
//	
//	@Test
//    @MockitoSettings(strictness = Strictness.LENIENT)//As mockito was not able to mock the serviceImpl class
//    public void testFindAll_Exception() {
//		final StreamObserver<com.ibm.grpc.stubs.InvestmentAccountSsys> responseObserver = mock(
//				StreamObserver.class);
//
//		when(mockRepository.findAll()).thenThrow(OptimisticLockingFailureException.class);
//
//		investmentAccountSsyGrpcServiceImplUnderTest.findAll(Empty.newBuilder().build(), responseObserver);
//		verify(mockRepository, times(0)).findAll(any());
//       
//    }
//	
//	 @Test
//    @MockitoSettings(strictness = Strictness.LENIENT)//As mockito was not able to mock the serviceImpl class
//    public  void testFindAll_NoSuchElementException() {
//		final StreamObserver<com.ibm.grpc.stubs.InvestmentAccountSsys> responseObserver = mock(
//				StreamObserver.class);
//
//		when(mockRepository.findAll()).thenThrow(NoSuchElementException.class);
//
//		investmentAccountSsyGrpcServiceImplUnderTest.findAll(Empty.newBuilder().build(), responseObserver);
//		verify(mockRepository, times(0)).findAll(any());
//       
//    }
//	
//	@Test
//    @MockitoSettings(strictness = Strictness.LENIENT)
//    void testSave() {
//        
//		final com.ibm.grpc.stubs.InvestmentAccountSsy request = createProtoModel();
//        final StreamObserver<com.ibm.grpc.stubs.InvestmentAccountSsy> mockResponseObserver = mock(StreamObserver.class);
//        final com.ibm.grpc.stubs.InvestmentAccountSsy expectedResponse =  com.ibm.grpc.stubs.InvestmentAccountSsy.newBuilder().build();
//        final InvestmentAccountSsy expectedEntity = createModel();
//        when(mockRepository.save(createModel()))
//                .thenReturn(createModel());
//       // when(mapper.mapFromProto(request)).thenReturn(expectedEntity);
//       // when(mapper.mapToProto(expectedEntity)).thenReturn(expectedResponse);
//        investmentAccountSsyGrpcServiceImplUnderTest.save(request, mockResponseObserver);
//        verify(mockResponseObserver).onCompleted();
//    }
//
//	@Test
//    @MockitoSettings(strictness = Strictness.LENIENT)//As mockito was not able to mock the serviceImpl class
//    void testSave_Exception() {
//    	  final com.ibm.grpc.stubs.InvestmentAccountSsy request =createProtoModel();
//    	  final InvestmentAccountSsy expectedEntity=createModel();
//          final StreamObserver<com.ibm.grpc.stubs.InvestmentAccountSsy> mockResponseObserver = mock(StreamObserver.class);
//          when(mockRepository.save(any(InvestmentAccountSsy.class)))
//                  .thenThrow(OptimisticLockingFailureException.class);
//
//          investmentAccountSsyGrpcServiceImplUnderTest.save(request, mockResponseObserver);
//         // verify(mockRepository, times(0)).save(any());
//          //verify(mockResponseObserver).onNext(null);
//          
//        //  verify(mockRepository).save(expectedEntity);
//       
//    }
//	
//	@Test
//    @MockitoSettings(strictness = Strictness.LENIENT)//As mockito was not able to mock the serviceImpl class
//    void testSave_NoSuchElementException() {
//    	  final com.ibm.grpc.stubs.InvestmentAccountSsy request =createProtoModel();
//    	  final InvestmentAccountSsy expectedEntity=createModel();
//          final StreamObserver<com.ibm.grpc.stubs.InvestmentAccountSsy> mockResponseObserver = mock(StreamObserver.class);
//          when(mockRepository.save(any(InvestmentAccountSsy.class)))
//                  .thenThrow(NoSuchElementException.class);
//
//          investmentAccountSsyGrpcServiceImplUnderTest.save(request, mockResponseObserver);
//          //verify(mockRepository, times(0)).save(any());
//          //verify(mockResponseObserver).onNext(null);
//          
//        //  verify(mockRepository).save(expectedEntity);
//       
//    }
//
//    @Test
//    @MockitoSettings(strictness = Strictness.LENIENT)
//    void testUpdate() {
//        
//		final com.ibm.grpc.stubs.InvestmentAccountSsy request = createProtoModel();
//        final StreamObserver<com.ibm.grpc.stubs.InvestmentAccountSsy> mockResponseObserver = mock(StreamObserver.class);
//        final com.ibm.grpc.stubs.InvestmentAccountSsy expectedResponse =  com.ibm.grpc.stubs.InvestmentAccountSsy.newBuilder().build();
//        final InvestmentAccountSsy expectedEntity = createModel();
//        when(mockRepository.save(createModel()))
//                .thenReturn(createModel());
//       // when(mapper.mapFromProto(request)).thenReturn(expectedEntity);
//       // when(mapper.mapToProto(expectedEntity)).thenReturn(expectedResponse);
//        investmentAccountSsyGrpcServiceImplUnderTest.update(request, mockResponseObserver);
//        verify(mockResponseObserver).onCompleted();
//		
//    }
//	
//	@Test
//    @MockitoSettings(strictness = Strictness.LENIENT)//As mockito was not able to mock the serviceImpl class
//    void testUpdate_Exception() {
//    	  final com.ibm.grpc.stubs.InvestmentAccountSsy request =createProtoModel();
//
//          final StreamObserver<com.ibm.grpc.stubs.InvestmentAccountSsy> mockResponseObserver = mock(StreamObserver.class);
//          when(mockRepository.save(any(InvestmentAccountSsy.class)))
//                  .thenThrow(OptimisticLockingFailureException.class);
//
//          investmentAccountSsyGrpcServiceImplUnderTest.update(request, mockResponseObserver);
//         // verify(mockRepository, times(0)).save(any());
//  
//       
//    }
//    
//	@Test
//    @MockitoSettings(strictness = Strictness.LENIENT)//As mockito was not able to mock the serviceImpl class
//    void testUpdate_NoSuchElementException() {
//    	  final com.ibm.grpc.stubs.InvestmentAccountSsy request =createProtoModel();
//
//          final StreamObserver<com.ibm.grpc.stubs.InvestmentAccountSsy> mockResponseObserver = mock(StreamObserver.class);
//          when(mockRepository.save(any(InvestmentAccountSsy.class)))
//                  .thenThrow(NoSuchElementException.class);
//
//          investmentAccountSsyGrpcServiceImplUnderTest.update(request, mockResponseObserver);
//          //verify(mockRepository, times(0)).save(any());
//  
//       
//    }
//	
//    @Test
//    @MockitoSettings(strictness = Strictness.LENIENT)//As mockito was not able to mock the serviceImpl class
//    void testFindByCif() {
//		final StreamObserver<com.ibm.grpc.stubs.InvestmentAccountSsys> responseObserver = mock(StreamObserver.class);
//		InvestmentAccountSsy expectedEntity = createModel();
//		AllInvestmentAccountSsyPartitionKeys request = AllInvestmentAccountSsyPartitionKeys.newBuilder().setCif(expectedEntity.getCif()).build();
//        List<InvestmentAccountSsy> expectedEntityList = createModelList();
//		List<com.ibm.grpc.stubs.InvestmentAccountSsy> expectedResponse =   createProtoModelList();
//        when(mockRepository.findByCif(request.getCif()))
//                .thenReturn(expectedEntityList);
//      //  when(mapper.mapToProtoList(expectedEntityList)).thenReturn(expectedResponse);
//
//        investmentAccountSsyGrpcServiceImplUnderTest.findByCif(request, responseObserver);
//        verify(mockRepository).findByCif(request.getCif());
//        
//    }
//    
//	@Test
//    @MockitoSettings(strictness = Strictness.LENIENT)//As mockito was not able to mock the serviceImpl class
//    public void testFindByCif_Exception() {
//    	final StreamObserver<com.ibm.grpc.stubs.InvestmentAccountSsys> responseObserver = mock(StreamObserver.class);
//    	InvestmentAccountSsy expectedEntity = createModel();
//    	AllInvestmentAccountSsyPartitionKeys request = AllInvestmentAccountSsyPartitionKeys.newBuilder().setCif(expectedEntity.getCif()).build();
//
//        
//		when(mockRepository.findByCif(request.getCif()))
//		.thenThrow(OptimisticLockingFailureException.class);
//
//		investmentAccountSsyGrpcServiceImplUnderTest.findByCif(request, responseObserver);
//		//verify(mockRepository, times(0)).findByCif(any());
//  
//       
//    }
//	
//	@Test
//    @MockitoSettings(strictness = Strictness.LENIENT)//As mockito was not able to mock the serviceImpl class
//    public void testFindByCifNoSuchElementException() {
//    	final StreamObserver<com.ibm.grpc.stubs.InvestmentAccountSsys> responseObserver = mock(StreamObserver.class);
//    	InvestmentAccountSsy expectedEntity = createModel();
//    	AllInvestmentAccountSsyPartitionKeys request = AllInvestmentAccountSsyPartitionKeys.newBuilder().setCif(expectedEntity.getCif()).build();
//
//        
//		when(mockRepository.findByCif(request.getCif()))
//		.thenThrow(NoSuchElementException.class);
//
//		investmentAccountSsyGrpcServiceImplUnderTest.findByCif(request, responseObserver);
//		//verify(mockRepository, times(0)).findByCif(any());
//  
//       
//    }
//	
//    @Test
//    @MockitoSettings(strictness = Strictness.LENIENT)//As mockito was not able to mock the serviceImpl class
//    void testFindByCifAndApplicationFormNumber() {
//        final StreamObserver<com.ibm.grpc.stubs.InvestmentAccountSsys> responseObserver = mock(StreamObserver.class);
//		InvestmentAccountSsy expectedEntity = createModel();
//		AllInvestmentAccountSsyPartitionAndClusterKeys request = AllInvestmentAccountSsyPartitionAndClusterKeys.newBuilder().setCif(expectedEntity.getCif()).setApplicationFormNumber(expectedEntity.getApplicationFormNumber()).build();
//		List<InvestmentAccountSsy> expectedEntityList = createModelList();
//		List<com.ibm.grpc.stubs.InvestmentAccountSsy> expectedResponse =   createProtoModelList();
//        when(mockRepository.findByCifAndApplicationFormNumber(request.getCif() ,request.getApplicationFormNumber()))
//                .thenReturn(expectedEntityList);
//       // when(mapper.mapToProtoList(expectedEntityList)).thenReturn(expectedResponse);
//
//        investmentAccountSsyGrpcServiceImplUnderTest.findByCifAndApplicationFormNumber(request, responseObserver);
//        verify(mockRepository).findByCifAndApplicationFormNumber(request.getCif() ,request.getApplicationFormNumber());
//        
//    }
//	
//	@Test
//    @MockitoSettings(strictness = Strictness.LENIENT)//As mockito was not able to mock the serviceImpl class
//    public void testFindByCifAndApplicationFormNumber_Exception() {
//    	final StreamObserver<com.ibm.grpc.stubs.InvestmentAccountSsys> responseObserver = mock(StreamObserver.class);
//    	InvestmentAccountSsy expectedEntity = createModel();
//    	AllInvestmentAccountSsyPartitionAndClusterKeys request = AllInvestmentAccountSsyPartitionAndClusterKeys.newBuilder().setCif(expectedEntity.getCif()).setApplicationFormNumber(expectedEntity.getApplicationFormNumber()).build();
//
//        
//		when(mockRepository.findByCifAndApplicationFormNumber(request.getCif() ,request.getApplicationFormNumber()))
//		.thenThrow(OptimisticLockingFailureException.class);
//
//		investmentAccountSsyGrpcServiceImplUnderTest.findByCifAndApplicationFormNumber(request, responseObserver);
//		//verify(mockRepository, times(0)).findByCifAndApplicationFormNumber(any(),any());
//  
//       
//    }
//	
//	@Test
//    @MockitoSettings(strictness = Strictness.LENIENT)//As mockito was not able to mock the serviceImpl class
//    public void testFindByCifAndApplicationFormNumberNoSuchElementException() {
//    	final StreamObserver<com.ibm.grpc.stubs.InvestmentAccountSsys> responseObserver = mock(StreamObserver.class);
//    	InvestmentAccountSsy expectedEntity = createModel();
//    	AllInvestmentAccountSsyPartitionAndClusterKeys request = AllInvestmentAccountSsyPartitionAndClusterKeys.newBuilder().setCif(expectedEntity.getCif()).setApplicationFormNumber(expectedEntity.getApplicationFormNumber()).build();
//
//        
//		when(mockRepository.findByCifAndApplicationFormNumber(request.getCif() ,request.getApplicationFormNumber()))
//		.thenThrow(NoSuchElementException.class);
//
//		investmentAccountSsyGrpcServiceImplUnderTest.findByCifAndApplicationFormNumber(request, responseObserver);
//		//verify(mockRepository, times(0)).findByCifAndApplicationFormNumber(any(),any());
//  
//       
//    }
//	
//    
//    @Test
//    @MockitoSettings(strictness = Strictness.LENIENT)//As mockito was not able to mock the serviceImpl class
//    void deleteByCif() {
//	
//		final StreamObserver<com.google.protobuf.Empty> responseObserver = mock(StreamObserver.class);
//		InvestmentAccountSsy expectedEntity = createModel();
//		AllInvestmentAccountSsyPartitionKeys request = AllInvestmentAccountSsyPartitionKeys.newBuilder().setCif(expectedEntity.getCif()).build();
//		investmentAccountSsyGrpcServiceImplUnderTest.deleteByCif(request, responseObserver);
//		verify(responseObserver).onNext(null);
//        
//    }
//	
//	@Test
//    @MockitoSettings(strictness = Strictness.LENIENT)//As mockito was not able to mock the serviceImpl class
//    void deleteByCif_Exception() {
//	
//		final StreamObserver<com.google.protobuf.Empty> responseObserver = mock(StreamObserver.class);
//		InvestmentAccountSsy expectedEntity = createModel();
//		AllInvestmentAccountSsyPartitionKeys request = AllInvestmentAccountSsyPartitionKeys.newBuilder().setCif(expectedEntity.getCif()).build();
//		doThrow(OptimisticLockingFailureException.class).when(mockRepository).deleteByCif(request.getCif());
//		investmentAccountSsyGrpcServiceImplUnderTest.deleteByCif(request, responseObserver);
//		verify(mockRepository, times(0)).delete(any());
//        
//    }
//	
//	@Test
//    @MockitoSettings(strictness = Strictness.LENIENT)//As mockito was not able to mock the serviceImpl class
//    void deleteByCif_NoSuchElementException() {
//	
//		final StreamObserver<com.google.protobuf.Empty> responseObserver = mock(StreamObserver.class);
//		InvestmentAccountSsy expectedEntity = createModel();
//		AllInvestmentAccountSsyPartitionKeys request = AllInvestmentAccountSsyPartitionKeys.newBuilder().setCif(expectedEntity.getCif()).build();
//		doThrow(NoSuchElementException.class).when(mockRepository).deleteByCif(request.getCif());
//		investmentAccountSsyGrpcServiceImplUnderTest.deleteByCif(request, responseObserver);
//		verify(mockRepository, times(0)).delete(any());
//        
//    }
//	
//    @Test
//    @MockitoSettings(strictness = Strictness.LENIENT)//As mockito was not able to mock the serviceImpl class
//    void deleteByCifAndApplicationFormNumber() {
//		final StreamObserver<com.google.protobuf.Empty> responseObserver = mock(StreamObserver.class);
//		InvestmentAccountSsy expectedEntity = createModel();
//		AllInvestmentAccountSsyPartitionAndClusterKeys request = AllInvestmentAccountSsyPartitionAndClusterKeys.newBuilder().setCif(expectedEntity.getCif()).setApplicationFormNumber(expectedEntity.getApplicationFormNumber()).build();
//        investmentAccountSsyGrpcServiceImplUnderTest.deleteByCifAndApplicationFormNumber(request, responseObserver);
//		verify(responseObserver).onNext(null);
//		
//    }
//	
//	@Test
//    @MockitoSettings(strictness = Strictness.LENIENT)//As mockito was not able to mock the serviceImpl class
//    void deleteByCifAndApplicationFormNumber_Exception() {
//	
//		final StreamObserver<com.google.protobuf.Empty> responseObserver = mock(StreamObserver.class);
//		InvestmentAccountSsy expectedEntity = createModel();
//		AllInvestmentAccountSsyPartitionAndClusterKeys request = AllInvestmentAccountSsyPartitionAndClusterKeys.newBuilder().setCif(expectedEntity.getCif()).setApplicationFormNumber(expectedEntity.getApplicationFormNumber()).build();
//		doThrow(OptimisticLockingFailureException.class).when(mockRepository).deleteByCifAndApplicationFormNumber(request.getCif() ,request.getApplicationFormNumber());
//		investmentAccountSsyGrpcServiceImplUnderTest.deleteByCifAndApplicationFormNumber(request, responseObserver);
//		verify(mockRepository, times(0)).delete(any());
//        
//    }
//	
//	@Test
//    @MockitoSettings(strictness = Strictness.LENIENT)//As mockito was not able to mock the serviceImpl class
//    void deleteByCifAndApplicationFormNumber_NoSuchElementException() {
//	
//		final StreamObserver<com.google.protobuf.Empty> responseObserver = mock(StreamObserver.class);
//		InvestmentAccountSsy expectedEntity = createModel();
//		AllInvestmentAccountSsyPartitionAndClusterKeys request = AllInvestmentAccountSsyPartitionAndClusterKeys.newBuilder().setCif(expectedEntity.getCif()).setApplicationFormNumber(expectedEntity.getApplicationFormNumber()).build();
//		doThrow(NoSuchElementException.class).when(mockRepository).deleteByCifAndApplicationFormNumber(request.getCif() ,request.getApplicationFormNumber());
//		investmentAccountSsyGrpcServiceImplUnderTest.deleteByCifAndApplicationFormNumber(request, responseObserver);
//		verify(mockRepository, times(0)).delete(any());
//        
//    }
//	
//    
//}
