package com.ubi.dbp.investment.apy.dal.utils;

//import java.time.LocalDateTime;
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Optional;
//
//import com.ubi.dbp.investment.apy.dal.entity.InvestmentAccountApy;
//import com.ubi.dbp.investment.apy.model.Ssa;
//
//import dbp.framework.common.investment.model.DeclarationDetails;
//import dbp.framework.common.investment.model.Document;
//import dbp.framework.common.investment.model.InvestmentContribution;
//import dbp.framework.common.model.AcctBuilder;
//import dbp.framework.common.model.Address;
//import dbp.framework.common.model.BankInfo;
//import dbp.framework.common.model.Beneficiary;
//import dbp.framework.common.model.ContactInfo;
//import dbp.framework.common.model.Customer;
//
//public class InvestmentAccountSsyEntityMapper {
//
//	public static InvestmentAccountSsy mapToEntity(Ssa ssa) {
//
//		InvestmentAccountSsyBuilder builder = InvestmentAccountSsy.builder();
//
//		Optional.ofNullable(ssa.getStatus()).ifPresentOrElse(builder::status, () -> builder.status(""));
//		Optional.ofNullable(ssa.getCif()).ifPresentOrElse(builder::cif, () -> builder.cif(""));
//		Optional.ofNullable(ssa.getApplNum()).ifPresentOrElse(builder::applicationFormNumber,
//				() -> builder.applicationFormNumber(""));
//		Optional.ofNullable(ssa.getDisplayName()).ifPresentOrElse(builder::name, () -> builder.name(""));
//		if (ssa.getBankInfo() != null) {
//
//			if (ssa.getBankInfo().getAddress() != null) {
//				Optional.ofNullable(ssa.getBankInfo().getAddress().getPinCode())
//						.ifPresentOrElse(builder::branchAddressPincode, () -> builder.branchAddressPincode(""));
//				Optional.ofNullable(ssa.getBankInfo().getAddress().getAddrLine1())
//						.ifPresentOrElse(builder::branchAddressline1, () -> builder.branchAddressline1(""));
//				Optional.ofNullable(ssa.getBankInfo().getAddress().getAddrLine2())
//						.ifPresentOrElse(builder::branchAddressline2, () -> builder.branchAddressline2(""));
//				Optional.ofNullable(ssa.getBankInfo().getAddress().getAddrLine3())
//						.ifPresentOrElse(builder::branchAddressline3, () -> builder.branchAddressline3(""));
//				Optional.ofNullable(ssa.getBankInfo().getAddress().getAddrLine4())
//						.ifPresentOrElse(builder::branchAddressline4, () -> builder.branchAddressline4(""));
//				Optional.ofNullable(ssa.getBankInfo().getAddress().getCityCode()).ifPresentOrElse(builder::branchCity,
//						() -> builder.branchCity(""));
//				Optional.ofNullable(ssa.getBankInfo().getAddress().getCityCode())
//						.ifPresentOrElse(builder::branchCityCode, () -> builder.branchCityCode(""));
//				Optional.ofNullable(ssa.getBankInfo().getAddress().getPinCode())
//						.ifPresentOrElse(builder::branchPostoffice, () -> builder.branchPostoffice(""));
//				Optional.ofNullable(ssa.getBankInfo().getAddress().getStateCode()).ifPresentOrElse(builder::branchState,
//						() -> builder.branchState(""));
//				Optional.ofNullable(ssa.getBankInfo().getAddress().getStateCode())
//						.ifPresentOrElse(builder::branchStateCode, () -> builder.branchStateCode(""));
//				Optional.ofNullable(ssa.getBankInfo().getBranchName()).ifPresentOrElse(builder::branchName,
//						() -> builder.branchName(""));
//			}
//			if (ssa.getBankInfo().getBranchSolId() != null) {
//				Optional.ofNullable(ssa.getBankInfo().getBranchId()).ifPresentOrElse(builder::branchCode,
//						() -> builder.branchCode(""));
//				Optional.ofNullable(ssa.getBankInfo().getBranchSolId()).ifPresentOrElse(builder::branchSolId,
//						() -> builder.branchSolId(""));
//			}
//		}
//		Optional.ofNullable(ssa.getChannel()).ifPresentOrElse(builder::channel, () -> builder.channel(""));
//		if (ssa.getDeclarationDetails() != null) {
//			Optional.ofNullable(ssa.getDeclarationDetails().getAcceptedDate()).ifPresentOrElse(
//					(value) -> builder.declarationDate(value), () -> builder.declarationDate(LocalDateTime.now()));
//			Optional.ofNullable(ssa.getDeclarationDetails().getIsAccepted())
//					.ifPresentOrElse(builder::declarationIndicator, () -> builder.declarationIndicator(false));
//		}
//		Optional.ofNullable(ssa.getCreatedDate()).ifPresentOrElse((value) -> builder.createdDate(value),
//				() -> builder.createdDate(LocalDateTime.now()));
//		Optional.ofNullable(ssa.getModifiedDate()).ifPresentOrElse((value) -> builder.modifiedDate(value),
//				() -> builder.modifiedDate(LocalDateTime.now()));
//		if (ssa.getSource() != null) {
//			Optional.ofNullable(ssa.getSource().getName()).ifPresentOrElse(builder::sourceAccountName,
//					() -> builder.sourceAccountName(""));
//			Optional.ofNullable(ssa.getSource().getAcctNum()).ifPresentOrElse(builder::sourceAccountNumber,
//					() -> builder.sourceAccountNumber(""));
//		}
//		Optional.ofNullable(ssa.getTransRefNum()).ifPresentOrElse(builder::transRefNumber,
//				() -> builder.transRefNumber(""));
//		Optional.ofNullable(ssa.getVerifyBy()).ifPresentOrElse(builder::verifyBy, () -> builder.verifyBy(""));
//		Optional.ofNullable(ssa.getVerifyById()).ifPresentOrElse(builder::verifyById, () -> builder.verifyById(""));
//		Optional.ofNullable(ssa.getPhyVerified()).ifPresentOrElse(builder::phyVerifyFlag,
//				() -> builder.phyVerifyFlag(false));
//		builder.beneficiaryDetail(mapBeneficiaryToEntity(ssa));
//		if (ssa.getDocuments() != null) {
//			List<DocumentInfo> docList = new ArrayList<>();
//			ssa.getDocuments().forEach(d -> {
//				docList.add(mapDocumentToEntity(d));
//			});
//			builder.documentDetail(docList);
//		}
//		return builder.build();
//	}
//
//	public static Ssa mapFromEntity(InvestmentAccountSsy investmentAccountSsa) {
//		Ssa.Builder builder = new Ssa.Builder();
//		builder.cif(investmentAccountSsa.getCif()).applNum(investmentAccountSsa.getApplicationFormNumber());
//		AcctBuilder acctBuilder = AcctBuilder.builder();
//		Customer customer = new Customer(investmentAccountSsa.getCif(), null, null, null, null, null, null, false,
//				null);
//		builder.customer(customer);
//		acctBuilder.cif(investmentAccountSsa.getCif());
//		builder.source(acctBuilder.build());
//		BankInfo.BankInfoBuilder bankInfoBuilder = BankInfo.builder();
//
//		Address.AddressBuilder addrBuilder = Address.builder();
//		addrBuilder.addrLine1(investmentAccountSsa.getBranchAddressline1())
//				.addrLine2(investmentAccountSsa.getBranchAddressline2())
//				.addrLine3(investmentAccountSsa.getBranchAddressline3())
//				.addrLine4(investmentAccountSsa.getBranchAddressline4())
//				.cityCode(investmentAccountSsa.getBranchCityCode())
//				.pinCode(investmentAccountSsa.getBranchAddressPincode())
//				.stateCode(investmentAccountSsa.getBranchStateCode());
//		bankInfoBuilder.branchId(investmentAccountSsa.getBranchCode()).branchName(investmentAccountSsa.getBranchName())
//				.branchSolId(investmentAccountSsa.getBranchSolId()).address(addrBuilder.build());
//		builder.channel(investmentAccountSsa.getChannel());
//		builder.bankInfo(bankInfoBuilder.build());
//		DeclarationDetails declarationDetails = new DeclarationDetails();
//		builder.declarationDetails(declarationDetails);
//		declarationDetails.setIsAccepted(investmentAccountSsa.getDeclarationIndicator());
//		declarationDetails.setAcceptedDate(investmentAccountSsa.getDeclarationDate());
//		builder.displayName(investmentAccountSsa.getName());
//		acctBuilder = AcctBuilder.builder();
//		acctBuilder.acctNum(investmentAccountSsa.getSourceAccountNumber())
//				.name(investmentAccountSsa.getSourceAccountName()).cif(investmentAccountSsa.getCif());
//		builder.source(acctBuilder.build());
//		builder.status(investmentAccountSsa.getStatus());
//		builder.referenceNum(investmentAccountSsa.getTransRefNumber());
//		builder.createdDate(investmentAccountSsa.getCreatedDate()).modifiedDate(investmentAccountSsa.getModifiedDate());
//		if (investmentAccountSsa.getBeneficiaryDetail() != null) {
//			builder.birthType(investmentAccountSsa.getBeneficiaryDetail().getBirthType());
//			builder.birthOrder(investmentAccountSsa.getBeneficiaryDetail().getBirthOrder());
//		}
//		builder.beneficiary(mapFromEntity(investmentAccountSsa.getBeneficiaryDetail()));
//		InvestmentContribution.InvestmentContributionBuilder ibuilder = InvestmentContribution.builder();
//		ibuilder.contribAcctNum(investmentAccountSsa.getAccountNumber());
//		InvestmentContribution invstContrib = ibuilder.build();
//		builder.investmentContribution(invstContrib);
//		if (investmentAccountSsa.getDocumentDetail() != null) {
//			List<Document> docList = new ArrayList<>();
//			builder.documents(docList);
//			investmentAccountSsa.getDocumentDetail().forEach(doc -> {
//				docList.add(mapFromEntity(doc));
//			});
//		}
//		Ssa ssa = builder.build();
//		return ssa;
//	}
//
//	public static List<InvestmentAccountSsy> mapToEntityList(List<Ssa> sourceList) {
//		List<InvestmentAccountSsy> retList = new ArrayList<>();
//		sourceList.forEach(s -> {
//			retList.add(mapToEntity(s));
//		});
//		return retList;
//	}
//
//	public static List<Ssa> mapFromEntityList(List<InvestmentAccountSsy> sourceList) {
//		List<Ssa> retList = new ArrayList<>();
//		sourceList.forEach(s -> {
//			retList.add(mapFromEntity(s));
//		});
//		return retList;
//
//	}
//
//	public static BeneficiaryInfo mapBeneficiaryToEntity(Ssa ssa) {
//		Beneficiary beneficiary = ssa.getBeneficiary();
//		BeneficiaryInfoBuilder builder = BeneficiaryInfo.builder();
//		if (beneficiary != null) {
//			Optional.ofNullable(beneficiary.getFname()).ifPresentOrElse(builder::firstName,
//					() -> builder.firstName(""));
//			Optional.ofNullable(beneficiary.getMname()).ifPresentOrElse(builder::middleName,
//					() -> builder.middleName(""));
//			Optional.ofNullable(beneficiary.getLname()).ifPresentOrElse(builder::lastName, () -> builder.lastName(""));
//			Optional.ofNullable(beneficiary.getRelShipId()).ifPresentOrElse(builder::relationshipCode,
//					() -> builder.relationshipCode(""));
//			Optional.ofNullable(beneficiary.getRelShipId()).ifPresentOrElse(builder::relationship,
//					() -> builder.relationship(""));
//			Optional.ofNullable(beneficiary.getDob().atTime(23, 59, 59)).ifPresentOrElse(
//					(value) -> builder.dateOfBirth(value), () -> builder.dateOfBirth(LocalDateTime.now()));
//			Optional.ofNullable(ssa.getBirthType()).ifPresentOrElse(builder::birthType, () -> builder.birthType(""));
//			Optional.ofNullable(ssa.getBirthOrder()).ifPresentOrElse(builder::birthOrder, () -> builder.birthOrder(""));
//			if (beneficiary.getContactInfo() != null && beneficiary.getContactInfo().getPostalAddr() != null) {
//				ContactInfo contactInfo = beneficiary.getContactInfo();
//				Address address = contactInfo.getPostalAddr();
//				Optional.ofNullable(address.getAddrLine1()).ifPresentOrElse(builder::addressline1,
//						() -> builder.addressline1(""));
//				Optional.ofNullable(address.getAddrLine2()).ifPresentOrElse(builder::addressline2,
//						() -> builder.addressline2(""));
//				Optional.ofNullable(address.getAddrLine3()).ifPresentOrElse(builder::addressline3,
//						() -> builder.addressline3(""));
//				Optional.ofNullable(address.getAddrLine4()).ifPresentOrElse(builder::addressline4,
//						() -> builder.addressline4(""));
//				Optional.ofNullable(address.getPinCode()).ifPresentOrElse(builder::addressPincode,
//						() -> builder.addressPincode(""));
//				Optional.ofNullable(address.getCityCode()).ifPresentOrElse(builder::cityCode,
//						() -> builder.cityCode(""));
//				Optional.ofNullable(address.getStateCode()).ifPresentOrElse(builder::stateCode,
//						() -> builder.stateCode(""));
//			}
//			return builder.build();
//		} else {
//			return BeneficiaryInfo.builder().dateOfBirth(LocalDateTime.now()).build();
//		}
//	}
//
//	public static Beneficiary mapFromEntity(BeneficiaryInfo beneficiaryInfo) {
//		Beneficiary.Builder builder = new Beneficiary.Builder();
//		builder.fname(beneficiaryInfo.getFirstName()).mname(beneficiaryInfo.getMiddleName())
//				.lname(beneficiaryInfo.getLastName()).dob((beneficiaryInfo.getDateOfBirth()).toLocalDate());
//		builder.relShipId(beneficiaryInfo.getRelationshipCode());
//		if (beneficiaryInfo != null) {
//			Address.AddressBuilder addrBuilder = Address.builder();
//			addrBuilder.addrLine1(beneficiaryInfo.getAddressline1()).addrLine2(beneficiaryInfo.getAddressline2())
//					.addrLine3(beneficiaryInfo.getAddressline3()).addrLine4(beneficiaryInfo.getAddressline4())
//					.cityCode(beneficiaryInfo.getCityCode()).stateCode(beneficiaryInfo.getStateCode())
//					.pinCode(beneficiaryInfo.getAddressPincode());
//			ContactInfo.ContactInfoBuilder cifBuilder = ContactInfo.builder();
//			cifBuilder.postalAddr(addrBuilder.build());
//			builder.contactInfo(cifBuilder.build());
//		}
//		return builder.build();
//	}
//
//	public static DocumentInfo mapDocumentToEntity(Document doc) {
//		DocumentInfoBuilder builder = DocumentInfo.builder();
//		Optional.ofNullable(doc.getName()).ifPresentOrElse(builder::name, () -> builder.name(""));
//		Optional.ofNullable(doc.getType()).ifPresentOrElse(builder::type, () -> builder.type(""));
//		Optional.ofNullable(doc.getUri()).ifPresentOrElse(builder::url, () -> builder.url(""));
//		Optional.ofNullable(doc.getDocRefNo()).ifPresentOrElse(builder::docRefno, () -> builder.docRefno(""));
//		return builder.build();
//	}
//
//	public static Document mapFromEntity(DocumentInfo doc) {
//		Document.DocumentBuilder builder = Document.builder();
//		builder.docRefNo(doc.getDocRefno()).name(doc.getName()).type(doc.getType()).uri(doc.getUrl());
//		return builder.build();
//	}
//
//}
