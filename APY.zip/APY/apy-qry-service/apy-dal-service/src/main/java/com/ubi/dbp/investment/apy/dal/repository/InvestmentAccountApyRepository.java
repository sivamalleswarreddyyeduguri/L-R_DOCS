package com.ubi.dbp.investment.apy.dal.repository;

import java.util.List;

import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;
import org.springframework.stereotype.Repository;

import com.ubi.dbp.investment.apy.dal.entity.InvestmentAccountApy;

@Repository
public interface InvestmentAccountApyRepository extends CassandraRepository<InvestmentAccountApy, String> {
	 // Find by all partitioned columns only. This will return  a list of records
    List<InvestmentAccountApy> findByCif(String cif);
	
    // Find by all partitioned and clustered columns. This will return the unique record
    List<InvestmentAccountApy> findByCifAndApplicationFormNumber(String cif,String applicationFormNumber);

    @Query("DELETE FROM investment_account_apy WHERE  cif = ?0 ")
    void deleteByCif(String cif);
	
    @Query("DELETE FROM investment_account_apy WHERE  cif = ?0  AND  application_form_number = ?1 ")
    void deleteByCifAndApplicationFormNumber(String cif,String applicationFormNumber);

    InvestmentAccountApy save(InvestmentAccountApy investmentAccountApy);

}
