package com.ubi.dbp.investment.apy.dal.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

import org.springframework.data.cassandra.core.mapping.Column;
import org.springframework.data.cassandra.core.mapping.UserDefinedType;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@UserDefinedType("nominee_info")
public class NomineeInfo implements Serializable{

    private static final long serialVersionUID = 3698444027865231718L;
    
    
	@Column("first_name")
    private String firstName;
    @Column("middle_name")
    private String middleName;
    @Column("last_name")
    private String lastName;
    @Column("account_type")
    private String accountType;
    @Column("allocationpercent")
    private BigDecimal allocationPercent;
    @Column("relationship_code")
    private String relationshipCode;
    @Column("relationship")
    private String relationship;
    @Column("age")
    private Integer age;
    @Column("date_of_birth")
    private LocalDateTime dateOfBirth;
    @Column("is_same_addr")
    private Boolean isSameAddr;
    @Column("addressline1")
    private String addressline1;
    @Column("addressline2")
    private String addressline2;
    @Column("addressline3")
    private String addressline3;
    @Column("addressline4")
    private String addressline4;
    @Column("address_pincode")
    private String addressPincode;
    @Column("city_code")
    private String cityCode;
    @Column("city")
    private String city;
    @Column("district_code")
    private String districtCode;
    @Column("district")
    private String district;
    @Column("state_code")
    private String stateCode;
    @Column("state")
    private String state;
    @Column("minor_flag")
    private Boolean minorFlag;
    @Column("guardian_relationship_code")
    private String guardianRelationshipCode;
    @Column("guardian_relationship")
    private String guardianRelationship;
    @Column("guardian_first_name")
    private String guardianFirstName;
    @Column("guardian_middle_name")
    private String guardianMiddleName;
    @Column("guardian_last_name")
    private String guardianLastName;
    @Column("guardian_date_of_birth")
    private LocalDateTime guardianDateOfBirth;
    @Column("guardian_age")
    private Integer guardianAge;
    @Column("guardian_addressline1")
    private String guardianAddressline1;
    @Column("guardian_addressline2")
    private String guardianAddressline2;
    @Column("guardian_addressline3")
    private String guardianAddressline;
    @Column("guardian_addressline4")
    private String guardianAddressline4;
    @Column("guardian_address_pincode")
    private String guardianAddressPincode;
    @Column("guardian_city_code")
    private String guardianCityCode;
    @Column("guardian_city")
    private String guardianCity;
    @Column("guardian_district_code")
    private String guardianDistrictCode;
    @Column("guardian_district")
    private String guardianDistrict;
    @Column("guardian_state_code")
    private String guardianStateCode;
    @Column("guardian_state")
    private String guardianState;
	
//	public boolean isEmpty()  {
//
//	    for (Field field : this.getClass().getDeclaredFields()) {
//	        try {
//	            field.setAccessible(true);
//	            if (field.get(this)!=null) {
//	                return false;
//	            }
//	        } catch (Exception e) {
//	          e.printStackTrace();
//	        }
//	    }
//    	return true;
//    }
}
