package com.ubi.dbp.investment.apy.dal.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

import org.springframework.data.cassandra.core.cql.PrimaryKeyType;
import org.springframework.data.cassandra.core.mapping.Column;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;
import org.springframework.data.cassandra.core.mapping.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table("investment_account_apy")
public class InvestmentAccountApy implements Serializable{

    private static final long serialVersionUID = 7586395088937556515L;
    
    
	@PrimaryKeyColumn(value = "cif", type = PrimaryKeyType.PARTITIONED)
    @Column("cif")
    private String cif;
    @PrimaryKeyColumn(value = "application_form_number", type = PrimaryKeyType.CLUSTERED)
    @Column("application_form_number")
    private String applicationFormNumber;
    @Column("account_number")
    private String accountNumber;
    @Column("active_flag")
    private Boolean activeFlag;
    @Column("branch_address_pincode")
    private String branchAddressPincode;
    @Column("branch_addressline1")
    private String branchAddressline1;
    @Column("branch_addressline2")
    private String branchAddressline2;
    @Column("branch_addressline3")
    private String branchAddressline3;
    @Column("branch_addressline4")
    private String branchAddressline4;
    @Column("branch_city")
    private String branchCity;
    @Column("branch_city_code")
    private String branchCityCode;
    @Column("branch_code")
    private String branchCode;
    @Column("branch_district")
    private String branchDistrict;
    @Column("branch_district_code")
    private String branchDistrictCode;
    @Column("branch_name")
    private String branchName;
    @Column("branch_postoffice")
    private String branchPostoffice;
    @Column("branch_sol_id")
    private String branchSolId;
    @Column("branch_state")
    private String branchState;
    @Column("branch_state_code")
    private String branchStateCode;
    @Column("branch_sub_district")
    private String branchSubDistrict;
    @Column("branch_working_days")
    private String branchWorkingDays;
    @Column("branch_working_hrs")
    private String branchWorkingHrs;
    @Column("channel")
    private String channel;
    @Column("contribution_frequency")
    private String contrubutionFrequency;
    @Column("contribution_period")
    private Integer contributionPeriod;
    @Column("created_by")
    private String createdBy;
    @Column("created_date")
    private LocalDateTime createdDate;
    @Column("date_of_deposit")
    private LocalDateTime dateOfDeposit;
    @Column("declaration_date")
    private LocalDateTime declarationDate;
    @Column("declaration_indicator")
    private Boolean declarationIndicator;
    @Column("income_tax_flag")
    private Boolean incomeTaxFlag;
    @Column("marital_status")
    private String martialStatus;
    @Column("modified_by")
    private String modifiedBy;
    @Column("modified_date")
    private LocalDateTime modifiedDate;
    @Column("name")
    private String name;

    @Column("nominee_detail")
    private NomineeInfo nomineeDetail;
    @Column("notification_indicator")
    private Boolean notificationIndicator;
    @Column("payment_mode")
    private String paymentMode;
    @Column("pension_amount")
    private BigDecimal pensionAmount;
    @Column("pran_number")
    private String pranNumber;
    @Column("premium")
    private BigDecimal premium;
    @Column("set_mandate_flag")
    private Boolean setMandateFlag;
    @Column("source_account_name")
    private String sourceAccountName;
    @Column("source_account_number")
    private String sourceAccountNumber;
    @Column("status")
    private String status;
    @Column("trans_ref_number")
    private String transRefNumber;
	

}
