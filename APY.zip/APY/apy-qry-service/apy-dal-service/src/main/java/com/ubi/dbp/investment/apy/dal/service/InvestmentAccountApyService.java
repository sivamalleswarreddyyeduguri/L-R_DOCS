package com.ubi.dbp.investment.apy.dal.service;


import java.util.List;

import com.ubi.dbp.investment.apy.dal.entity.InvestmentAccountApy;

public interface InvestmentAccountApyService {

    List<InvestmentAccountApy> save();

    List<InvestmentAccountApy> findAll();

    List<InvestmentAccountApy> findByCif(String cif);
	
    List<InvestmentAccountApy> findByCifAndApplicationFormNumber(String cif,String applicationFormNumber);
    
    InvestmentAccountApy save(InvestmentAccountApy investmentAccountApy);

    InvestmentAccountApy update(InvestmentAccountApy investmentAccountApy);
 
    void deleteByCif(String cif);
	
    void deleteByCifAndApplicationFormNumber(String cif,String applicationFormNumber);
}