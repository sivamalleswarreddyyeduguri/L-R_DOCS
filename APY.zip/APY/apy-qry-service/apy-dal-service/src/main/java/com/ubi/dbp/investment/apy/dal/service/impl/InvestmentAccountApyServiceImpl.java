package com.ubi.dbp.investment.apy.dal.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ubi.dbp.investment.apy.dal.entity.InvestmentAccountApy;
import com.ubi.dbp.investment.apy.dal.repository.InvestmentAccountApyRepository;
import com.ubi.dbp.investment.apy.dal.service.InvestmentAccountApyService;

@Service
public class InvestmentAccountApyServiceImpl implements InvestmentAccountApyService {

	Logger logger = LoggerFactory.getLogger(getClass());

    @Autowired
    private InvestmentAccountApyRepository repository;

    @Override
    public List<InvestmentAccountApy> save() {

        List<InvestmentAccountApy> investmentAccountApy = repository.findAll();
        if (investmentAccountApy.isEmpty()){
          logger.error("No values found in DB..!!");
        } 
        return repository.findAll();
    }

    @Override
    public List<InvestmentAccountApy> findAll() {
        return repository.findAll();
    }

	@Override
    public List<InvestmentAccountApy> findByCif(String cif) {
        return repository.findByCif(cif);
    }

    @Override
    public List<InvestmentAccountApy> findByCifAndApplicationFormNumber(String cif,String applicationFormNumber){
        return repository.findByCifAndApplicationFormNumber(cif,applicationFormNumber);
    }
    
    @Override
    public InvestmentAccountApy save(InvestmentAccountApy investmentAccountApy) {
        return repository.save(investmentAccountApy);
    }

    @Override
    public InvestmentAccountApy update(InvestmentAccountApy investmentAccountApy) {
        return repository.save(investmentAccountApy);
    }

    @Override
    public void deleteByCif(String cif) {
        repository.deleteByCif(cif);
    }
	
    @Override
    public void deleteByCifAndApplicationFormNumber(String cif,String applicationFormNumber){
        repository.deleteByCifAndApplicationFormNumber(cif,applicationFormNumber);
    }
    
}